# Digitaltechnik - Kapitel 7a: Schaltnetze und Schaltwerke

## Schaltzeichen nach der Norm DIN 40900
> [!NOTE]
> Definiert die standardisierten grafischen Symbole für logische Gatter, die als Grundbausteine digitaler Schaltungen dienen.

| UND (AND) | NAND | Funktionsblock |
| :---: | :---: | :---: |
| ![](07a_Schaltnetze_und_Schaltwerke/AND_gate_EWbt.excalidraw) | ![](07a_Schaltnetze_und_Schaltwerke/NAND_gate_HtTO.excalidraw) | ![](07a_Schaltnetze_und_Schaltwerke/Function_block_3fYq.excalidraw) |
| **ODER (OR)** | **NOR** | **NICHT (NOT / Inverter)** |
| ![](07a_Schaltnetze_und_Schaltwerke/OR_gate_Opgc.excalidraw) | ![](07a_Schaltnetze_und_Schaltwerke/NOR_gate_Neo1.excalidraw) | ![](07a_Schaltnetze_und_Schaltwerke/NOT_gate_1_vDc1.excalidraw) <br> ![](07a_Schaltnetze_und_Schaltwerke/NOT_gate_2_SQ9Z.excalidraw) |

---

## Schaltnetze (Kombinatorische Logik)
> [!NOTE]
> Ein Schaltnetz ist eine digitale Schaltung, deren Ausgangswerte ausschließlich von den momentan anliegenden Eingangswerten abhängen. Es besitzt kein Gedächtnis zur Speicherung vergangener Zustände.

Ein **Schaltnetz** realisiert eine Boolesche Funktion. Die Ausgänge $y$ sind eine direkte Funktion der Eingänge $x$. Sie sind "gedächtnislos".

**Beispiel: XOR-Gatter**
Die logische Funktion für ein XOR-Gatter lautet:
$y = (x_2 \land \overline{x_1}) \lor (\overline{x_2} \land x_1) = z_2 \lor z_1$

Realisierung mit AND-, OR- und NOT-Gattern:
![](07a_Schaltnetze_und_Schaltwerke/LogicCircuit_XOR_Implementation_mhlw.excalidraw)

Allgemeine Darstellung eines Schaltnetzes als Blockdiagramm:
![](07a_Schaltnetze_und_Schaltwerke/BlockDiagramWithInputAndOutput_1FJp.excalidraw)

### Entwurf von Schaltnetzen
> [!NOTE]
> Der Entwurfsprozess übersetzt eine funktionale Anforderung systematisch in eine logische Schaltung, meist über den Weg einer Wahrheitstabelle und der anschließenden Minimierung der Booleschen Ausdrücke.

### Beispiele für Schaltnetze: Addiererbausteine
> [!NOTE]
> Addierer sind fundamentale Schaltnetze, die die arithmetische Addition von Binärzahlen durchführen. Sie bilden die Grundlage für Rechenwerke in Prozessoren.

#### Halbaddierer
> [!NOTE]
> Ein Halbaddierer addiert zwei einzelne Bits ($a_i, b_i$) und erzeugt daraus ein Summenbit ($s_i$) und ein Übertragsbit ($c_{i+1}$).

<div style="display: flex; justify-content: space-between; align-items: flex-start;">
<div style="flex-basis: 50%;">
Die logischen Funktionen des Halbaddierers sind:
<ul>
    <li>Summe: $s_i = a_i \oplus b_i$</li>
    <li>Übertrag (Carry): $c_{i+1} = a_i \cdot b_i$</li>
</ul>
<br>

**Wahrheitstabelle:**
![](Truth_table_skeleton_for_a_half-adder_myVL.png)
</div>
<div style="flex-basis: 50%; text-align: center;">
<b>Interne Struktur:</b><br>
![](07a_Schaltnetze_und_Schaltwerke/Internal_structure_of_a_half-adder_e3W1.excalidraw)
<br><br>
<b>Blockdiagramm:</b><br>
![](07a_Schaltnetze_und_Schaltwerke/Block_diagram_of_a_half-adder_ENR9.excalidraw)
</div>
</div>

#### Volladdierer
> [!NOTE]
> Ein Volladdierer addiert drei einzelne Bits: zwei Summandenbits ($a_i, b_i$) und ein Übertragsbit vom vorherigen Addierer ($c_i$). Er erzeugt ebenfalls ein Summen- und ein Übertragsbit.

**Logische Funktionen:**
*   Summe: $s_i = a_i \oplus b_i \oplus c_i$
*   Übertrag: $c_{i+1} = (a_i \cdot b_i) + (a_i \cdot c_i) + (b_i \cdot c_i)$

**Interne Struktur (aus zwei Halbaddierern):**
![](07a_Schaltnetze_und_Schaltwerke/Detailed_circuit_diagram_of_a_full_adder_showing_i_lRj8.excalidraw)

**Wahrheitstabelle:**
| $a_i$ | $b_i$ | $c_i$ | $s_i$ | $c_{i+1}$ |
|:---:|:---:|:---:|:---:|:---:|
| 0 | 0 | 0 | 0 | 0 |
| 0 | 0 | 1 | 1 | 0 |
| 0 | 1 | 0 | 1 | 0 |
| 0 | 1 | 1 | 0 | 1 |
| 1 | 0 | 0 | 1 | 0 |
| 1 | 0 | 1 | 0 | 1 |
| 1 | 1 | 0 | 0 | 1 |
| 1 | 1 | 1 | 1 | 1 |

**Blockdiagramm:**
![](07a_Schaltnetze_und_Schaltwerke/Simplified_block_diagram_of_a_full_adder_with_inpu_xlQB.excalidraw)

#### n-Bit Ripple-Carry-Addierer
> [!NOTE]
> Ein Ripple-Carry-Addierer wird durch die serielle Verschaltung von Volladdierern gebildet, um n-Bit breite Zahlen zu addieren. Der Übertrag "rieselt" dabei von einer Stufe zur nächsten.

![](07a_Schaltnetze_und_Schaltwerke/Block_diagram_of_an_n-Bit_Ripple-Carry_Adder_tt3s.excalidraw)

##### 4-Bit Ripple-Carry-Addierer
> [!NOTE]
> Dies ist eine konkrete Implementierung eines Ripple-Carry-Addierers für die Addition von zwei 4-Bit-Zahlen, bestehend aus vier verketteten Volladdierern.

Der Hauptnachteil ist die Gatterlaufzeit, da jede Stufe auf den Übertrag der vorherigen warten muss.
![](07a_Schaltnetze_und_Schaltwerke/Diagram_of_a_4-Bit_Ripple-Carry_Adder_Y35Z.excalidraw)

#### Subtrahierbaustein
> [!NOTE]
> Ein Subtrahierer kann durch die Nutzung eines Addierers und der Logik des Zweierkomplements realisiert werden. Die Subtraktion $A - B$ wird als Addition $A + (-B)$ ausgeführt.

![](07a_Schaltnetze_und_Schaltwerke/SubtractorModuleCircuit_H1r8.excalidraw)

### Struktur von Schaltnetzen
> [!NOTE]
> Beschreibt die verschiedenen Architekturen, nach denen Schaltnetze aufgebaut werden können, von unstrukturierter ("krauser") Logik bis zu hochgradig regelmäßigen Strukturen wie PLAs.

#### Normalformorientierte Struktur
> [!NOTE]
> Diese Struktur basiert direkt auf der Disjunktiven Normalform (DNF) einer Booleschen Funktion. Sie besteht aus einer UND-Ebene, die alle Minterme generiert, gefolgt von einer ODER-Ebene, die die relevanten Minterme zur Bildung der Ausgabe verknüpft.

Ein Schaltnetz kann als zweistufige Logik aus einer UND-Matrix und einem ODER-Gatter aufgebaut werden.
*   Die erste Stufe generiert alle $2^n$ möglichen Minterme $m_j$.
*   Die zweite Stufe verknüpft die benötigten Minterme mit ODER.

Beispiel: $y = m_1 \lor m_4 \lor m_5 \lor m_6 \lor m_7$

**Blockdiagramm:**
![](07a_Schaltnetze_und_Schaltwerke/DNF_Block_Diagram_YLK1.excalidraw)

**Logische Schaltung:**
![](07a_Schaltnetze_und_Schaltwerke/Logic_Circuit_Implementation_Epl6.excalidraw)

#### Blockorientierte Struktur
> [!NOTE]
> Bei dieser Struktur werden gemeinsame Terme, die in mehreren Ausgangsfunktionen vorkommen, nur einmal realisiert und wiederverwendet. Dies führt zu einer effizienteren Schaltung im Vergleich zur strikten Normalform.

Wenn weniger als $2^n$ UND-Verknüpfungen benötigt werden oder Terme mehrfach verwendet werden können, ist eine blockorientierte Struktur effizienter.

**Beispiel:**
*   $y = (\overline{x_2} \land x_1) \lor (x_3)$
*   $z = (\overline{x_2} \land x_1) \lor (x_2 \land \overline{x_1})$
Der Term $(\overline{x_2} \land x_1)$ wird für beide Ausgänge wiederverwendet.

**Blockdiagramm (AND/OR Matrix):**
![](07a_Schaltnetze_und_Schaltwerke/AND_OR_Matrix_DMF_Structure_Su08.excalidraw)

**Logische Schaltung:**
![](07a_Schaltnetze_und_Schaltwerke/Logic_Circuit_For_Y_and_Z_wcK3.excalidraw)

##### CPLD (Complex Programmable Logic Device)
> [!NOTE]
> Ein CPLD ist ein programmierbarer Logikbaustein, der aus mehreren logischen Blöcken besteht, die durch eine programmierbare Verbindungsmatrix miteinander verbunden sind. Jeder Block implementiert eine blockorientierte AND-OR-Struktur.

Ein **CPLD** ist ein integrierter Schaltkreis, der aus mehreren programmierbaren Logikblöcken (Logic Array Blocks, LABs) besteht. Diese Blöcke sind untereinander über eine programmierbare Interconnect-Matrix verbunden.
*   **Architektur:** Basiert auf der Summe von Produkten (AND-OR-Struktur).
*   **Speicher:** Nicht-flüchtig (Konfiguration bleibt nach dem Ausschalten erhalten).
*   **Eigenschaften:** Vorhersehbare Timing-Verzögerungen, gut für Steuerungslogik.

**Chip-Foto und Architektur:**
| Altera MAX CPLD | CPLD Architektur |
|:---:|:---:|
| ![](07a_Schaltnetze_und_Schaltwerke/Altera_MAX_CPLD_Chip_Photo_catU.excalidraw) | ![](07a_Schaltnetze_und_Schaltwerke/CPLD_Architecture_Block_Diagram_DHlQ.excalidraw) |

##### Entwicklung programmierbarer Logik
> [!NOTE]
> Die Evolution programmierbarer Logikbausteine reicht von einfachen PALs und GALs bis hin zu komplexen CPLDs und FPGAs, die eine immer höhere Integrationsdichte und Flexibilität bieten.

Die Entwicklung führte von einfachen programmierbaren Bausteinen zu hochkomplexen Systemen:
*   **PAL (Programmable Array Logic):** Programmierbare AND-Matrix, feste OR-Matrix.
*   **GAL (Generic Array Logic):** Ähnlich wie PAL, aber wiederprogrammierbar.
*   **CPLD (Complex Programmable Logic Device):** Mehrere PAL/GAL-ähnliche Blöcke auf einem Chip.
*   **FPGA (Field-Programmable Gate Array):** Große Anzahl von konfigurierbaren Logikblöcken (CLBs) in einer Matrix-Struktur.

![](07a_Schaltnetze_und_Schaltwerke/ConceptBox_Lightbulb_IOBP.excalidraw) ![](07a_Schaltnetze_und_Schaltwerke/ConceptBox_Chip_5NZa.excalidraw)

---

## Automaten (Endliche Zustandsautomaten)
> [!NOTE]
> Ein Automat ist ein abstraktes Modell eines Systems mit einer endlichen Anzahl von Zuständen. Sein Verhalten wird durch Eingaben gesteuert, die Zustandsübergänge auslösen und Ausgaben erzeugen.

### Motivation: Fahrkartenautomat
> [!NOTE]
> Ein Fahrkartenautomat ist ein anschauliches Beispiel für einen Automaten: Er hat verschiedene Zustände (z.B. "Warte auf Geldeinwurf", "Betrag erreicht"), reagiert auf Eingaben (Münzen, Tastendruck) und erzeugt Ausgaben (Ticket, Wechselgeld).

Ein Fahrkartenautomat muss sich den eingeworfenen Geldbetrag "merken" (Zustand), um zu entscheiden, ob ein Ticket ausgegeben werden kann.

*   **Eingaben:** Geldeinwurf $G$, Wahl $W$, Bestätigung $E$, Korrektur $K$.
*   **Zustand:** Aktuell eingeworfener Betrag.
*   **Ausgaben:** Ticket, Wechselgeld.

![](07a_Schaltnetze_und_Schaltwerke/Ticket_machine_with_inputs__person__and_outputs__c_VnIy.excalidraw)

### Allgemeines Modell eines Automaten
> [!NOTE]
> Das allgemeine Modell beschreibt einen Automaten formal durch seine Eingabe- und Ausgabealphabete, eine endliche Zustandsmenge sowie eine Überführungs- und eine Ausgabefunktion. Die Ausgabe hängt von der aktuellen Eingabe und der Historie vergangener Eingaben ab, die im Zustand zusammengefasst ist.

Ein Automat (AT) wird formal durch seine Komponenten definiert:
*   **Eingabemenge** $E = \{E_1, E_2, \dots, E_u\}$
*   **Ausgabemenge** $A = \{A_1, A_2, \dots, A_v\}$
*   Der Zustand $S$ fasst die Historie der Eingaben zusammen.
*   Die Ausgabe zum Zeitpunkt $\nu$ hängt von der Sequenz vergangener Eingaben ab:
    $A_h^\nu = f(E_g^\nu, E_g^{\nu-1}, E_g^{\nu-2}, \dots, E_g^{\nu-\alpha})$
    
![](07a_Schaltnetze_und_Schaltwerke/Block_diagram_of_an_automaton_X3Hr.excalidraw)

Das System hat ein "Gedächtnis" von $\textcolor{#4ce699}{\alpha}$ vergangenen Takten.

Der Zustand $S_k$ zum Zeitpunkt $\nu$ wird durch die vorherigen $\alpha$ Eingaben bestimmt: $(E_g^{\nu-1} \dots E_g^{\nu-\alpha}) \rightarrow S_k^\nu$.

Damit können die Kernfunktionen des Automaten definiert werden:
*   **Ausgabefunktion $\textcolor{#e64c4c}{\lambda}$:** Bestimmt die aktuelle Ausgabe aus der aktuellen Eingabe und dem aktuellen Zustand.
    $\textcolor{#e64c4c}{A_h^v = \lambda (E_g^v, S_k^v)}$
*   **Überführungsfunktion $\textcolor{#4ce699}{\delta}$:** Bestimmt den nächsten Zustand aus der aktuellen Eingabe und dem aktuellen Zustand.
    $\textcolor{#4ce699}{S_k^{v+1} = \delta (E_g^v, S_k^v)}$

Formal wird ein Automat als 5-Tupel beschrieben: **$AT = (E, A, S, \delta, \lambda)$**

![](07a_Schaltnetze_und_Schaltwerke/AutomatonBlockDiagram_RsGP.excalidraw)

### Typen von Automaten
> [!NOTE]
> Automaten werden danach unterschieden, wovon ihre Ausgabe abhängt. Die drei Haupttypen sind Mealy, Moore und Medwedew.

#### Mealy-Automat
> [!NOTE]
> Beim Mealy-Automaten hängt die Ausgabe sowohl vom aktuellen Zustand als auch von der aktuellen Eingabe ab. Dies ermöglicht eine unmittelbare Reaktion auf Eingabeänderungen.

Die Ausgabefunktion lautet: $\textcolor{#4ce64c}{A_h^v = \lambda(E_g^v, S_k^v)}$
![](07a_Schaltnetze_und_Schaltwerke/BlockDiagramOfAutomaton_xNtb.excalidraw)

#### Moore-Automat
> [!NOTE]
> Beim Moore-Automaten hängt die Ausgabe ausschließlich vom aktuellen Zustand ab. Die Ausgabe ändert sich nur bei einem Zustandswechsel.

Die Ausgabefunktion ist nur vom Zustand abhängig: $\textcolor{#4c99e6}{A_h^v = \lambda ( S_k^v )}$
![](07a_Schaltnetze_und_Schaltwerke/Mealy_Automaton_MR8C.excalidraw)

#### Medwedew-Automat
> [!NOTE]
> Der Medwedew-Automat ist ein Spezialfall des Moore-Automaten, bei dem der Zustand selbst direkt die Ausgabe ist. Es gibt keine separate Ausgabefunktion.

Die Ausgabe ist identisch mit dem Zustand: $\textcolor{#4c99e6}{A_h^v = S_k^v}$
![](07a_Schaltnetze_und_Schaltwerke/Moore_Automaton_P9xV.excalidraw)

### Beschreibung des Verhaltens
> [!NOTE]
> Das Verhalten eines Automaten kann grafisch durch einen Automatengraphen (Zustandsdiagramm) oder tabellarisch durch eine Zustandstabelle dargestellt werden.

#### Automatengraph (Zustandsdiagramm)
> [!NOTE]
> Ein Zustandsdiagramm visualisiert die Zustände als Knoten und die Zustandsübergänge als gerichtete Kanten. Die Kanten sind mit den auslösenden Eingaben und den erzeugten Ausgaben beschriftet.

*   **Knoten:** Stellen die Zustände $S_k$ dar.
*   **Kanten:** Stellen die Übergänge $S_k^v \to S_k^{v+1}$ dar.
*   **Beschriftung:**
    *   **Mealy:** `Eingabe / Ausgabe` an der Kante.
    *   **Moore:** `Ausgabe` im Zustandsknoten.

| Mealy-Automat | Moore-Automat |
|:---:|:---:|
| ![](07a_Schaltnetze_und_Schaltwerke/StateAutomaton_S1_S2_S3_S4_31nP.excalidraw) | ![](07a_Schaltnetze_und_Schaltwerke/StateAutomaton_S1A1_S2A1_S3A2_S4A3_yMAO.excalidraw) |

#### Zustandstabelle
> [!NOTE]
> Eine Zustandstabelle listet für jede Kombination aus aktuellem Zustand und aktueller Eingabe den Folgezustand und die entsprechende Ausgabe auf.

| Mealy-Tabelle (Ausgabe von Zustand und Eingabe abhängig) | Moore-Tabelle (Ausgabe nur von Zustand abhängig) |
|:---:|:---:|
| ![](State_Transition_Table_With_Output_lASN.png) | ![](State_Transition_Table_Without_Output_W5YB.png) |

---

## Schaltwerke (Sequentielle Logik)
> [!NOTE]
> Ein Schaltwerk ist die technische Realisierung eines Automaten. Es besteht aus einem kombinatorischen Schaltnetz und einem Speicher, wodurch sein Ausgang sowohl von den aktuellen Eingängen als auch von seinem inneren Zustand abhängt.

Ein Schaltwerk ist ein Schaltnetz mit Gedächtnis und wird auch als **Automat** bezeichnet. Die binären Signale werden wie folgt zugeordnet:
*   Eingabealphabet $\textcolor{#4c99e6}{E \leftrightarrow \{X_i\}}$ mit $|E| \le 2^n$ bei einem Eingangsvektor $X = \{x_n, ..., x_1\}$.
*   Ausgabealphabet $\textcolor{#4c99e6}{A \leftrightarrow \{Y_i\}}$ mit $|A| \le 2^m$ bei einem Ausgangsvektor $Y = \{y_m, ..., y_1\}$.
*   Zustandsmenge $\textcolor{#4ce64c}{S \leftrightarrow \{Q_k\}}$ mit $|S| \le 2^r$ bei einem Zustandsvektor $Q = \{q_r, ..., q_1\}$.

Die Funktionen $\textcolor{#e64c4c}{\lambda}$ (Ausgabefunktion) und $\textcolor{#4ce64c}{\delta}$ (Überführungsfunktion) werden durch Schaltnetze realisiert.

### Asynchrone Schaltwerke
> [!NOTE]
> Bei asynchronen Schaltwerken erfolgt die Zustandsänderung unmittelbar als Reaktion auf eine Eingabeänderung, ohne ein zentrales Taktsignal. Die Stabilität hängt von den Gatterlaufzeiten ab, was den Entwurf komplex macht.

Zustandsänderungen werden direkt durch Änderungen der Eingangssignale ausgelöst. Die Rückführung der Zustandssignale erfolgt über Verzögerungsglieder.
![](07a_Schaltnetze_und_Schaltwerke/AsynchronousSequentialCircuitDiagram_XjYs.excalidraw)

### Synchrone Schaltwerke
> [!NOTE]
> Synchrone Schaltwerke verwenden ein zentrales Taktsignal ($c$), um alle Zustandsänderungen zu koordinieren. Änderungen im Zustandsspeicher (Flip-Flops) finden nur zu definierten Zeitpunkten statt, die durch die Taktflanke bestimmt werden.

Ein zusätzliches, informationsfreies Binärsignal, der **Takt** $\textcolor{#4c4ce6}{c}$, steuert die Zustandsübergänge.
*   Wenn $\textcolor{#4c4ce6}{c = 0}$ (inaktiv): Der Zustandsspeicher ist "gesperrt", der Zustand $S^v$ bleibt erhalten.
*   Wenn $\textcolor{#4c4ce6}{c = 1}$ (aktiv): Der neu berechnete Folgezustand $S^{v+1}$ wird in den Speicher übernommen.

Der Übergang $\textcolor{#4c4ce6}{S^{v+1} \to S^v}$ findet nur bei aktiver Taktflanke statt.

![](07a_Schaltnetze_und_Schaltwerke/SynchronousCircuitBlockDiagram_7Dej.excalidraw)

#### Steuerarten des Taktes (Clocking)
> [!NOTE]
> Definiert, zu welchem Zeitpunkt des Taktsignals eine Zustandsänderung stattfindet. Gängige Methoden sind pegelgesteuert (während des High- oder Low-Pegels) oder flankengesteuert (bei der ansteigenden oder abfallenden Flanke).

*   **Pegelgesteuert (level-triggered):** Der Zustand kann sich ändern, solange der Takt auf einem bestimmten Pegel (z.B. HIGH) ist.
*   **Flankengesteuert (edge-triggered):** Der Zustand ändert sich nur im exakten Moment einer Taktflanke.
    *   **Positive Flanke:** Übergang von $0 \to 1$.
    *   **Negative Flanke:** Übergang von $1 \to 0$.

| Positive Flankensteuerung | Symbol |
| :--- | :--- |
| ![](07a_Schaltnetze_und_Schaltwerke/ClockSignalPulseDiagram_pJ1o.excalidraw) <br> ![](07a_Schaltnetze_und_Schaltwerke/RisingClockEdge_iRud.excalidraw) | ![](07a_Schaltnetze_und_Schaltwerke/ClockInputCircuitSymbol_kRl5.excalidraw) |
| **Negative Flankensteuerung** | **Symbol** |
| ![](07a_Schaltnetze_und_Schaltwerke/Clock_Signal_Timing_Diagram_9DZJ.excalidraw) | ![](07a_Schaltnetze_und_Schaltwerke/Negated_Clock_Input_Symbol_O3kp.excalidraw) |

### Speicherung der Zustände: Binärspeicher (Flip-Flops)
> [!NOTE]
> Flip-Flops sind die fundamentalen Speicherbausteine in synchronen Schaltwerken. Jedes Flip-Flop kann ein einzelnes Bit speichern und bildet zusammen mit anderen den Zustandsvektor des Schaltwerks.

Um $|S|$ Zustände zu speichern, werden $r = \lceil \log_2 |S| \rceil$ binäre Speicherelemente (Flip-Flops) benötigt.
Jedes Flip-Flop $k$ speichert ein Zustandsbit $q_k$. Der gesamte Zustand wird im Zustandsvektor $\textcolor{#4ce64c}{Q} = (q_r, ..., q_k, ..., q_1)$ gespeichert.

![](07a_Schaltnetze_und_Schaltwerke/SequentialCircuitBlockDiagram_2uES.excalidraw)

Flip-Flops sind takgesteuerte bistabile Kippschaltungen, die entweder den Zustand $\textcolor{#4c4ce6}{0}$ oder $\textcolor{#4c4ce6}{1}$ annehmen können. Der Übergang vom alten Zustand $q^v$ zum neuen Zustand $q^{v+1}$ wird durch die Eingänge des Flip-Flops und den Takt gesteuert.

#### RS-FlipFlop
> [!NOTE]
> Das RS-Flip-Flop wird über zwei Eingänge gesteuert: **S** (Set) zum Setzen des Ausgangs auf 1 und **R** (Reset) zum Zurücksetzen auf 0. Der Zustand R=1, S=1 ist verboten.

| Eingang | Beschreibung | $q_k^{neu}$ |
| :--- | :--- | :---: |
| R=0, S=0 | Speichern | $q_k^{alt}$ |
| R=0, S=1 | Setzen | 1 |
| R=1, S=0 | Zurücksetzen | 0 |
| R=1, S=1 | Verboten | - |

![](RS_FlipFlop_FunctionTable_YgPU.png)

#### D-FlipFlop
> [!NOTE]
> Das D-Flip-Flop (Data-Flip-Flop) hat einen Dateneingang **D** und oft einen Schreib-/Enable-Eingang **W**. Bei aktiver Taktflanke wird der Wert am D-Eingang in das Flip-Flop übernommen und gespeichert.

*   Der Wert am Eingang $\textcolor{#4c4ce6}{D}$ wird bei aktiver Taktflanke übernommen.
*   Ein zusätzlicher Eingang $W$ (Write Enable) kann die Übernahme steuern.
    *   $W=0$: Speichern (alter Zustand bleibt)
    *   $W=1$: Schreiben (neuer Zustand wird $D$)

![](D-FlipFlop_Truth_Table_Header_q_k_alt_D_W_q_k_neu_KrBg.png)

#### Charakteristische Gleichungen
> [!NOTE]
> Die charakteristische Gleichung eines Flip-Flops beschreibt den Folgezustand $q^{v+1}$ als Boolesche Funktion des aktuellen Zustands $q^v$ und der Steuereingänge.

Die Gleichung beschreibt den Zustand $q_k^{v+1}$ in Abhängigkeit von $q_k^v$ und den Eingängen ($R^v, S^v, D^v, W^v$).

| RS-FlipFlop | D-FlipFlop (mit Write-Enable) |
| :--- | :--- |
| ![](07a_Schaltnetze_und_Schaltwerke/KV_Map_SR_c4Zv.excalidraw) ![](Table_RS_ZjWa.png) | ![](07a_Schaltnetze_und_Schaltwerke/KV_Map_WD_eoRY.excalidraw) ![](Table_DW_vEh1.png) |
| $q_k^{v+1} = S^v \lor (q_k^v \land \overline{R^v})$, mit der Bedingung $S^v \land R^v = 0$ | $q_k^{v+1} = (D^v \land W^v) \lor (q_k^v \land \overline{W^v})$ |

#### Ansteuerfunktionen
> [!NOTE]
> Ansteuerfunktionen (oder Anregungstabellen) geben an, welche Eingangswerte an einem Flip-Flop anliegen müssen, um einen gewünschten Zustandsübergang von $q^v$ nach $q^{v+1}$ zu bewirken.

| RS-Ansteuerung | D-Ansteuerung (mit Write-Enable) |
|:---:|:---:|
| <table><thead><tr><th>$q^v$</th><th>$q^{v+1}$</th><th>$R^v$</th><th>$S^v$</th></tr></thead><tbody><tr><td>0</td><td>0</td><td>x</td><td>0</td></tr><tr><td>0</td><td>1</td><td>0</td><td>1</td></tr><tr><td>1</td><td>0</td><td>1</td><td>0</td></tr><tr><td>1</td><td>1</td><td>0</td><td>x</td></tr></tbody></table> | <table><thead><tr><th>$q^v$</th><th>$q^{v+1}$</th><th>$D^v$</th><th>$W^v$</th></tr></thead><tbody><tr><td>0</td><td>0</td><td>0</td><td>1 (oder x,0)</td></tr><tr><td>0</td><td>1</td><td>1</td><td>1</td></tr><tr><td>1</td><td>0</td><td>0</td><td>1</td></tr><tr><td>1</td><td>1</td><td>1</td><td>1 (oder x,0)</td></tr></tbody></table> |

*   Einfache Ansteuerungen:
    *   **RS-FF**: $R^v = \overline{q_k^{v+1}}$, $S^v = q_k^{v+1}$
    *   **D-FF**: $D^v = q_k^{v+1}$
    *   **T-FF (Toggle)**: $W^v = (q_k^{v+1} \neq q_k^v)$, $D^v = \overline{q_k^v}$

#### Zusammenfassung der FlipFlop-Typen

| Symbol | Charakteristische Gleichung | Wahrheitstabelle |
|:---:|:---:|:---:|
| ![](07a_Schaltnetze_und_Schaltwerke/Flip-flop_symbols_2shl.excalidraw) | $\textcolor{#4d4d4d}{q^{\nu+1} = S \lor (q^\nu \& \bar{R})}$ <br><br><br><br><br><br><br><br> $\textcolor{#4d4d4d}{q^{\nu+1} = D}$ | ![](Flip-flop_characteristic_tables_aDEp.png) |

| Typ | Symbol | Charakteristische Gleichung | Anregungstabelle |
| :--- | :---: | :--- | :--- |
| **T-FlipFlop** | ![](07a_Schaltnetze_und_Schaltwerke/T-FlipFlop_Block_Diagram_vihC.excalidraw) | $q^{v+1} = (T \land \bar{q}^v) \lor (\bar{T} \land q^v)$ | ![](T-FlipFlop_Anregungstabelle_Shell_vA3P.png) |
| **JK-FlipFlop** | ![](07a_Schaltnetze_und_Schaltwerke/JK-FlipFlop_Block_Diagram_fX6i.excalidraw) | $q^{v+1} = (\bar{K} \land q^v) \lor (J \land \bar{q}^v)$ | ![](JK-FlipFlop_Anregungstabelle_Shell_JbPn.png) |

---

## Entwurf von Schaltwerken
> [!NOTE]
> Der Entwurf eines Schaltwerks ist ein systematischer Prozess, der eine verbale Beschreibung in eine logische Schaltung umsetzt. Die Schritte umfassen die Erstellung eines Ablaufdiagramms, die Zustandskodierung, das Ableiten von Logikgleichungen und die finale Realisierung mit Gattern und Flip-Flops.

**Entwurfsschritte:**
1.  Erstellen des **Ablaufdiagramms** aus der verbalen Beschreibung.
2.  Aufstellen der **Ablauftabelle** (Zustandstabelle).
3.  **Zustandskodierung**: Zuweisung von Binärwerten zu den symbolischen Zuständen.
4.  Auswahl des **Flip-Flop-Typs**.
5.  Aufstellen der **Ansteuer- und Ausgangsfunktionen** (z.B. mit KV-Diagrammen).
6.  **Realisierung** des Schaltwerks.

### Beispiel: Entwurf eines Automaten

Der Automat soll folgendes Verhalten zeigen (Eingaben: K, T, B; Ausgabe: A):
![](07a_Schaltnetze_und_Schaltwerke/Flowchart_of_a_sequential_circuit_0Ntd.excalidraw)

#### Schritt 1-3: Ablauftabelle und Zustandskodierung
> [!NOTE]
> Die Ablauftabelle übersetzt das grafische Ablaufdiagramm in eine tabellarische Form. Anschließend werden den symbolischen Zuständen (z.B. S0, S1) eindeutige binäre Codes (z.B. 00, 01) zugewiesen.

Wir verwenden 4 Zustände, die mit 2 Flip-Flops ($q_2, q_1$) kodiert werden. Die Ausgabe A ist 1 im Zustand $Q=(1,1)$.
![](StateTransitionTable_wm5G.png)

#### Schritt 4-5: Bestimmung der Ansteuerfunktionen
> [!NOTE]
> Aus der kodierten Zustandstabelle werden die Logikgleichungen für die Flip-Flop-Eingänge (Ansteuerfunktionen) und die Ausgänge des Schaltwerks abgeleitet, typischerweise durch Minimierung mit KV-Diagrammen.

Wir wählen D-Flip-Flops, bei denen die Ansteuerfunktion direkt dem Folgezustand entspricht ($D_2 = q_2^{v+1}$, $D_1 = q_1^{v+1}$).

| Ansteuerfunktion $D_2 = q_2^{v+1}$ | Ansteuerfunktion $D_1 = q_1^{v+1}$ |
| :---: | :---: |
| <div align="center"> $q_2^v, q_1^v$ <br> <img src="07a_Schaltnetze_und_Schaltwerke/KarnaughMapAxis_q2_q1_WPaQ.excalidraw" width="100"> </div> | <div align="center"> $q_2^v, q_1^v$ <br> <img src="07a_Schaltnetze_und_Schaltwerke/KarnaughMapAxis_q2_q1_WPaQ.excalidraw" width="100"> </div> |
| $D_2 = \overline{q_2^v}q_1^v\overline{K} \lor q_2^v\overline{q_1^v}T \lor q_2^v q_1^v \overline{K} \lor q_2^v q_1^v \overline{B}$ | $D_1 = \overline{q_2^v}\overline{K} \lor q_2^v\overline{q_1^v}\overline{K} \lor q_2^v q_1^v \overline{B}$ |

Die **Ausgangsfunktion** lautet: $A = q_2^v q_1^v$.

#### Schritt 6: Realisierung der Schaltung
> [!NOTE]
> Im letzten Schritt wird die finale Schaltung gezeichnet, indem die minimierten Logikgleichungen mit Gattern umgesetzt und mit den ausgewählten Flip-Flops verbunden werden.

Die abgeleiteten Gleichungen werden direkt in eine Schaltung mit Gattern und zwei D-Flip-Flops umgesetzt.
![](07a_Schaltnetze_und_Schaltwerke/DigitalLogicCircuitForSequentialMachine_pN7W.excalidraw)

---

## Poster: Zusammenfassung Automaten

![](07a_Schaltnetze_und_Schaltwerke/ITV_QRCode_prcn.excalidraw)

### Grundlagen
> [!NOTE]
> Ein Automat ist ein mathematisches Modell, das durch ein Tupel aus Eingabe-, Ausgabe-, und Zustandsmengen sowie Überführungs- und Ausgabefunktionen definiert wird.

Ein <span style="color:#4c99e6">Automat</span> ist ein mathematisches Modell, das Eingabewerte verarbeitet und entsprechende Ausgabewerte liefert. Er wird durch das Tupel
$AT = (E, A, S, \lambda, \delta)$
definiert, wobei:
-   $E$ das <span style="color:#4c99e6">Eingabealphabet</span> ist.
-   $A$ das <span style="color:#4c99e6">Ausgabealphabet</span> ist.
-   $S$ die endliche Menge der <span style="color:#4c99e6">Zustände</span> des Automaten umfasst.
-   $\lambda$ eine <span style="color:#4c99e6">Ausgabefunktion</span> ist.
-   $\delta$ die <span style="color:#4c99e6">Überführungsfunktion</span> ist.

![](07a_Schaltnetze_und_Schaltwerke/SimpleAutomatonBlockDiagram_V45G.excalidraw)

Die Ausgabe zum Zeitpunkt $v$ hängt vom aktuellen Eingabewert $E^v$ und Zustand $S^v$ ab:
$A^v = \lambda(E^v, S^v)$

Der nächste Zustand ergibt sich über die Überführungsfunktion:
$S^{v+1} = \delta(E^v, S^v)$

### Mealy-Automat
> [!NOTE]
> Beim Mealy-Automaten hängt die Ausgabe sowohl vom aktuellen Zustand als auch von der aktuellen Eingabe ab, was eine schnelle Reaktion auf Eingabeänderungen ermöglicht.

Beim <span style="color:#4c99e6">Mealy-Automaten</span> hängt die <span style="color:#4c99e6">Ausgabe</span> nicht nur vom Zustand, sondern auch direkt von der <span style="color:#4c99e6">Eingabe</span> ab. Die Ausgabefunktion ist definiert als:
$A_h^v = \lambda(E_g^v, S_k^v)$
Die Zustandsübergänge erfolgen nach:
$S_k^{v+1} = \delta(E_g^v, S_k^v)$

![](07a_Schaltnetze_und_Schaltwerke/MealyAutomatBlockDiagram_ntvC.excalidraw)

### Moore-Automat
> [!NOTE]
> Beim Moore-Automaten hängt die Ausgabe ausschließlich vom aktuellen Zustand ab. Änderungen der Ausgabe erfolgen nur bei einem Zustandswechsel.

Beim <span style="color:#4c99e6">Moore-Automaten</span> hängt die <span style="color:#4c99e6">Ausgabe</span> nur vom <span style="color:#4c99e6">aktuellen Zustand</span> ab, nicht direkt von der Eingabe. Die Ausgabefunktion ist:
$A_h^v = \lambda(S_k^v)$
Die Zustandsübergänge erfolgen nach:
$S_k^{v+1} = \delta(E_g^v, S_k^v)$

![](07a_Schaltnetze_und_Schaltwerke/MooreAutomatBlockDiagram_Hwu8.excalidraw)

### Medwedew-Automat
> [!NOTE]
> Der Medwedew-Automat ist eine vereinfachte Form des Moore-Automaten, bei dem der Zustand selbst direkt als Ausgabe dient, wodurch keine separate Ausgabefunktion benötigt wird.

Beim <span style="color:#4c99e6">Medwedew-Automaten</span> ist die <span style="color:#4c99e6">Ausgabe</span> direkt der <span style="color:#4c99e6">Zustand</span>. Die Ausgabefunktion ist die Identität:
$A_h^v = S_k^v$
Die Zustandsübergänge erfolgen wie gewohnt durch:
$S_k^{v+1} = \delta(E_g^v, S_k^v)$

![](07a_Schaltnetze_und_Schaltwerke/MedwedewAutomatBlockDiagram_Xdk6.excalidraw)

### Automatengraph
> [!NOTE]
> Ein Automatengraph visualisiert Zustände als Knoten und Übergänge als Kanten. Bei Mealy-Automaten tragen Kanten die Beschriftung "Eingabe/Ausgabe", bei Moore-Automaten steht die Ausgabe im Zustandsknoten.

Ein <span style="color:#4c99e6">Automatengraph</span> stellt die Zustände eines Automaten als Knoten und die Zustandsübergänge als gerichtete Kanten dar.
*   **Beschriftung bei Mealy-Automaten**: Kanten tragen die Beschriftung `Eingabe / Ausgabe`.
*   **Beschriftung bei Moore-Automaten**: Die Ausgabe ist im Zustandsknoten selbst vermerkt.

Die gezeigte Grafik stellt einen <span style="color:#4c99e6">Mealy-Automaten</span> dar.
![](07a_Schaltnetze_und_Schaltwerke/StateTransitionGraph_1PRR.excalidraw)

---
![](07a_Schaltnetze_und_Schaltwerke/KIT_Logo_FCwS.excalidraw)