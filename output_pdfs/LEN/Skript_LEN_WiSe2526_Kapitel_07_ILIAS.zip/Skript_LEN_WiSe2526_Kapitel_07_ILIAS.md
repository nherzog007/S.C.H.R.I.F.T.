# 7. Der Transformator

## 7.1 Einführung & Grundlagen

### Funktionsprinzip und Anwendungsbereiche
Transformatoren nutzen die <span style="color:#4c4ce6">magnetische Kopplung</span> zwischen <span style="color:#4c4ce6">galvanisch getrennten</span> (= elektrisch isolierten) Stromkreisen zur Übertragung von <span style="color:#4c4ce6">Energie</span> bzw. <span style="color:#4c4ce6">Information</span>. Die Funktion von Transformatoren basiert auf dem <span style="color:#4c4ce6">Induktionsgesetz</span>.

Die Anwendung unterscheidet sich je nach elektrotechnischer Disziplin:

| Bereich | Bezeichnung | Funktion & Ziel |
| :--- | :--- | :--- |
| **Energietechnik** | <span style="color:#4c4ce6">Leistungstransformatoren</span> | <span style="color:#4ce64c">Herauf-/Heruntertransformieren</span> von Wechselspannungen/-strömen. <span style="color:#4ce64c">Berührungsschutz</span> durch galvanische Trennung. |
| **Nachrichtentechnik** | <span style="color:#4c4ce6">Übertrager</span> | Breitbandige <span style="color:#4ce64c">Anpassung</span> von <span style="color:#4ce64c">Lastimpedanzen</span> an Signalquellen bei galvanischer Trennung. |
| **Messtechnik** | <span style="color:#4ce64c">Spannungs-/Stromwandler</span> | Verringern von zeitlich veränderlichen Messgrößen zur sicheren Erfassung. |

> [!NOTE]
> **Wirkungsweise:** Ein Transformator überträgt Energie oder Signale zwischen zwei isolierten Stromkreisen durch magnetische Induktion, wobei Spannung und Stromstärke je nach Windungsverhältnis angepasst werden.

### Struktur und Zählpfeilsysteme
In dieser Vorlesung betrachten wir <span style="color:#4c4ce6">Transformatoren mit zwei galvanisch getrennten Wicklungen</span>. Diese sind <span style="color:#4ce64c">elektrische Vierpole</span>, die oft als gekoppelte Zweipole beschrieben werden.

*   **Primärseite (Index 1):** Eingang, Energieaufnahme.
*   **Sekundärseite (Index 2):** Ausgang, Energieabgabe.

Wir nehmen an, dass die Transformatoren <span style="color:#4c4ce6">linear</span> und <span style="color:#4c4ce6">zeitinvariant</span> sind (Rechnen mit komplexen Größen möglich). Bei nicht-linearen Materialien (z.B. ferromagnetischer Kern in der Sättigung) wäre eine numerische Analyse nötig.

**Visualisierung der Zählpfeilsysteme:**

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/SymmetrischesZhlpfeilsystem_heEC.excalidraw)

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/KettenZhlpfeilsystem_643e.excalidraw)

---

## 7.2 Das Modell des Idealen Transformators

Der ideale Transformator ist ein theoretisches Modell, definiert durch <span style="color:#4c99e6">galvanische Entkopplung</span> und das <span style="color:#4c99e6">Übersetzungsverhältnis</span> $\ddot{u}$. Er speichert keine Energie, besitzt keine Verluste (Wirk- oder Blindleistung) und zeigt keine Phasenverschiebung (Spannungen sind $0^{\circ}$ oder $180^{\circ}$ zueinander).

### Übersetzungsverhältnis und Leistungsbilanz

$$
\ddot{u} = \frac{U_1}{U_2} > 0
$$

*   **Fall $\ddot{u} > 1$:** Eingangsspannung wird <span style="color:#4c99e6">heruntertransformiert</span>.
*   **Fall $\ddot{u} < 1$:** Eingangsspannung wird <span style="color:#4c99e6">herauftransformiert</span>.
*   **Fall $\ddot{u} = 1$:** Reine <span style="color:#4c99e6">galvanische Trennung</span>.

Da keine Verlustleistung auftritt ($\sum S = 0$), gilt für die Beträge:
$$
\frac{U_1}{U_2} = \frac{I_2}{I_1} = \ddot{u}
$$

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/IdealerTransformatorSchaltbild_qg8Q.excalidraw)

### Impedanztransformation
Schließt man an die Sekundärseite eine Impedanz $\underline{Z}_2$ an, wirkt diese auf die Primärseite transformiert als $\underline{Z}_1'$.

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/ImpedanztransformationSchaltbi_8pde.excalidraw)

$$
\underline{Z}_1' = \frac{\underline{U}_1}{\underline{I}_1} = \ddot{u}^2 \cdot \frac{\underline{U}_2}{\underline{I}_2} = \ddot{u}^2 \cdot \underline{Z}_2
$$

> [!NOTE]
> **Wirkungsweise:** Der ideale Transformator wandelt Spannungen proportional zu $\ddot{u}$ und Ströme proportional zu $1/\ddot{u}$. Impedanzen werden dabei quadratisch mit $\ddot{u}^2$ transformiert, was für die Leistungsanpassung essentiell ist.

---

## 7.3 Elektrodynamische Grundlagen

Um reale Transformatoren zu verstehen, betrachten wir die physikalischen Ursachen der Induktion. Ein Strom erzeugt ein Magnetfeld $\textcolor{#4c99e6}{\vec{H}}$ und eine Flussdichte $\vec{B} = \mu_0 \mu_r \vec{H}$. Der <span style="color:#4c99e6">magnetische Fluss</span> $\Phi_{mag}$ durch eine Fläche ist definiert als:

$$
\Phi_{mag} = \int \vec{B} \cdot d\vec{A} \quad \xrightarrow{B=\text{const}, B \parallel dA} \quad \Phi_{mag} = B \cdot A
$$

### Selbst- und Gegeninduktivität
Der magnetische Fluss ist über die Induktivität $L$ mit dem Strom verknüpft ($N \cdot \Phi = L \cdot i$). Bei zwei benachbarten Leiterschleifen beeinflussen sich diese gegenseitig:

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/Twoconductorloopswithmutualind_TIMs.excalidraw)

Die <span style="color:#4c99e6">Gegeninduktivität</span> $M$ beschreibt die Kopplung:
*   $N_1 \cdot \Phi_{12} = \colorbox{#e6994c}{\( M_{12} \)} \cdot i_2$ (Fluss in 1 durch Strom in 2)
*   $N_2 \cdot \Phi_{21} = \colorbox{#e6994c}{\( M_{21} \)} \cdot i_1$ (Fluss in 2 durch Strom in 1)
*   Symmetrie: $M_{12} = M_{21} = M$

### Induktionsgesetz & Flussverkettung
Ein zeitlich veränderlicher Fluss induziert eine Spannung.
> [!IMPORTANT]
> **Vorzeichenkonvention:**
> *   **Erzeuger-System:** $u_{ind} = -N \frac{d\Phi}{dt}$ (Lenzsche Regel).
> *   **Verbraucher-System (Üblich in Netzwerkanalyse):** $u_{ind} = + L \cdot \frac{di}{dt}$.

Beim Transformator wird der Fluss durch einen <span style="color:#4c99e6">hochpermeablen Kern</span> geführt ("Eisenkern"), um die magnetische Kopplung zu maximieren.

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/TransformerConstructionandWind_te2j.excalidraw)
![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/MagneticFluxLinkageFeedbackLoo_AQUb.excalidraw)

> [!NOTE]
> **Wirkungsweise:** Ein Strom in der Primärspule erzeugt einen magnetischen Fluss, der durch den Kern zur Sekundärspule geleitet wird. Die Änderung dieses Flusses induziert in der Sekundärspule eine Spannung proportional zur Windungszahl und Flussänderung.

---

## 7.4 Der Verlustlose Transformator

Wir betrachten zwei magnetisch gekoppelte Spulen <span style="color:#4c99e6">ohne ohm'sche Widerstände</span>.

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/TransformatorModellmitmagnetis_65Hp.excalidraw)

Der Gesamtfluss setzt sich aus **Streufluss** ($\Phi_{\sigma}$) und **Kopplungsfluss** ($\Phi_{ij}$) zusammen:
*   $\Phi_1 = \Phi_{\sigma 1} + \Phi_{21}$
*   $\Phi_2 = \Phi_{\sigma 2} + \Phi_{12}$

### Mathematische Beschreibung (Matrixform)
Unter Verwendung komplexer Wechselgrößen ($\underline{u} = \underline{\hat{U}}e^{j\omega t}$) lauten die Transformatorgleichungen:

$$
\begin{pmatrix} \underline{U}_1 \\ \underline{U}_2 \end{pmatrix} = 
\begin{pmatrix} i\omega L_1 & i\omega M \\ i\omega M & i\omega L_2 \end{pmatrix}
\begin{pmatrix} \underline{I}_1 \\ \underline{I}_2 \end{pmatrix}
$$

### Kenngrößen der Kopplung

#### 1. Kopplungskonstante $k$
Ein Maß für die Qualität der magnetischen Kopplung ($0 \le k \le 1$).

$$
k^2 = \frac{M^2}{L_1 \cdot L_2} = \frac{\Phi_{21} \cdot \Phi_{12}}{\Phi_{11} \cdot \Phi_{22}}
$$

*   $k=1$: Perfekte Kopplung (keine Streuverluste).
*   $k=0$: Keine magnetische Kopplung.

#### 2. Übersetzungsverhältnis (Physikalisch)
Definiert über die Induktivitäten:
$$
\ddot{u}^2 = \frac{L_1}{L_2}
$$
Im Leerlauf ($\underline{I}_2=0$) ergibt sich das Spannungsverhältnis zu $\frac{\underline{U}_1}{\underline{U}_2} = \frac{\ddot{u}}{k}$. Nur bei perfekter Kopplung ($k=1$) ist dies identisch mit $\ddot{u}$.

### T-Ersatzschaltung
Um den Transformator in der Netzwerkanalyse ohne Transformatorgleichungen (nur mit Kirchhoff) zu berechnen, nutzt man die T-Ersatzschaltung:

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/TErsatzschaltung_FZ1m.excalidraw)

Die Induktivitäten werden dabei aufgeteilt in:
*   Längszweige: $L_1 - M$ und $L_2 - M$
*   Querzweig: $M$

> [!WARNING]
> Dieses Ersatzbild täuscht eine galvanische Kopplung vor und ist **nicht für Gleichstrom** geeignet.

> [!NOTE]
> **Wirkungsweise:** Der verlustlose Transformator wird durch ein Netzwerk aus drei Induktivitäten modelliert, welches das Klemmenverhalten (Spannungen und Ströme) korrekt abbildet, solange Wechselstrom betrachtet wird.

---

## 7.5 Der Verlustbehaftete Transformator

Reale Transformatoren weisen Energieverluste auf:
1.  **<span style="color:#4c4ce6">Kupferverluste:</span>** Ohm'sche Widerstände der Wicklungen ($R_{Cu}$).
2.  **<span style="color:#4c4ce6">Eisenverluste:</span>** Magnetisierungs- und Wirbelstromverluste im Kern.

### Modellierung mit reduzierten Größen
Zur Vereinfachung rechnet man alle Größen der Sekundärseite auf die Primärseite um. Man definiert "reduzierte" Größen (gekennzeichnet mit einem Strich $'$):

| Größe | Definition | Bedeutung |
| :--- | :--- | :--- |
| **Primäre Streuinduktivität** | $L_{1\sigma} = L_1 - \ddot{u}M = (1-k)L_1$ | Teil von $L_1$, der nicht koppelt. |
| **Primäre Hauptinduktivität** | $L_{1h} = \ddot{u} M = k L_1$ | Teil von $L_1$, der koppelt. |
| **Reduzierte Sekundärspannung** | $\underline{U}_2' = \ddot{u} \underline{U}_2$ | Spannung $U_2$ auf Primärniveau skaliert. |
| **Reduzierter Sekundärstrom** | $\underline{I}_2' = \frac{1}{\ddot{u}} \underline{I}_2$ | Strom $I_2$ auf Primärniveau skaliert. |
| **Reduzierte Impedanz** | $R'_{2Cu} = \ddot{u}^2 R_{2Cu}$ | Widerstand $R_2$ transformiert. |

### Ersatzschaltbild (Kupfer- & Streuverluste)

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/ErsatzschaltbildTransformator_di4X.excalidraw)

Die Spannungsgleichung der Primärseite lautet:
$$
\underline{U}_1 = R_{1Cu} \underline{I}_1 + i \omega L_{1\sigma} \underline{I}_1 + i \omega L_{1h} (\underline{I}_1 - \underline{I}_2')
$$

### Vollständiges Modell (inkl. Eisenverluste)
Berücksichtigt man auch die Hystereseverluste im Eisenkern, wird ein Parallelwiderstand $R_{Fe}$ (Eisenverlustwiderstand) zum Hauptinduktivitätszweig hinzugefügt:

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/ErsatzschaltbildTransformatorm_OnuF.excalidraw)

> [!NOTE]
> **Wirkungsweise:** Das reale Ersatzschaltbild bildet physikalische Unzulänglichkeiten (Widerstand des Drahtes, magnetische Streuung, Kernverluste) durch diskrete Bauteile ($R$, $L$) ab, um das genaue Betriebsverhalten unter Last simulieren zu können.

---

## 7.6 Allgemeiner Transformator mit beliebiger Last

Betrachtet wird ein Transformator, der sekundärseitig mit einer Impedanz $\underline{Z}_L$ abgeschlossen ist.

![](Skript_LEN_WiSe2526_Kapitel_07_ILIAS/SchaltplaneinesTransformatorsm_xp9I.excalidraw)

### Übertragungsfunktionen

Durch Einsetzen der Randbedingung $\underline{U}_2 = -\underline{Z}_L \cdot \underline{I}_2$ in die Transformatorgleichungen erhält man:

**1. Stromübersetzungsverhältnis:**
$$
\frac{\underline{I}_2}{\underline{I}_1} = - \frac{i \omega M}{R_2 + i \omega L_2 + \underline{Z}_L}
$$

**2. Eingangsimpedanz ($\underline{Z}_{ein}$):**
Die Last $\underline{Z}_L$ ist auf der Primärseite sichtbar als:
$$
\underline{Z}_{ein} = \frac{\underline{U}_1}{\underline{I}_1} = (R_1 + i \omega L_1) + \frac{\omega^2 M^2}{R_2 + i \omega L_2 + \underline{Z}_L}
$$

**3. Spannungsübersetzungsverhältnis:**
$$
\frac{\underline{U}_2}{\underline{U}_1} = \frac{i\omega M}{(R_1 + i\omega L_1)\left( \frac{R_2}{\underline{Z}_L} + \frac{i\omega L_2}{\underline{Z}_L} + 1 \right) + \frac{\omega^2 M^2}{\underline{Z}_L}}
$$

### Spezialfälle: Leerlauf und Kurzschluss

| Betriebsfall | Bedingung | Ergebnis (Näherung) |
| :--- | :--- | :--- |
| **Kurzschluss** | $\underline{U}_2 = 0$ bzw. $\underline{Z}_L = 0$ | **Stromübersetzung:** $\frac{\underline{I}_2}{\underline{I}_1} = - \frac{i\omega M}{R_2 + i\omega L_2}$<br>**Eingangsimpedanz:** $\underline{Z}_{in} = (R_1 + i\omega L_1) + \frac{\omega^2 M^2}{(R_2 + i\omega L_2)}$ |
| **Leerlauf** | $\underline{I}_2 = 0$ bzw. $\underline{Z}_L \to \infty$ | **Spannungsübersetzung:** $\frac{\underline{U}_2}{\underline{U}_1} = \frac{i\omega M}{R_1 + i\omega L_1}$<br>**Eingangsimpedanz:** $\underline{Z}_{in} = R_1 + i\omega L_1$ |

> [!NOTE]
> **Wirkungsweise:** Das Verhalten des Transformators (Eingangswiderstand, Spannungs-/Stromverhältnis) ist dynamisch und hängt stark von der angeschlossenen Last ab. Die Formeln erlauben die Berechnung dieser Größen unter Berücksichtigung aller internen Verluste.