# Elektrische Leistung

## 5.1 Wirk-, Schein- und Blindleistung

### 5.1.1 Herleitung der Momentanleistung

Erinnerung: In einem <span style="color:#4c99e6">Gleichstromnetzwerk</span> ist die in einem Zweipol umgesetzte Leistung eine konstante, vorzeichenbehaftete Größe:

$$
P = U \cdot I
$$

Bei Wechselstrom kann man die entsprechenden Überlegungen auf jedes kleine Zeitintervall $[t; t + \Delta t]$ übertragen. Man erhält damit die sog. <span style="color:#4c99e6">Augenblicksleistung oder Momentanleistung</span>:

$$
p(t) = u(t) \cdot i(t)
$$

#### Klassischer Ansatz (ohne komplexe Spannungen und Ströme)

Wir betrachten Spannung und Strom als Zeitfunktionen:

$$
\left.
\begin{aligned}
\text{Spannung: } u(t) &= \hat{U} \sin(\omega t + \varphi_{ui}) \\
\text{Strom: } \quad i(t) &= \hat{I} \sin(\omega t)
\end{aligned}
\right\} \rightarrow p(t) = \hat{U} \cdot \hat{I} \cdot \sin(\colorbox{#e64c4c}{\(\omega t + \varphi_{ui}\)}) \cdot \sin(\colorbox{#e6994c}{\(\omega t\)})
$$

Unter Verwendung des **Additionstheorems**:
$\sin \colorbox{#e64c4c}{\(\alpha\)} \cdot \sin \colorbox{#e6994c}{\(\beta\)} = \frac{1}{2} [\cos (\colorbox{#e64c4c}{\(\alpha\)} - \colorbox{#e6994c}{\(\beta\)}) - \cos (\colorbox{#e64c4c}{\(\alpha\)} + \colorbox{#e6994c}{\(\beta\)})]$

Ergibt sich für die Leistung:

$$
\begin{aligned}
\Rightarrow p(t) &= \hat{U} \cdot \hat{I} \cdot \frac{1}{2} [\cos(\colorbox{#e64c4c}{\(\omega t + \varphi_{ui}\)} - \colorbox{#e6994c}{\(\omega t\)}) - \cos(\colorbox{#e64c4c}{\(\omega t + \varphi_{ui}\)} + \colorbox{#e6994c}{\(\omega t\)})] \\
&= \frac{1}{2} \hat{U} \cdot \hat{I} \cdot [\cos(\varphi_{ui}) - \cos(2\omega t + \varphi_{ui})] \\
&= \underset{\textcolor{#4ce64c}{\text{konstant}}}{\frac{1}{2} \hat{U} \hat{I} \cos \varphi_{ui}} - \underset{\textcolor{#4ce64c}{\text{oszilliert mit Kreisfrequenz } 2\omega}}{\frac{1}{2} \hat{U} \hat{I} \cos(2\omega t + \varphi_{ui})}
\end{aligned}
$$

Zerlegung des oszillierenden Terms mittels **Additionstheorem**:
$\cos(\colorbox{#e64c4c}{\(\alpha\)} + \colorbox{#e6994c}{\(\beta\)}) = \cos \colorbox{#e64c4c}{\(\alpha\)} \cdot \cos \colorbox{#e6994c}{\(\beta\)} - \sin \colorbox{#e64c4c}{\(\alpha\)} \sin \colorbox{#e6994c}{\(\beta\)}$

$$
\begin{aligned}
\Rightarrow p(t) &= \frac{1}{2} \hat{U} \cdot \hat{I} [\cos \varphi_{ui} - \cos(\colorbox{#e64c4c}{\(2\omega t\)}) \cos(\colorbox{#e6994c}{\(\varphi_{ui}\)}) + \sin(\colorbox{#e64c4c}{\(2\omega t\)}) \sin(\colorbox{#e6994c}{\(\varphi_{ui}\)})] \\
&= \frac{1}{2} \hat{U} \hat{I} [\cos \varphi_{ui} (1 - \cos(\colorbox{#99e64c}{\(2\omega t\)})) + \sin(2\omega t) \sin(\varphi_{ui})]
\end{aligned}
$$

Umformung mittels **Halbwinkel-Beziehung**:
$\sin^2 \alpha = \frac{1}{2} [1 - \cos(2\alpha)] \iff 1 - \cos(\colorbox{#99e64c}{\(2\alpha\)}) = 2 \cdot \sin^2 \colorbox{#99e64c}{\(\alpha\)}$

Daraus folgt die finale Form der Momentanleistung:

$$
\begin{aligned}
\Rightarrow p(t) &= \frac{1}{2} \hat{U} \hat{I} [\cos \varphi_{ui} \cdot 2 \sin^2(\colorbox{#99e64c}{\(\omega t\)}) + \sin(\varphi_{ui}) \sin(2\omega t)] \\
&= 2 \cdot \frac{1}{2} \hat{U} \hat{I} \cos \varphi_{ui} \sin^2(\omega t) + \frac{1}{2} \hat{U} \hat{I} \sin \varphi_{ui} \sin(2\omega t)
\end{aligned}
$$

> [!NOTE]
> Die Momentanleistung im Wechselstromkreis ist zeitabhängig und schwingt mit der doppelten Netzfrequenz ($2\omega$). Durch mathematische Umformung wird sie in einen stets positiven Anteil (Wirkanteil) und einen um den Nullpunkt oszillierenden Anteil (Blindanteil) zerlegt.

### 5.1.2 Definition der Leistungsgrößen

Aus der obigen Rechnung heraus definiert man die folgenden zentralen Leistungsbegriffe:

**1. Wirkleistung ($P$)**
Zeitlich gemittelter Leistungsfluss aus einem Generator heraus bzw. in einen Verbraucher hinein.

$$
P = \overline{p(t)} = \frac{1}{\underset{\textcolor{#4ce64c}{\uparrow \text{ Periodendauer}}}{T}} \int_0^T p(t)dt = \frac{1}{T} \int_0^T \textcolor{#4ce64c}{\underbrace{\textcolor{black}{\frac{1}{2}\hat{U}\hat{I}\cos\varphi_{ui}}}_{\text{const}}} dt - \frac{1}{T} \int_0^T \textcolor{#4ce64c}{\underbrace{\textcolor{black}{\frac{1}{2}\hat{U}\hat{I}\cos(2\omega t + \varphi_{ui})}}_{\text{= 0}}} dt
$$

$$
= \frac{1}{2}\hat{U}\hat{I}\cos\varphi_{ui}
$$

*   **Einheit:** $[P] = 1 VA = 1 W$ <span style="color:#4ce64c">(Watt)</span>

**2. Blindleistung ($Q$)**
Amplitude der Leistung, die zwischen dem Erzeuger und dem Verbraucher oszilliert (kein dauerhafter Energieumsatz).

$$
Q = \frac{1}{2}\hat{U}\hat{I}\sin\varphi_{ui}
$$

*   **Einheit:** $[Q] = 1 VA = 1 var$

> [!IMPORTANT]
> <span style="color:#4ce64c">**Achtung:** Man verwendet hier typischerweise die Bezeichnung "var" (Volt-Ampere-Reaktiv).</span>

**3. Scheinleistung ($S$)**
Die Amplitude der oszillierenden Gesamtleistung. Die Augenblicksleistung oszilliert quasi um die Wirkleistung herum.

$$
S = \frac{1}{2}\hat{U}\hat{I}
$$

*   **Einheit:** $[S] = 1 VA$

> [!IMPORTANT]
> <span style="color:#4ce64c">**Achtung:** Man verwendet hier nicht die Abkürzung "Watt".</span>

**Zusammenfassende Darstellung der Momentanleistung:**

$$
p(t) = \textcolor{#4ce64c}{\underbrace{\textcolor{black}{2 P \sin^2(\omega t)}}_{\text{stets positiv}}} + \textcolor{#4ce64c}{\underbrace{\textcolor{black}{Q \sin(2\omega t)}}_{\text{oszilliert um Null}}}
$$

> [!NOTE]
> Die Wirkleistung ($P$) ist der energetisch nutzbare Anteil, der in andere Energieformen (z.B. Wärme, Licht) umgewandelt wird. Die Blindleistung ($Q$) repräsentiert Energie, die periodisch zwischen magnetischen/elektrischen Feldern und dem Netz hin- und herpendelt, ohne verbraucht zu werden.

### 5.1.3 Zusammenhang im Leistungsdreieck

Wir betrachten den geometrischen Zusammenhang:

$$
\sqrt{P^2 + Q^2} = \left[ \frac{1}{4}\hat{U}^2\hat{I}^2\cos^2\varphi_{ui} + \frac{1}{4}\hat{U}^2\hat{I}^2\sin^2\varphi_{ui} \right]^{1/2} = \sqrt{\frac{1}{4}\hat{U}^2\hat{I}^2} = \frac{1}{2}\hat{U}\hat{I} = S
$$

$\Rightarrow$ Wirkleistung, Blindleistung und Scheinleistung verhalten sich wie die Seiten eines rechtwinkligen Dreiecks (Satz des Pythagoras).

**Zeigerdiagramme:**

| Induktive Last | Kapazitive Last |
| :--- | :--- |
| ![](Skript_LEN_WiSe2526_Kapitel_05_ILIAS/ZeigerdiagrammInduktiveLast_KrjI.excalidraw) | ![](Skript_LEN_WiSe2526_Kapitel_05_ILIAS/ZeigerdiagrammKapazitiveLast_xg4i.excalidraw) |
| $\varphi_{ui} > 0 \rightarrow Q > 0$ | $\varphi_{ui} < 0 \rightarrow Q < 0$ |

**Graphische Zusammenfassung aller Leistungsgrößen:**

![](Skript_LEN_WiSe2526_Kapitel_05_ILIAS/ZeitverlaufvonLeistungptSpannu_71KS.excalidraw)

> [!NOTE]
> Das Leistungsdreieck visualisiert den Pythagoras-Zusammenhang $S^2 = P^2 + Q^2$. Der Winkel $\varphi_{ui}$ bestimmt das Verhältnis von Wirk- zu Blindleistung (Leistungsfaktor $\cos \varphi$).

## 5.2 Effektivwerte von Leistungen

**Erinnerung:**

*   Leistung an Widerstand für Gleichstrom:
    $$P = U \cdot I$$
*   Wirkleistung an Widerstand für Wechselstrom:
    $$P = \frac{1}{2}\hat{U}\hat{I} \, , \quad \text{da } \varphi_{ui} = 0$$

> <span style="color:#e64c4c">$\leftarrow$ Dies ist physikalisch die "gleiche" Größe, aber durch unterschiedliche Definitionen von U und I entstehen offensichtlich zwei verschiedene Formeln.</span>

$\Rightarrow$ Definition von <span style="color:#4c4ce6">Effektivwerten</span> (für sinusförmige Wechselspannungen), um die Formeln anzugleichen:

$$
U_{eff} = \frac{\hat{U}}{\sqrt{2}} \ ; \ I_{eff} = \frac{\hat{I}}{\sqrt{2}}
$$

<span style="color:#4ce64c">Bemerkung: Der Index "eff" wird in der Praxis oft weggelassen; wenn bei Wechselstromgrößen keine Kennzeichnung (Dach) steht, ist meist der Effektivwert gemeint.</span>

Daraus folgen die Leistungsformeln mit Effektivwerten:

$$
\left.\begin{aligned}
\rightarrow \quad P &= U \cdot I \cdot \cos \varphi_{ui} && \textcolor{#4c4ce6}{\text{Wirkleistung} \ , \ [P]=1\text{W}} \\
Q &= U \cdot I \cdot \sin \varphi_{ui} && \textcolor{#4c4ce6}{\text{Blindleistung} \ , \ [Q]=1\text{var}} \\
S &= U \cdot I && \textcolor{#4c4ce6}{\text{Scheinleistung} \ , \ [S]=1\text{VA}}
\end{aligned} \right\} \textcolor{#4ce64c}{\begin{aligned} \\ \text{hier werden Effektiv-} \\ \text{werte verwendet} \end{aligned}}
$$

> [!NOTE]
> Effektivwerte sind quadratische Mittelwerte einer Wechselgröße. Sie sind so definiert, dass sie an einem ohmschen Widerstand im zeitlichen Mittel die gleiche thermische Leistung (Wärme) erzeugen wie ein gleich großer Gleichstrom.

## 5.3 Komplexe Leistung

**Definition:** <span style="color:#4c99e6">Komplexer Leistungszeiger</span>

Man nutzt die komplexe Rechnung, um Wirk- und Blindleistung in einer einzigen Größe zusammenzufassen.

$$
\underline{S} = \underline{U} \cdot \underline{I}^*
$$

<span style="color:#4ce64c">Bemerkung: Hier werden wieder Effektivwerte verwendet. Der Stern ($^*$) kennzeichnet das konjugiert Komplexe.</span>

Herleitung der Komponenten:

$$
\begin{aligned}
\underline{S} &= U e^{i \varphi_u} \cdot I e^{-i \varphi_i} = U \cdot I \cdot e^{i(\varphi_u - \varphi_i)} \\
&= \underline{U I \cos \varphi_{ui}} + i \underline{U I \sin \varphi_{ui}} \\
&= P + i Q
\end{aligned}
$$

Daraus folgt die Zuordnung:
*   $Re(\underline{S}) = P \quad \textcolor{#4c99e6}{\text{(Wirkleistung)}}$
*   $Im(\underline{S}) = Q \quad \textcolor{#4c99e6}{\text{(Blindleistung)}}$
*   $|\underline{S}| = \sqrt{P^2 + Q^2} = S \quad \textcolor{#4c99e6}{\text{(Scheinleistung)}}$

### 5.3.1 Zusammenhang mit Impedanz und Admittanz

Für Gleichstrom gilt die Beziehung $P = U \cdot I = \frac{U^2}{R} = R \cdot I^2$ (Ohmsches Gesetz). In der konventionellen Schreibweise gilt diese Beziehung für Wechselstrom nicht, da Spannung und Strom gegeneinander phasenverschoben sind. Mit den komplexen Größen kann diese Struktur jedoch wiederhergestellt werden:

$$
\begin{aligned}
\underline{S} &= \underline{U} \cdot \underline{I}^* = \underline{Z} \cdot \underline{I} \cdot \underline{I}^* = \underline{Z} \cdot |\underline{I}|^2 = \underline{Z} \cdot I^2 \\
&= \underline{U} \cdot \underline{U}^* \cdot \underline{Y}^* = \underline{Y}^* \cdot |\underline{U}|^2 = \underline{Y}^* \cdot U^2
\end{aligned}
$$

Aufgetrennt nach Real- und Imaginärteil erhält man damit folgende Übersicht:

| Impedanz $\underline{Z} = R + iX$ | Admittanz $\underline{Y} = G + iB$ |
| :--- | :--- |
| **Wirkleistung** <br> $P = Re(\underline{S}) = R \cdot I^2$ | **Wirkleistung** <br> $P = Re(\underline{S}) = G \cdot U^2$ |
| **Blindleistung** <br> $Q = Im(\underline{S}) = X \cdot I^2$ | **Blindleistung** <br> $Q = Im(\underline{S}) = -B \cdot U^2$ |
| **Scheinleistung** <br> $S = |\underline{S}| = \sqrt{R^2 + X^2} \cdot I^2$ | **Scheinleistung** <br> $S = |\underline{S}| = \sqrt{G^2 + B^2} \cdot U^2$ |

> [!NOTE]
> Die komplexe Leistung $\underline{S}$ vereinigt die Information über Energieumsatz (Realteil) und Energiespeicherung (Imaginärteil). Durch die Verwendung des konjugierten Stroms $\underline{I}^*$ wird sichergestellt, dass der Imaginärteil bei induktiver Last positiv (und bei kapazitiver Last negativ) ist, passend zur Konvention im Leistungsdreieck.