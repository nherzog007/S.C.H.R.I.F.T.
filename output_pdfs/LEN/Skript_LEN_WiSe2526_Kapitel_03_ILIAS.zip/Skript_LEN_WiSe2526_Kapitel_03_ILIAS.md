# Skript_LEN_WiSe2526_Kapitel_03_ILIAS

## 3. Grundlagen und Modellierung des Operationsverstärkers

### 3.1 Ein- und Ausgangsgrößen

#### Darstellung und Nomenklatur
Das Schaltsymbol und die Pinbelegung visualisieren die Schnittstellen des Bauteils.

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/PinbelegungOperationsverstrker_tQKZ.excalidraw)

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/SchaltsymbolOperationsverstrke_YiRN.excalidraw)

**Nomenklatur der Anschlüsse:**

| Bezeichnung | Symbol | Bedeutung / Funktion |
| :--- | :--- | :--- |
| **N-Eingang** | $-$ | Invertierender Eingang |
| **P-Eingang** | $+$ | Nicht-invertierender Eingang |
| **Versorgung** | $V^+, V^-$ | Positive / negative Versorgungsspannung |
| **Ausgang** | Output | Ausgangssignal |
| **Offset** | Offset | Nullabgleich |
| **NC** | NC | "Not Connected" (nicht belegt) |

> [!NOTE]
> In vielen Schaltungen / Schaltplänen wird aus Gründen der Übersichtlichkeit die Versorgungsspannung $V^+, V^-$ nicht eingezeichnet.

#### Grundschaltung und Übertragungskennlinie

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/GrundschaltungOperationsverstr_BHIf.excalidraw)

*   $\textcolor{#4c4ce6}{U_d \hat{=} \text{Differenzspannung}} \rightarrow U_d = +U_p - U_n$
*   Alle Spannungen sind gegenüber Bezugspotential ("Masse") angegeben.

Die Kennlinie dieser Grundschaltung (Annahme: Versorgungsspannung $\pm 12V$) zeigt das Übertragungsverhalten:

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/KennlinieGrundschaltungUavsUd_vcfQ.excalidraw)

*   **Linearer Bereich:** Um den Nullpunkt existiert ein <span style="color:#4c4ce6">linearer Bereich</span>, in dem die Ausgangsspannung proportional zur Differenzspannung ist.
*   **Sättigungsbereich:** Für "hohe" Differenzspannungen <span style="color:#4c4ce6">sättigt</span> die Kennlinie; die Ausgangsspannung nimmt den Wert der positiven/negativen Versorgungsspannung an.
*   **Offset:** Eine Verschiebung der Kennlinie entlang der y-Achse wird als <span style="color:#e6994c">Offset</span> bezeichnet.

Innerhalb des linearen Bereichs definiert man die <span style="color:#4c99e6">Differenzverstärkung</span> (<span style="color:#4c99e6">open-loop gain</span>):
$$ A = \frac{\Delta U_a}{\Delta U_d} = \frac{dU_A}{dU_d} \quad ; \quad \text{typische Werte} : A \sim 10^5 $$

#### Ersatzschaltbild

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/ErsatzschaltbildeinesOperation_eAYy.excalidraw)

**Eigenschaften des idealen Operationsverstärkers:**
1.  $U_d = 0 \longrightarrow U_a = 0$
2.  $R_d \longrightarrow \infty$ (Sehr hoher <span style="color:#4c99e6">Eingangswiderstand</span>)
3.  $R_a \longrightarrow 0$ (Verschwindend kleiner <span style="color:#4c99e6">Ausgangswiderstand</span>)
    $\textcolor{#4c99e6}{\longrightarrow OP = \text{ideale Spannungsquelle}}$

> [!NOTE]
> **Wirkungsweise:** Ein Operationsverstärker verstärkt die Differenzspannung zwischen den Eingängen mit einem extrem hohen Faktor ($A$), wobei idealerweise kein Strom in die Eingänge fließt und der Ausgangswiderstand null ist.

---

### 3.2 Prinzip der Gegenkopplung

Der lineare Bereich der Grundschaltung ist für praktische Anwendungen zu klein. Durch eine <span style="color:#4c4ce6">Rückkopplung / Gegenkopplung</span> (Verbindung des Ausgangs mit dem *invertierenden* Eingang) wird das Verhalten stabilisiert.

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/InvertierenderVerstrkerSchaltp_qIcF.excalidraw)

#### Herleitung des Spannungsverhältnisses

**Ausgangslage:**
Es ist $U_a = A \cdot (U_p - U_n) = - A \cdot U_n$, da $U_p = 0$. Dies folgt aus den Eigenschaften des OPV sowie der Verbindung des P-Eingangs mit Masse.

**Knotenregel am Knoten $\textcolor{#e6994c}{k}$ (N-Eingang):**

$$ \frac{U_e - U_n}{R_1} + \frac{U_a - U_n}{R_N} = 0 $$

Da der Eingangswiderstand $R_d$ eines idealen OPV unendlich ist ($\textcolor{#4ce64c}{R_d \to \infty}$), fließt kein Strom in den N-Eingang.

$$ \Leftrightarrow \quad \frac{U_e + \frac{U_a}{A}}{R_1} + \frac{U_a + \frac{U_a}{A}}{R_N} = 0 $$

$$ \Leftrightarrow \quad \frac{1}{R_1 R_N} \left[ U_e R_N + \frac{U_a R_N}{A} + U_a \cdot R_1 + \frac{U_a R_1}{A} \right] = 0 $$

$$ \Leftrightarrow \quad U_e R_N = - U_a \left( \frac{R_N}{A} + R_1 + \frac{R_1}{A} \right) $$

$$ \Leftrightarrow \quad \frac{U_a}{U_e} = - \frac{R_N}{R_1} \textcolor{#4ce64c}{\underbrace{\textcolor{black}{\left[ 1 + \frac{1}{A} \frac{R_N + R_1}{R_1} \right]}}_{\approx 1 \text{ für } A \gg \frac{R_N+R_1}{R_1}}}^{-1} $$

**Ergebnis:**
$$ \Rightarrow \quad \frac{U_a}{U_e} = - \frac{R_N}{R_1} $$

Die Ausgangsspannung $U_a$ hängt nur von der Eingangsspannung $U_e$ ab, nicht von der Differenzspannung $U_d$. Dies impliziert $U_d \approx 0$.

> [!IMPORTANT]
> **Merksatz:** Die Gegenkopplung bewirkt, dass die Differenzspannung $U_d$ am Eingang des Operationsverstärkers einen sehr kleinen Wert annimmt. Vereinfacht nimmt man typischerweise <span style="color:#4c99e6">$U_d = 0$</span> an.

#### Analyse mit virtueller Masse ($U_d = 0$)

Wir betrachten die Schaltung erneut unter der Annahme $U_d = 0$:

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/InvertierenderVerstrkermitMasc_4IfI.excalidraw)

1.  **<span style="color:#4ce64c">Linke Masche</span>:** $-U_e + R_1 I_1 - U_d = 0 \quad \xrightarrow{U_d=0} \quad I_1 = \frac{U_e}{R_1}$
2.  **<span style="color:#e64c4c">Rechte Masche</span>:** $+U_d + R_N \cdot I_1 + U_a = 0$

Einsetzen von (1) in (2):
$$ U_a = - R_N \cdot I_1 - U_d = - R_N \cdot \frac{U_e}{R_1} = - \frac{R_N}{R_1} \cdot U_e $$

**Zusammenfassung:**
1.  Ein gegengekoppelter Operationsverstärker ist hier ein <span style="color:#4c99e6">invertierender Verstärker</span>.
2.  Das Spannungsverhältnis $\frac{U_a}{U_e}$ ist <span style="color:#4c99e6">unabhängig</span> von der Differenzverstärkung $A$.
3.  Die Verstärkung wird allein durch die <span style="color:#4c99e6">äußere Beschaltung</span> bestimmt.

> [!NOTE]
> **Wirkungsweise:** Die Gegenkopplung führt einen Teil der Ausgangsspannung so auf den Eingang zurück, dass die Differenzspannung an den Eingängen minimiert wird ("virtueller Kurzschluss"), was eine stabile, durch Widerstände einstellbare Verstärkung ermöglicht.

---

### 3.3 Goldene Regeln für den Operationsverstärker

Für die Analyse von analogen Schaltungen mit <span style="color:#4c99e6">gegengekoppelten Operationsverstärkern</span> gelten folgende Axiome:

1.  **Spannung:** Die Potentialdifferenz am Eingang verschwindet: $\textcolor{#4c99e6}{U_d \approx 0}$.
2.  **Strom:** In die Eingänge fließen keine Ströme hinein ($I_n = I_p = 0$).
3.  **Analyse:** Maschen- und Knotengleichungen gelten unter Einhaltung von 1.) und 2.).
4.  **Topologie:** Durch einen Operationsverstärker darf unter keinen Umständen eine Masche gelegt werden (siehe Ersatzschaltbild).

#### Erlaubte vs. Verbotene Maschen

**Erlaubt:**
![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/ErlaubteMasche1Eingangsschleif_gLnQ.excalidraw)
![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/ErlaubteMasche2Rckkopplungssch_8Dnm.excalidraw)
![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/ErlaubteMasche3Ausgangsschleif_Jwzy.excalidraw)

**Verboten:**
![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/VerboteneMasche1DurchEingang_07VS.excalidraw)
![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/VerboteneMasche2DurchOPVIntern_NSGa.excalidraw)

<span style="color:#4c99e6">Anhand des Ersatzschaltbilds (Abschnitt 3.1) lässt sich herleiten, warum interne Maschen physikalisch nicht sinnvoll definiert werden können.</span>

> [!NOTE]
> **Wirkungsweise:** Diese Regeln vereinfachen die Berechnung komplexer OPV-Schaltungen drastisch, indem sie den OPV als ideales Bauteil behandeln, das die Eingangsspannungsdifferenz ausregelt, ohne den Signalknoten Strom zu entnehmen.

---

## 4. Lineare Grundschaltungen

### 3.4 Invertierender Addierer

Diese Schaltung summiert mehrere gewichtete Eingangsspannungen.

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/SchaltplaneinesinvertierendenA_NLgg.excalidraw)

**Analyse:**
Knotenregel am Knoten KN:
$$ \frac{U_1-U_N}{R_1} + \frac{U_2-U_N}{R_2} + \frac{U_3-U_N}{R_3} + \frac{U_a-U_N}{R_N} = 0 $$

Da $U_d = U_P - U_N = -U_N \stackrel{!}{=} 0$ (virtuelle Masse):

$$ \Rightarrow U_a = - \left( \frac{R_N}{R_1} U_1 + \frac{R_N}{R_2} U_2 + \frac{R_N}{R_3} U_3 \right) $$

**Spezialfälle:**
*   Bei gleichen Eingangswiderständen ($R_1=R_2=R_3=R$):
    $$ U_a = - \frac{R_N}{R} (U_1 + U_2 + U_3) $$
*   Bei $R_N=R$:
    $$ U_a = - (U_1 + U_2 + U_3) $$

> [!NOTE]
> **Wirkungsweise:** Die Schaltung addiert die Ströme der einzelnen Eingangszweige im Knotenpunkt vor dem invertierenden Eingang und wandelt die Summe in eine invertierte Ausgangsspannung um.

---

### 3.5 Stromgesteuerte invertierende Spannungsquelle (Transimpedanzverstärker)

Diese Schaltung wandelt einen Eingangsstrom in eine proportionale Spannung.

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/StromgesteuerteinvertierendeSp_IjjI.excalidraw)

**Analyse:**
Maschengleichung ($\textcolor{#e64c4c}{\text{rote Masche}}$):
$$ U_d + R_N \cdot I_1 + U_a = R_N \cdot I_1 + U_a = 0 $$

$$ \hookrightarrow U_a = - R_N \cdot I_1 $$

Für $R_1 \gg R_N + R_L$ gilt (nach Stromteilerregel): $I_1 \approx I_q$.
$$ \Rightarrow U_a = -R_N \cdot I_q $$

**Anwendung:** Auslesen von Fotodioden.

> [!NOTE]
> **Wirkungsweise:** Der Operationsverstärker zwingt den gesamten Eingangsstrom durch den Rückkopplungswiderstand $R_N$, wodurch am Ausgang eine Spannung entsteht, die direkt proportional zum Strom ist (Strom-Spannungs-Wandlung).

---

### 3.6 Spannungsfolger (Impedanzwandler)

Eine Schaltung mit Verstärkung 1, die zur Entkopplung dient.

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/SchaltungeinesSpannungsfolgers_c7ou.excalidraw)

**Analyse:**
$$ -U_e + U_d + U_a = -U_e + U_a = 0 \quad (\text{da } U_d \approx 0) $$
$$ \hookrightarrow U_a = U_e $$
Die Ausgangsspannung folgt exakt der Eingangsspannung.

#### Motivation: Vergleich mit belasteter Spannungsquelle

**Fall 1: Lineare Spannungsquelle mit Last (ohne OPV)**

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/LineareSpannungsquellemitLastw_xT2p.excalidraw)

Maschengleichung: $-U_e + R_i \cdot I + R_L \cdot I = 0$
$$ \hookrightarrow I = \frac{U_e}{R_i + R_L} \rightarrow U_a = R_L \cdot I = \frac{R_L}{R_i + R_L} \cdot U_e $$
$\Rightarrow$ Die Ausgangsspannung bricht bei Belastung ein (Spannungsteiler), besonders stark wenn $R_i \approx R_L$.

**Fall 2: Mit nachgeschaltetem Spannungsfolger**

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/LineareSpannungsquellemitnachf_vAKy.excalidraw)

Maschengleichung: $-U_e + R_i \cdot I + U_d + U_a = 0$
Da $I \approx 0$ (Eingangsstrom OPV) und $U_d \approx 0$:
$$ U_a = U_e \quad (\text{unabhängig von } R_L) $$

$\Rightarrow$ Der Spannungsfolger wirkt als <span style="color:#4c99e6">Impedanzwandler</span>: Er transformiert den Innenwiderstand der Quelle virtuell auf $R_i \approx 0$.

> [!NOTE]
> **Wirkungsweise:** Der Spannungsfolger belastet die Signalquelle nicht (hoher Eingangswiderstand), kann aber am Ausgang Strom liefern (niedriger Ausgangswiderstand), wodurch die Signalspannung unverfälscht an die Last weitergegeben wird.

---

### 3.7 Nichtinvertierender Verstärker

Verstärkt eine Spannung ohne Vorzeichenumkehr.

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/Schaltplaneinesnichtinvertiere_2Cg5.excalidraw)

**Analyse:**

1.  $\colorbox{#e6994c}{\( (M1) \)} \quad - U_e + U_d + R_2 \cdot I_2 = - U_e + R_2 I_2 = 0$
    $\hookrightarrow U_e = R_2 \cdot I_2 \iff I_2 = \frac{U_e}{R_2}$

2.  $\colorbox{#4ce699}{\( (M2) \)} \quad - I_2 R_2 - I_1 R_1 + U_a = 0$
    $\hookrightarrow U_a = (R_1 + R_2) I_2 \quad , \text{ da } I_1 = I_2$

**Ergebnis:**
$$ U_a = (R_1 + R_2) \cdot \frac{U_e}{R_2} = \frac{R_1 + R_2}{R_2} U_e = \left( 1 + \frac{R_1}{R_2} \right) U_e $$

Die Verstärkung ist stets $\ge 1$.

> [!NOTE]
> **Wirkungsweise:** Die Eingangsspannung liegt direkt am nicht-invertierenden Eingang. Die Rückkopplung stellt sicher, dass am invertierenden Eingang dieselbe Spannung anliegt, was einen definierten Strom durch $R_2$ und $R_1$ erzwingt und somit die verstärkte Ausgangsspannung erzeugt.

---

### 3.8 Differenzverstärker

Verstärkt die Differenz zweier Eingangsspannungen.

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/Differenzverstrkerschaltungmit_oXHV.excalidraw)

**Analyse:**
Es gelten folgende Maschen (kein Stromfluss in OPV-Eingänge):
*   <span style="color:#e64c4c">Rote Masche (M1):</span> $-U_{e1} + R_1 I_1 + R_3 I_1 + U_a = 0$
*   <span style="color:#4c99e6">Blaue Masche (M2):</span> $-U_{e1} + R_1 I_1 + R_4 \cdot I_2 = 0$
*   <span style="color:#4ce64c">Grüne Masche (M3):</span> $-U_{e2} + R_2 I_2 + R_4 \cdot I_2 = 0$

Aus (M3) folgt $I_2$:
$$ I_2 = \frac{U_{e2}}{R_2+R_4} $$

Einsetzen in (M2) liefert $I_1$:
$$ -U_{e1} + R_1 I_1 + \frac{R_4}{R_2+R_4} \cdot U_{e2} = 0 \quad \hookrightarrow \quad I_1 = \frac{U_{e1}}{R_1} - \frac{R_4}{R_1} \frac{U_{e2}}{R_2+R_4} $$

Einsetzen von $I_1$ in (M1) zur Bestimmung von $U_a$:
$$
\begin{aligned}
-U_{e1} + (R_1+R_3) \left( \frac{U_{e1}}{R_1} - \frac{R_4}{R_1} \frac{U_{e2}}{R_2+R_4} \right) + U_a &= 0 \\
\dots \text{ (Zwischenschritte siehe Herleitung)} \dots \\
U_a &= - \frac{R_3}{R_1} U_{e1} + \frac{R_3}{R_1} \frac{R_4 R_1 + R_4 R_3}{R_3 R_2 + R_3 R_4} U_{e2}
\end{aligned}
$$

**Symmetriebedingung:**
Wählt man die Widerstände so, dass $\frac{R_1}{R_3} = \frac{R_2}{R_4}$ (bzw. $R_1 R_4 = R_2 R_3$), vereinfacht sich der Term:

$$ U_a = \frac{R_3}{R_1} \left( U_{e2} - U_{e1} \right) $$

> [!NOTE]
> **Wirkungsweise:** Bei Einhaltung der Widerstandssymmetrie eliminiert diese Schaltung Gleichtaktsignale (Spannungen, die an beiden Eingängen gleich auftreten) und verstärkt ausschließlich die Spannungsdifferenz zwischen den Eingängen.

---

### 3.9 Spannungsgesteuerte Stromquelle

Diese Schaltung liefert einen konstanten Ausgangsstrom $I_2$, der proportional zur Eingangsspannung $U_1$ ist.

![](Skript_LEN_WiSe2526_Kapitel_03_ILIAS/Schaltungderspannungsgesteuert_oEg5.excalidraw)

**Analyse:**
Da $U_d \approx 0$, gilt $U_p \approx U_n = U$.

**Knotengleichungen:**
1.  $\textcolor{#e64c4c}{(KP):} \quad \frac{U_1 - U_p}{R_1 + R_2} + \frac{U_2 - U_p}{R_3} = 0$
2.  $\textcolor{#e6994c}{(KN):} \quad \frac{U_a - U_n}{R_2} - \frac{U_n}{R_3} = 0$
3.  $\textcolor{#4ce64c}{(KA):} \quad \frac{U_a - U_2}{R_1} + \frac{U_p - U_2}{R_3} - I_2 = 0$

Durch Auflösen des Gleichungssystems (siehe ausführliche Herleitung im Quelltext) erhält man für den Strom $I_2$:

$$ I_2 = \frac{U_1}{R_1} + U_2 \frac{R_2 - R_3}{R_1 R_3} $$

**Bedingung für ideale Stromquelle:**
Wählt man $R_2 = R_3$, entfällt der zweite Term:

$$ I_2 = \frac{U_1}{R_1} $$

Der Ausgangsstrom ist nun <span style="color:#4c99e6">unabhängig</span> von der Ausgangsspannung $U_2$ (Lastspannung).

> [!NOTE]
> **Wirkungsweise:** Durch eine geschickte Kombination von positiver und negativer Rückkopplung wird der Ausgangswiderstand der Schaltung theoretisch unendlich groß, sodass sie als ideale Stromquelle wirkt, gesteuert durch die Spannung $U_1$.