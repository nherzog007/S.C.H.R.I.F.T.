# Skript_LEN_WiSe2526_Kapitel_06_ILIAS

## 6. Ortskurven

> [!NOTE]
> **Wirkungsweise:** Eine Ortskurve visualisiert den Verlauf einer komplexen Größe (z. B. Impedanz) in der gaußschen Zahlenebene in Abhängigkeit eines variablen, reellen Parameters (meist der Kreisfrequenz $\omega$).

### Definition und Konzept
Eine <span style="color:#4c99e6">Ortskurve</span> bezeichnet eine Kurve, auf der alle Punkte einer <span style="color:#4c99e6">Funktionenschar</span> liegen, die eine bestimmte Eigenschaft erfüllen.

$\Rightarrow$ In einem <span style="color:#4c99e6">Sinusstromnetzwerk</span> erhält man eine Ortskurve, in dem man eine <span style="color:#4c99e6">komplexe Größe</span> als Funktion eines reellen Parameters aufträgt.

**Beispiele:**
$\underline{Z}(\omega), \underline{Y}(\omega), \underline{J}(\omega), \underline{U}(\omega), \dots$

**Bildliche Interpretation:**
Für jeden beliebigen Wert des Parameters trägt man in die komplexe Ebene der gesuchten Größe den zugehörigen Pfeil ein. Die Kurve, die die Pfeilspitzen beschreiben, entsprechen dann der Ortskurve.

---

## 6.1 Ortskurven der Impedanz und Admittanz (R, L, C)

> [!NOTE]
> **Wirkungsweise:** Bei elementaren RLC-Schaltungen ergeben sich charakteristische geometrische Formen (Geraden oder Kreise) für Impedanz und Admittanz, wobei die Lage auf der Kurve durch das Verhältnis von Frequenz zu den Bauteilwerten bestimmt wird.

Wir betrachten hier zunächst nur einige sehr einfache Beispiele, die das Konzept der Ortskurven verdeutlichen. In späteren Kapiteln zu Schwingkreisen etc. nehmen Ortskurven dann eine ganz zentrale Rolle ein.

### 6.1.1 Serienschaltung aus R und L

![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/RLSeriesCircuit_elld.excalidraw)

**Impedanz der Schaltung:**
$$
\underline{Z} = R + i\omega L \quad \rightarrow \quad \text{Re } \underline{Z} = R \, ; \, \text{Im } \underline{Z} = \omega L
$$

$\Rightarrow$
![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/ImpedanceLocusCurvePlot_EJBF.excalidraw)

#### Deutung der Ortskurve

*   **Winkel:** Der Winkel des Zeigers von $\underline{Z}$ zur reellen Achse entspricht der <span style="color:#4c99e6">Phasendifferenz $\textcolor{#4c99e6}{\varphi_{ui}}$</span> zwischen Strom und Spannung.
*   **Länge:** Die Länge des Zeigers $|\underline{Z}|$ entspricht dem Faktor zwischen den Amplituden von Strom und Spannung:
    $$
    \hat{U} = |\underline{Z}| \cdot \hat{J}
    $$

**Grenzbetrachtung:**

| Frequenzbereich | Phasenbeziehung ($\varphi_{ui}$) | Amplitudenverhältnis |
| :--- | :--- | :--- |
| **$\omega = 0$** | $0$ (Strom u. Spg. in Phase) | $\hat{U} = R \cdot \hat{I}$ |
| **$\omega \to \infty$** | $\to +\frac{\pi}{2}$ (Phasenverschoben) | $\hat{I} \to 0$ (bei gegebener Spg.)<br>$\hat{U} \to \infty$ (bei gegebenem Strom) |

#### Charakteristische Frequenz (RL-Serie)
Die <span style="color:#4c99e6">Charakteristische Frequenz</span> ist die Frequenz $\omega_0$, bei der die Phasenverschiebung $+\frac{\pi}{4}$ beträgt.

![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/ImpedanzOrtskurveRL_oIUT.excalidraw)

Für $\varphi_{ui} = +\frac{\pi}{4}$ gilt:
$$
\text{Im } \underline{Z} = \text{Re } \underline{Z} \quad \to \quad \omega_0 \cdot L = R \quad \to \quad \omega_0 = \frac{R}{L}
$$
$$
\Rightarrow \underline{Z} (\omega = \omega_0) = R + i R \quad \hookrightarrow \quad |\underline{Z}| = \sqrt{2} \cdot R
$$

> [!WARNING]
> **Bemerkung:** Die charakteristische Frequenz $\omega_0$ für die einfachen Schaltungen aus R, L und C darf nicht mit der Resonanzfrequenz $\omega_0$ von Schwingkreisen verwechselt werden.

---

### 6.1.2 Serienschaltung aus R und C

![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/SerienschaltungRC_7ULy.excalidraw)

**Impedanz der Schaltung:**
$$
\underline{Z} = R + \frac{1}{i\omega C} = R - i \frac{1}{\omega C}
$$
$$
\hookrightarrow \text{Re } \underline{Z} = R \quad ; \quad \text{Im } \underline{Z} = -\frac{1}{\omega C}
$$

$\Rightarrow$
![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/ImpedanzOrtskurveRC_3scZ.excalidraw)

#### Deutung der Ortskurve

*   **Phasendifferenz:** Zwischen Strom und Spannung immer negativ; sie geht bei $\omega \to \infty$ gegen Null:
    *   $\varphi_{ui} < 0$ für alle Kreisfrequenzen $\omega$
    *   $\varphi_{ui} \to 0$ für $\omega \to \infty$
*   **Amplitude:** Ist die Amplitude der Spannung vorgegeben, so wird die Amplitude des Stroms kleiner, je kleiner die Frequenz wird. Schließlich gilt:
    *   $\hat{U} = R \cdot \hat{I} \quad \text{für } \omega \to \infty$
*   **Grenzfall Null:** Für $\omega \to 0$ nimmt die Phasendifferenz den Wert $\varphi_{ui} = -\frac{\pi}{2}$ an.

#### Charakteristische Frequenz (RC-Serie)
Bedingung: $\varphi_{ui} = -\frac{\pi}{4} \rightarrow \text{Re } \underline{Z} = \text{Im } \underline{Z}$
$$
\Rightarrow R = \frac{1}{\omega_0 C} \quad \rightarrow \quad \omega_0 = \frac{1}{RC} \quad \rightarrow \quad \hat{U} = \sqrt{2} \cdot R \cdot \hat{I}
$$

---

### 6.1.3 Parallelschaltung aus R und C

![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/ParallelschaltungausRundC_kgDT.excalidraw)

*   **Admittanz:** $\underline{Y} = \frac{1}{R} + i\omega C$
*   **Impedanz:** $\underline{Z} = \frac{1}{\frac{1}{R} + i\omega C}$

![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/OrtskurvederAdmittanz_SilY.excalidraw)

#### Herleitung der Kreisform (Impedanz)
**Frage:** Wie sieht die Ortskurve der Impedanz aus?

$$
\underline{Z} = \frac{1}{\frac{1}{R} + i\omega C} = \frac{\frac{1}{R} - i\omega C}{(\frac{1}{R} + i\omega C)(\frac{1}{R} - i\omega C)} = \frac{\frac{1}{R} - i\omega C}{(\frac{1}{R})^2 + \omega^2 C^2}
$$

Aufspaltung in Real- und Imaginärteil ($x(\omega)$ und $y(\omega)$):
$$
= \textcolor{#4c4ce6}{\underbrace{\textcolor{#4d4d4d}{\frac{\frac{1}{R}}{(\frac{1}{R})^2 + \omega^2 C^2}}}_{= \text{Re } \underline{Z} =: x(\omega)}} + i \textcolor{#4c4ce6}{\underbrace{\textcolor{#4d4d4d}{\frac{-\omega C}{(\frac{1}{R})^2 + \omega^2 C^2}}}_{= \text{Im } \underline{Z} =: y(\omega)}}
$$

**Darstellung eines Kreises:**
Allgemeine Form: $(x-x_0)^2 + (y-y_0)^2 = r^2$
<span style="color:#4ce64c">mit $(x_0, y_0) \hat{=}$ Koordinaten des Mittelpunkts des Kreises, $r \hat{=}$ Radius.</span>

**Behauptung:**
Die Ortskurve der Impedanz entspricht einem Kreis um den Mittelpunkt $M=(R/2 \mid 0)$ mit dem Radius $R/2$:
$$
\left[ X(\omega) - \frac{R}{2} \right]^2 + Y^2(\omega) = \frac{R^2}{4} \quad \textcolor{#e64c4c}{(*)}
$$

**Beweis:**
Definiere $\alpha = (\frac{1}{R})^2 + \omega^2 C^2 \hat{=}$ Nenner der Impedanz $\underline{Z}(\omega)$.

Einsetzen in $\textcolor{#e64c4c}{(*)}$:
$$
\begin{align*}
\implies \left[ \frac{1}{R} \cdot \frac{1}{\alpha} - \frac{R}{2} \right]^2 + \frac{\omega^2 C^2}{\alpha^2} &= \frac{(\frac{1}{R})^2}{\alpha^2} - \frac{1}{\alpha} + \frac{R^2}{4} + \frac{\omega^2 C^2}{\alpha^2} \\
&= \frac{(\frac{1}{R})^2 - \alpha}{\alpha^2} + \frac{R^2}{4} + \frac{\omega^2 C^2}{\alpha^2}
\end{align*}
$$

<span style="color:#4ce64c">Schreibe $\alpha$ gemäß Definition aus</span> $\downarrow$
$$
= \frac{(\frac{1}{R})^2 - ((\frac{1}{R})^2 - \omega^2 C^2) + \omega^2 C^2}{\alpha^2} + \underbrace{\frac{R^2}{4} = \frac{R^2}{4}}_{\textcolor{#4ce64c}{\text{was zu beweisen war } \nabla}} \quad \text{für alle } \omega
$$

Die Ortskurve der Impedanz kann damit wie folgt dargestellt werden:

![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/OrtskurvederImpedanzRCGlied_y0xe.excalidraw)

#### Charakteristische Frequenz (RC-Parallel)
Bedingung: $Im \underline{Z}(\omega_0) = Re \underline{Z}(\omega_0)$

$$
\rightarrow \quad \omega_0 = \frac{1}{RC} \quad , \quad \varphi_{ui} = -\frac{\pi}{4}
$$

---

### 6.1.4 Parallelschaltung aus R und L

![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/ParallelschaltungRundL_camR.excalidraw)

*   **Admittanz:** $\underline{Y} = \frac{1}{R} + \frac{1}{i\omega L} = \frac{1}{R} - i \frac{1}{\omega L}$
*   **Impedanz:** $\underline{Z} = \frac{1}{\underline{Y}} = \left[ \frac{1}{R} + \frac{1}{i\omega L} \right]^{-1} = \frac{i\omega R L}{R + i\omega L}$

$\Rightarrow$ Auch hier lässt sich "einfach" beweisen, dass die Ortskurve der Impedanz einem Halbkreis entspricht.

![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/AdmittanceLocusDiagram_icAd.excalidraw)
![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/ImpedanceLocusDiagram_JdMR.excalidraw)

**Charakteristische Frequenz:**
$$
\mathrm{Im}\,\underline{Z}(\omega_0) = \mathrm{Re}\,\underline{Z}(\omega_0) \quad \rightarrow \quad \omega_0 = \frac{R}{L} \quad \rightarrow \quad \varphi_{ui} = +\frac{\pi}{4}
$$

---

## 6.2 Inversion von Ortskurven

> [!NOTE]
> **Wirkungsweise:** Die Transformation zwischen Impedanz $\underline{Z}$ und Admittanz $\underline{Y}$ entspricht einer mathematischen Inversion (Kehrwertbildung) im Komplexen. Diese bildet Geraden auf Kreise ab (und umgekehrt) und invertiert den Abstand zum Ursprung.

Bei der Diskussion der Ortskurven im vorangegangenen Abschnitt haben wir "Paare" von Ortskurven betrachtet:
$\underline{Z} \longleftrightarrow \underline{Y}$, wobei $\underline{Z} = \frac{1}{\underline{Y}}$ bzw. $\underline{Y} = \frac{1}{\underline{Z}}$

Bei der Umrechnung der beiden Kurven kommen <span style="color:#4c99e6">komplexe Abbildungen</span> ins Spiel:
$f: \mathbb{C} \rightarrow \mathbb{C}, \quad z \mapsto f(z)$
$\longrightarrow$ Jedem Punkt in der komplexen Ebene wird ein anderer Punkt in der komplexen Ebene zugeordnet.

Für die Umrechnung der Ortskurven von Impedanz und Admittanz gehen wir von der Exponentialschreibweise komplexer Zahlen aus:
$$
\underline{Z} = r e^{i\varphi} \quad \longrightarrow \quad \underline{Y} = \frac{1}{\underline{Z}} = \frac{1}{r} e^{-i\varphi}
$$

### 6.2.1 Geometrische Eigenschaften
**<span style="text-decoration:underline">Beobachtungen</span>:**

1.  Alle Punkte auf dem Einheitskreis ($r=1$) werden auf Punkte auf dem Einheitskreis abgebildet, wobei die obere Kreishälfte zur unteren Kreishälfte wird und umgekehrt:
    ![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/EinheitskreisInversion_UfZK.excalidraw)

2.  Teile einer Ortskurve, die weit vom Ursprung der komplexen Ebene entfernt sind, werden auf Teile der inversen Ortskurve abgebildet, die nahe am Ursprung liegen. Das Argument gilt auch in umgekehrter Richtung:
    ![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/BetragundArgumentInversion_wzSh.excalidraw)

### 6.2.2 Transformationsregeln
Aus der Inversionsvorschrift für einzelne komplexe Größen können wir folgende Regeln für die Inversion elementarer Ortskurven ableiten.

> [!TIP]
> **Bemerkung:** Ist eine Ortskurve nur ein Teil einer Geraden oder eines Kreises, so können die folgenden Regeln sinngemäß angewendet werden.

| Ausgangsform | Eigenschaft | Ergebnis der Inversion |
| :--- | :--- | :--- |
| **Gerade** | durch den Nullpunkt | **Gerade** durch den Nullpunkt |
| **Gerade** | **nicht** durch den Nullpunkt | **Kreis** durch den Nullpunkt |
| **Kreis** | durch den Nullpunkt | **Gerade** **nicht** durch den Nullpunkt |
| **Kreis** | **nicht** durch den Nullpunkt | **Kreis** **nicht** durch den Nullpunkt |

**Beispielhafte Darstellung:**
![](Skript_LEN_WiSe2526_Kapitel_06_ILIAS/InversioneinerOrtskurveGeradez_rcrH.excalidraw)

### 6.2.3 Mathematischer Beweis (Beispiel Gerade)

**Abbildungsvorschrift:**
$(x,y) \longmapsto (X,Y) = \frac{(x,y)}{x^2+y^2}$ bzw. $(X,Y) \longmapsto (x,y) = \frac{(X,Y)}{X^2+Y^2}$

**Ausgangspunkt: Geradengleichung**
$$
ax + by + c = 0
$$

Ersetze $x, y$ durch die obigen Ausdrücke ($\textcolor{#4ce64c}{\uparrow}$):
$$
\begin{align*}
&\quad a \frac{X}{X^2+Y^2} + b \frac{Y}{X^2+Y^2} + c = 0 \\
&\Leftrightarrow aX + bY + c (X^2+Y^2) = 0
\end{align*}
$$

**Fallunterscheidung:**

*   **Fall 1:** $c=0$
    $$
    aX + bY = 0 \quad \rightarrow \quad \text{Gerade!}
    $$
    *(Entspricht: Gerade durch den Ursprung $\to$ Gerade)*

*   **Fall 2:** $c \neq 0$
    $$
    aX + bY + c(X^2+Y^2) = 0 \quad \Leftrightarrow \quad \left(X + \frac{a}{2c}\right)^2 + \left(Y + \frac{b}{2c}\right)^2 = \frac{a^2+b^2}{4c^2}
    $$
    $$
    \hookrightarrow \text{Kreis!}
    $$
    *(Entspricht: Gerade nicht durch Ursprung $\to$ Kreis)*