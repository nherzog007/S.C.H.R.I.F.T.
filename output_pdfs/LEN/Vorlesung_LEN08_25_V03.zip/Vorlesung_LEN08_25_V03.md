# Vorlesung_LEN08_25_V03

## 8. Schwingkreise

Elektrische Schwingkreise bestehen aus mindestens **zwei** Energiespeichern, deren gespeicherte Energie periodisch ausgetauscht wird.

> [!NOTE]
> **Grundprinzip:** Elektrische Schwingkreise verhalten sich analog zu mechanischen Systemen (z.B. Federpendel).

| **1. Kondensator (Elektrisches Feld)** | **2. Spule (Magnetisches Feld)** |
|:---:|:---:|
| ![Diagram: CapacitorWithElectricField](CapacitorWithElectricField_0yWI.png) | ![Diagram: InductorWithMagneticField](InductorWithMagneticField_KZVW.png) |

### Analogie zum mechanischen Federpendel

![Diagram: Spring_Mass_System_States](Spring_Mass_System_States_edo6.png)

**Mechanische Größen:**
*   $D$: <span style="color:#4c4ce6">Federkonstante</span>
*   $s$: <span style="color:#4c4ce6">maximale Auslenkung</span>
*   $m$: <span style="color:#4c4ce6">bewegte Masse</span>
*   $v$: <span style="color:#4c4ce6">Geschwindigkeit</span>

**Energie-Vergleich:**

| <span style="color:#4c4ce6">Spannarbeit (Potentiell)</span> | <span style="color:#4c4ce6">Kinetische Energie</span> |
| :--- | :--- |
| $\textcolor{#4c4ce6}{E_{pot} = \frac{1}{2} D \cdot s^2}$ | $\textcolor{#4c4ce6}{E_{kin} = \frac{1}{2} m \cdot v^2}$ |

**Systemvergleich (Mapping):**

| **Elektrisch** | **Mechanisch** | **Analogie** |
| :--- | :--- | :--- |
| **Energie (El. Feld)**: $\textcolor{#4c4ce6}{E_e = \frac{1}{2}\frac{1}{C}Q^2}$ | **Energie (Pot.)**: $\textcolor{#4c4ce6}{E_{pot} = \frac{1}{2}Dy^2}$ | $\textcolor{#4c4ce6}{Q \triangleq y}$ (Ladung $\triangleq$ Auslenkung)<br>$\textcolor{#4c4ce6}{\frac{1}{C} \triangleq D}$ (Kehrwert Kapazität $\triangleq$ Federkonstante) |
| **Energie (Mag. Feld)**: $\textcolor{#4c4ce6}{E_m = \frac{1}{2}LI^2}$ | **Energie (Kin.)**: $\textcolor{#4c4ce6}{E_{kin} = \frac{1}{2}mv^2}$ | $\textcolor{#4c4ce6}{I \triangleq v}$ (Strom $\triangleq$ Geschwindigkeit)<br>$\textcolor{#4c4ce6}{L \triangleq m}$ (Induktivität $\triangleq$ Masse) |
| **Spannung**: $\textcolor{#4c4ce6}{U}$ | **Kraft**: $\textcolor{#4c4ce6}{F_r}$ | |

**Kennwerte der Schwingung:**
*   <span style="color:#4c99e6">Kreisfrequenz:</span> $\textcolor{#4c99e6}{\omega_0 = \sqrt{\frac{D}{m}}}$
*   <span style="color:#4c99e6">Schwingungsdauer:</span> $\textcolor{#4c99e6}{T = 2\pi\sqrt{\frac{m}{D}}}$

---

## 8.1 Serienschwingkreis

### Aufbau und Impedanz

Ein realer Serienschwingkreis berücksichtigt Verluste durch einen ohmschen Widerstand $R$.

| Idealer Schwingkreis | Realer Schwingkreis | Impedanz-Ersatzschaltbild |
| :---: | :---: | :---: |
| ![Diagram: Ideal_Electrical_Resonant_Circuit](Ideal_Electrical_Resonant_Circuit_z0f6.png) | ![Diagram: Series_Resonant_Circuit](Series_Resonant_Circuit_u3B5.png) | ![Diagram: Lossy_Series_Resonant_Circuit_Impedance](Lossy_Series_Resonant_Circuit_Impedance_yhrT.png) |

**Herleitung der komplexen Impedanz:**

Die Spannungen im RLC-Kreis addieren sich:
$\textcolor{#4c4ce6}{\underline{U}_R = R \cdot \underline{I}}$
$\textcolor{#4c4ce6}{\underline{U}_C = \frac{1}{j\omega C} \cdot \underline{I}}$
$\textcolor{#4c4ce6}{\underline{U}_L = j\omega L \cdot \underline{I}}$

Daraus folgt die Gesamtspannung und Impedanz $\underline{Z}$:
$\textcolor{#e64c4c}{\underline{U}} = \textcolor{#4c4ce6}{\underline{Z}} \cdot \textcolor{#e64c4c}{\underline{I}} = \left( \textcolor{#4c4ce6}{R} + \textcolor{#4c4ce6}{\frac{1}{j\omega C}} + \textcolor{#4c4ce6}{j\omega L} \right) \cdot \textcolor{#e64c4c}{\underline{I}}$

> [!TIP]
> **Rechenregel:** Es gilt $\textcolor{#4c4ce6}{j = -\frac{1}{j}}$

Aufteilung nach Real- und Imaginärteil:
$\underbrace{\textcolor{#4c4ce6}{\underline{Z}}}_{\substack{\textcolor{#4ce64c}{\text{Komplexe}} \\ \textcolor{#4ce64c}{\text{Impedanz}}}} = \underbrace{\textcolor{#4c4ce6}{R}}_{\substack{\textcolor{#4ce64c}{\text{Realteil}} \\ \textcolor{#4ce64c}{\hat{=}} \\ \textcolor{#4ce64c}{\text{Wirkwiderstand}}}} + \underbrace{\textcolor{#4c4ce6}{j \left(\omega L -\frac{1}{\omega C} \right)}}_{\substack{\textcolor{#4ce64c}{\text{Imaginärteil}} \\ \textcolor{#4ce64c}{\hat{=}} \\ \textcolor{#4ce64c}{\text{Blindwiderstand}}}} = \textcolor{#4c4ce6}{R + jX}$

### Definition der Resonanzfrequenz $f_{\textcolor{#e64c4c}{0}}$

![Diagram: SeriesRLC_Circuit](SeriesRLC_Circuit_qQE0.png)

Resonanz tritt auf, wenn der **Imaginärteil der Impedanz verschwindet** ($\underline{Z}$ wird reell).

1.  **Bedingung:** $\textcolor{#4c99e6}{X \stackrel{!}{=} \mathrm{Im}\{\underline{Z}(\omega_0)\} \stackrel{!}{=} 0}$
2.  $\textcolor{#4c99e6}{\omega_0 L - \frac{1}{\omega_0 C} \stackrel{!}{=} 0 \quad \Rightarrow \quad \omega_0 L = \frac{1}{\omega_0 C}}$
3.  Auflösen nach $\omega_0$:
    $\textcolor{#e64c4c}{\omega_0 = \frac{1}{\sqrt{LC}} = 2 \cdot \pi \cdot f_0}$

**Spannungsverhältnisse bei Resonanz ($\omega = \omega_0$):**
*   $\underline{U}_L = j\omega_0 L \cdot \underline{I}$
*   $\underline{U}_C = - \frac{1}{j\omega_0 C} \cdot \underline{I}$
*   Da die Beträge gleich sind, aber das Vorzeichen entgegengesetzt ist: $\underline{U}_L + \underline{U}_C = 0$.
*   Die Gesamtspannung fällt nur am Widerstand ab: $\textcolor{#4c99e6}{\underline{U} \stackrel{!}{=} \underline{U}_R |_{\omega = \omega_0}}$ und $\textcolor{#e64c4c}{\underline{Z} = R}$.

### Definition des Kennwiderstands $\textcolor{#e64c4c}{X_0}$

Bei Resonanz sind die Beträge der Blindwiderstände gleich groß:
$\textcolor{#e64c4c}{X_L \Big|_{\omega_0} = \omega_0 L = \sqrt{\frac{L}{C}}}$ und $\textcolor{#e64c4c}{X_C \Big|_{\omega_0} = \frac{1}{\omega_0 C} = \sqrt{\frac{L}{C}}}$

Daraus definiert sich der **Kennwiderstand**:
$\textcolor{#e64c4c}{X_0 = \sqrt{\frac{L}{C}}}$

Umstellung nach Bauteilwerten:
*   $L = \frac{1}{\omega_0} \cdot X_0 \quad [\Omega s]$
*   $C = \frac{1}{\omega_0} \cdot \frac{1}{X_0} \quad [\frac{s}{\Omega}]$

### Ortskurve für die Serienimpedanz

![Diagram: Impedance_Locus_Plot_for_Series_RLC](Impedance_Locus_Plot_for_Series_RLC_U63n.png)

Verlauf von $\underline{Z} = R + j\left(\omega L - \frac{1}{\omega C}\right)$:
*   **$\omega \to 0$:** $\textcolor{#4c4ce6}{\underline{Z} \approx R - j\infty}$ (kapazitiv dominiert)
*   **$\omega = \omega_0$:** $\textcolor{#4c4ce6}{\underline{Z} = R}$ (rein ohmsch, Minimum des Betrags)
*   **$\omega \to \infty$:** $\textcolor{#4c4ce6}{\underline{Z} \approx R + j\infty}$ (induktiv dominiert)

### Grenzfrequenzen und Bandbreite

Wir betrachten die Frequenzen, bei denen die Phasenverschiebung zwischen Spannung und Strom $45^{\circ}$ beträgt ($\operatorname{Re} = |\operatorname{Im}|$).

![Diagram: Phasor_Diagrams_RLC](Phasor_Diagrams_RLC_85AQ.png)

**Herleitung der Grenzfrequenzen $\omega_1$ und $\omega_2$:**

Für $\omega_1 > \omega_0$ gilt $\angle(\underline{U}, \underline{I}) = +45^\circ$, also $R = X$:
1.  $\textcolor{#4c4ce6}{R = \omega_1 L - \frac{1}{\omega_1 C} \quad \Big| \cdot \frac{\omega_1}{L}}$
2.  $\textcolor{#4c4ce6}{\omega_1 \frac{R}{L} = \omega_1^2 - \frac{1}{LC}}$
3.  $\textcolor{#4c4ce6}{0 = \omega_1^2 - \omega_1 \frac{R}{L} - \frac{1}{LC}}$

Lösen der quadratischen Gleichung durch quadratische Ergänzung:
$\textcolor{#4c4ce6}{0 = \left(\omega_1 - \frac{R}{2L}\right)^2 - \left(\frac{R}{2L}\right)^2 - \frac{1}{LC}}$
$\textcolor{#4c4ce6}{\implies \omega_1 = +\frac{R}{2L} + \sqrt{\left(\frac{R}{2L}\right)^2 + \frac{1}{LC}}}$

Analog für $\omega_2 < \omega_0$:
$\textcolor{#4c4ce6}{\implies \omega_2 = -\frac{R}{2L} + \sqrt{\left(\frac{R}{2L}\right)^2 + \frac{1}{LC}}}$

*(Hinweis: Nur positive Frequenzen sind physikalisch relevant)*

#### Definitionen für Bandbreite und Güte

1.  **Frequenzbandbreite ($b_w$):**
    $\textcolor{#4c4ce6}{\boxed{b_w := \omega_1 - \omega_2 = \frac{R}{L}}}$

2.  **Relative Bandbreite / Dämpfung ($d$):**
    $d := \textcolor{#4c4ce6}{\frac{b_w}{\omega_0} = \frac{R}{L \sqrt{LC}} = R \sqrt{\frac{C}{L}}}$
    $\textcolor{#4c4ce6}{\boxed{d = \frac{R}{X_0}}}$

3.  **Güte ($Q$):**
    $Q := \textcolor{#4c4ce6}{\frac{1}{d} = \frac{X_0}{R} = \frac{\text{Kennwiderstand}}{\text{ohmscher Widerstand}}}$

> [!IMPORTANT]
> **Zusammenhang:** $\textcolor{#e64c4c}{\boxed{R \downarrow + L \uparrow \sim Q \uparrow}}$
> Eine höhere Güte wird durch kleinen Widerstand oder hohe Induktivität erreicht.

### Zusammenfassung der Frequenzverläufe

![Diagram: Series_Resonance_Frequency_Response_Plots](Series_Resonance_Frequency_Response_Plots_2Xkt.png)

*   **Impedanz $\underline{Z}$:** Minimum bei $\omega_0$ (Betrag $R$).
*   **Admittanz $\underline{Y} = 1/\underline{Z}$:** Maximum bei $\omega_0$.
*   **Strom $I$:** Maximum bei $\omega_0$.
*   **Verhalten:**
    *   $\omega \to 0$: Kreis wirkt kapazitiv.
    *   $\omega \gg \omega_0$: Kreis wirkt induktiv.

#### Beispielrechnung

![Diagram: RLC_SeriesCircuit](RLC_SeriesCircuit_7JM3.png)

**Gegeben:**
*   $R = 1 \, \Omega$
*   $f_0 = 1 \, \text{MHz}$
*   $R = X_0$ (Güte $Q=1$)

**Lösung:**
$\textcolor{#4c4ce6}{L = \frac{1}{\omega_0} \cdot X_0 = \frac{1}{2\pi \cdot 10^6} \cdot 1 = \frac{1}{2\pi} \mu H \approx 159 \, \text{nH}}$
$\textcolor{#4c4ce6}{C = \frac{1}{\omega_0 X_0} = \frac{1}{2\pi \cdot 10^6 \cdot 1} = \frac{1}{2\pi} \mu F \approx 159 \, \text{nF}}$

### Bemerkungen zur Symmetrie und Güte

Die Resonanzkurven sind im Allgemeinen **nicht symmetrisch** um $\omega_0$.
Eine Näherung $\textcolor{#4c4ce6}{\omega_{1,2} \approx \omega_0 \pm \frac{R}{2L}}$ gilt nur, wenn:
$\textcolor{#4c4ce6}{\left( \frac{R}{2L} \right)^2 \ll \frac{1}{LC}}$
Das entspricht einer **hohen Güte** ($Q \gg 1$).

> [!WARNING]
> **Resonanzüberhöhung:** Bei hoher Güte ($Q \gg 1$) gilt:
> $\textcolor{#4c4ce6}{\operatorname{Im}\{\underline{U}_{L_0}\} \approx \operatorname{Im}\{\underline{U}_{C_0}\} \approx Q \cdot \underline{U}_R}$
> Die Spannungen an Spule und Kondensator können die Eingangsspannung um ein Vielfaches übersteigen!

---

## 8.2 Parallelschwingkreis

Hier liegen $R$, $L$ und $C$ parallel an der Spannung $\underline{U}$. Wir betrachten daher die **Admittanz** (Leitwert).

![Diagram: Parallel_RLC_Circuit](Parallel_RLC_Circuit_rIw9.png)

**Komplexe Admittanz:**
$\textcolor{#4c4ce6}{\underline{Y} = \underbrace{\frac{1}{R}}_{\text{Realteil}} + \underbrace{j\omega C + \frac{1}{j\omega L}}_{\text{Imaginärteil}} = \frac{1}{R} + j\left(\omega C - \frac{1}{\omega L}\right)}$

### Ortskurve für $\underline{Y}$

![Diagram: AdmittanceLocusPlot](AdmittanceLocusPlot_sb4g.png)

*   **$\omega \to 0$:** $\textcolor{#4c4ce6}{\underline{Y} \approx \frac{1}{R} - j\infty}$ (induktiv dominiert)
*   **$\omega = \omega_0$:** $\textcolor{#4c4ce6}{\underline{Y}_0 = \frac{1}{R}}$ (Minimaler Leitwert, also maximale Impedanz!)
*   **$\omega \to \infty$:** $\textcolor{#4c4ce6}{\underline{Y} \approx \frac{1}{R} + j\infty}$ (kapazitiv dominiert)

### Resonanz ($\omega = \omega_0$)

Bei Resonanz heben sich die Blindströme auf:
$\textcolor{#4c4ce6}{\underline{I}_{C_0} = -\underline{I}_{L_0}}$
Es fließt nach außen nur der Wirkstrom durch $R$.

**Def.: Kennleitwert ($B_0$)**
$\textcolor{#4c99e6}{B_0 := \omega_0 C = \frac{1}{\omega_0 L} = \sqrt{\frac{C}{L}} = \frac{1}{X_0}}$

### Bandbreite und Güte beim Parallelkreis

Analog zum Serienkreis werden die Grenzfrequenzen bestimmt, wo Real- und Imaginärteil der Admittanz gleich sind:
$\textcolor{#4c4ce6}{\frac{1}{R} \stackrel{!}{=} \omega_1 C - \frac{1}{\omega_1 L}}$

Ergebnisse:
1.  **Bandbreite:** $\textcolor{#4c4ce6}{b_w = \frac{1}{RC}}$
2.  **Dämpfung:** $\textcolor{#4c4ce6}{d_p = \sqrt{\frac{L}{C} \cdot \frac{1}{R}}}$
3.  **Güte ($Q_p$):**
    $\textcolor{#4c4ce6}{Q_p = R \cdot \sqrt{\frac{C}{L}} = R \cdot B_0}$

> [!IMPORTANT]
> **Vergleich Serie vs. Parallel:**
> *   Serie: $Q \sim \frac{1}{R}$ (Kleiner Widerstand = hohe Güte)
> *   Parallel: $Q_p \sim R$ (Großer Widerstand = hohe Güte, weniger Dämpfung)
>
> Bei hoher Güte ($Q \gg 1$) gilt beim Parallelkreis **Stromüberhöhung**: $\textcolor{#4c4ce6}{\underline{I}_{C0} \approx \underline{I}_{L0} \approx Q \cdot \underline{I}_R}$.

---

## 8.3 Energetische Betrachtung der Güte

Eine allgemeingültige Definition der Güte für jedes schwingungsfähige System ist:

$\boxed{Q = 2\pi \cdot \frac{\text{gesamte gespeicherte Energie}}{\text{Energieverlust pro Periode}}}$

Wir verifizieren dies durch Betrachtung der Energien im Zeitbereich.

### 1. Energie im Widerstand (Verlust)

![Diagram: ResistorSchematic](ResistorSchematic_icuf.png)

Leistung $P_R(t) = u_R(t) \cdot i_R(t)$.
Mit $i_R = \hat{I}_R \sin(\omega t)$:
$\textcolor{#4c4ce6}{P_R = R \cdot \hat{I}_R^2 \cdot \sin^2(\omega t) = R \cdot \hat{I}_R^2 \cdot \frac{1}{2} (1 - \cos(2\omega t))}$

Die **mittlere Energie** (Verlust) über eine Periode $T$:
$W_R = \int_0^T P_R dt = \boxed{\frac{1}{2} R \hat{I}_R^2 \cdot T}$

Es gilt auch: $\textcolor{#4c4ce6}{\boxed{W_R = P_R \cdot T}}$ (wobei $P_R$ hier die Wirkleistung ist).

### 2. Energie in Spule und Kondensator (Speicher)

**Induktivität (L):**
Die Leistung pendelt: $\textcolor{#e64c4c}{P_L = \frac{1}{2}\omega L \hat{I}^2 \cdot \sin(2\omega t)}$.
*   Mittelwert über eine Periode ist **0**.
*   Aber die **maximal gespeicherte Energie** (Integration bis $T/4$) ist:
    $\textcolor{#4c4ce6}{W_L = \frac{1}{2} L \hat{I}_L^2}$

**Kapazität (C):**
Analog für den Kondensator:
$\textcolor{#4c4ce6}{W_C = \frac{1}{2} C \hat{U}_C^2}$

### 3. Verifikation der Güte-Formeln

Einsetzen in die allgemeine Güte-Definition:

*   **Für Serienkreis** ($\hat{I}_L = \hat{I}_R = \hat{I}$):
    $Q_R = 2\pi \cdot \frac{\frac{1}{2}L\hat{I}^2}{\frac{1}{2}R \cdot \hat{I}^2 \cdot T} = 2\pi \frac{L}{R \cdot T} = \frac{L}{R} \omega_0 = \frac{1}{R}\sqrt{\frac{L}{C}} \quad \text{(stimmt überein)}$

*   **Für Parallelkreis** ($\hat{U}_C = \hat{U}_R = \hat{U}$):
    $Q_p = 2\pi \cdot \frac{\frac{1}{2}C\hat{U}^2}{\frac{1}{2}\frac{\hat{U}^2}{R} \cdot T} = \frac{C \cdot R \cdot 2\pi}{T} = \omega_0 C R = R \sqrt{\frac{C}{L}} \quad \text{(stimmt überein)}$

---

## 8.4 Verallgemeinerte Resonanzkurven

Um Resonanzkurven unabhängig von konkreten Bauteilwerten darzustellen, führt man eine **Normierung** ein.

**Definition der Verstimmung $\vartheta$ (Theta):**
$\vartheta := \frac{\omega}{\omega_0} - \frac{\omega_0}{\omega}$

*   $\omega = \omega_0 \implies \vartheta = 0$
*   $\omega \to 0 \implies \vartheta \to -\infty$
*   $\omega \to \infty \implies \vartheta \to +\infty$

**Normierte Impedanz (Serienkreis):**
$\underline{Z} = R + j\omega_0 L \left(\frac{\omega}{\omega_0} - \frac{\omega_0}{\omega}\right) = R \cdot (1 + j \frac{\omega_0 L}{R} \cdot \vartheta)$

$\boxed{\underline{Z} = R \cdot (1 + jQ_R \cdot \vartheta)}$

> [!WARNING]
> **Fehlerhinweis:** Im Skript auf S.145 Gl. 8.39 befindet sich ein Fehler bezüglich dieser Herleitung.

![Diagram: ImpedanceAndPhasePlot](ImpedanceAndPhasePlot_7m4E.png)