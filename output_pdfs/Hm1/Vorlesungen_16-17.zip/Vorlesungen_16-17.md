# Vorlesungen 16-17: Logarithmus, Trigonometrie und Arkusfunktionen

## 1. Der natürliche Logarithmus und die allgemeine Potenz

> [!NOTE]
> **Wirkungsweise:** Der natürliche Logarithmus transformiert Multiplikationen in Additionen, was durch die Umkehrung der Exponentialfunktion begründet ist. Die allgemeine Potenz erweitert den Potenzbegriff auf reelle Exponenten, indem sie auf die e-Funktion und den natürlichen Logarithmus zurückgeführt wird.

### 1.1 Eigenschaften des natürlichen Logarithmus
Für alle $x,y > 0$ gelten die fundamentalen Rechenregeln:

*   $\ln(x \cdot y) = \ln(x) + \ln(y) \quad \textcolor{#e64c4c}{(*)}$
*   $\ln\left(\frac{x}{y}\right) = \ln(x) - \ln(y)$

**Beweis der Multiplikationseigenschaft:**
$\ln(xy) = \ln(x) + \ln(y) \iff_{\substack{\uparrow \\ \text{exp. streng} \\ \text{monoton wachsend}}} e^{\ln(xy)} = e^{\ln(x) + \ln(y)}$
$\iff^{\textcolor{#e64c4c}{(1a)}} xy = e^{\ln(x)} \cdot e^{\ln(y)} \iff^{\textcolor{#e64c4c}{(1a)}} xy = xy$ (wahre Aussage).

Also stimmt $\ln(xy) = \ln(x) + \ln(y)$.
*Beispiel:* $\ln(15) = \ln(5 \cdot 3) = \ln(5) + \ln(3)$.

### Beispiel 9.2: Existenz von Nullstellen
**Aufgabe:** Zeige, dass $f: (0; \infty) \to \mathbb{R}$ mit $f(x) = \ln x + x$ genau eine Nullstelle im Intervall $(\frac{1}{2}; \frac{2}{3})$ besitzt.

**Lösung:**
$f$ ist stetig und streng monoton wachsend, da $x$ und $\ln(x)$ diese Eigenschaften besitzen. Wir prüfen die Intervallgrenzen:

$$
\left. \begin{aligned}
f(\tfrac{1}{2}) &= \ln(\tfrac{1}{2}) + \tfrac{1}{2} < 0 \quad \textcolor{#e64c4c}{(1)} \\
f(\tfrac{2}{3}) &= \ln(\tfrac{2}{3}) + \tfrac{2}{3} \overset{!}{>} 0 \quad \textcolor{#e64c4c}{(2)}
\end{aligned} \right\} \xrightarrow[\text{Zwischenwertsatz}]{f \text{ stetig}} \exists x_0 \in (\tfrac{1}{2}; \tfrac{2}{3}) \text{ mit } f(x_0)=0
$$

**Nachweis für Ungleichung (2):**
$\textcolor{#e64c4c}{(2)} \iff \ln(\tfrac{2}{3}) > -\tfrac{2}{3} \iff_{\substack{\uparrow \\ \text{exp streng} \\ \text{monoton}}} e^{\ln(\frac{2}{3})} > e^{-\frac{2}{3}} \overset{\textcolor{#e64c4c}{(1a)}}{\iff} \frac{2}{3} > e^{-\frac{2}{3}}$
Durch Multiplikation mit $\frac{3}{2}e^{\frac{2}{3}}$:
$\iff e^{\frac{2}{3}} > \frac{3}{2} \iff \left(e^{\frac{2}{3}}\right)^{\frac{3}{2}} > \left(\frac{3}{2}\right)^{\frac{3}{2}} \iff e > \left(\frac{3}{2}\right)^{\frac{3}{2}}$.

Dies ist wahr, da $\left(\frac{3}{2}\right)^{\frac{3}{2}} < \left(\frac{3}{2}\right)^2 = 2,25 < e$.
Da $f$ streng monoton wachsend ist, ist $f$ injektiv. Somit existiert **genau eine** Nullstelle in diesem Intervall.

---

### 1.2 Definition der allgemeinen Potenz
Während $a^3 = a \cdot a \cdot a$ intuitiv ist, sind Ausdrücke wie $a^{\sqrt{2}}$ oder $a^e$ für $a > 0$ nicht direkt über Multiplikation definiert.

**Definition:**
$\forall a > 0$ gilt $a \overset{\textcolor{#e64c4c}{(1a)}}{=} e^{\ln(a)}$. Wir definieren daher:
$$a^x = (e^{\ln(a)})^x = e^{x \ln(a)}$$

**Eigenschaften der Abbildung $x \mapsto a^x$:**
*   Stetig und streng positiv ($a^x > 0 \;\; \forall x \in \mathbb{R}$).
*   $a^{x+y} = a^x a^y$
*   $a^{-x} = \frac{1}{a^x}$
*   $\ln(a^x) = \ln(e^{x \ln(a)}) \overset{\textcolor{#e64c4c}{(1a)}}{=} x \ln(a)$
*   $(a^x)^y = a^{xy}$

### 1.3 Logarithmus zur Basis $a$
Sei $a > 0, a \neq 1$. Die Funktion $f(x) = a^x$ bildet $\textcolor{#99e64c}{\mathbb{R}} \to \textcolor{#4ce6e6}{(0; \infty)}$ ab. Sie ist streng monoton, stetig und bijektiv.
Die Umkehrabbildung ist der Logarithmus zur Basis $a$:
$\log_a: \textcolor{#4ce6e6}{(0; \infty)} \to \textcolor{#99e64c}{\mathbb{R}}$

**Identitäten:**
1.  $\log_a(\textcolor{#99e64c}{a^x}) = \textcolor{#99e64c}{x} \quad \forall x \in \mathbb{R}$
2.  $a^{\log_a(y)} = y \quad \forall y \in (0; \infty) \quad \textcolor{#e64c4c}{(3)}$
3.  $x = \log_a(y) \iff y = a^x$

#### Beispiel 9.3: Logarithmuswerte
*   $\log_{\textcolor{#e6994c}{10}}(\textcolor{#4ce6e6}{10\,000}) = \textcolor{#99e64c}{4}$, weil $\textcolor{#e6994c}{10}^{\textcolor{#99e64c}{4}} = \textcolor{#4ce6e6}{10\,000}$.
*   Ziffernanzahl bestimmen: $23 \le \log_{10} N < 24 \implies N$ hat 24 Ziffern (z.B. Avogadro-Zahl $\approx 6,023 \cdot 10^{23}$).

#### Beispiel 9.4: Exponentenregel
Seien $x, a > 0, a \neq 1$.
$\log_a(x^{\textcolor{#e6994c}{b}}) = \textcolor{#e6994c}{b} \cdot \log_a(x) \quad \textcolor{#e64c4c}{(4)}$

*Beweis:* Wende $a^{(\dots)}$ auf beide Seiten an.
$a^{\log_a(x^{\textcolor{#e6994c}{b}})} = x^{\textcolor{#e6994c}{b}}$ (links) und $a^{\textcolor{#e6994c}{b} \log_a(x)} = (a^{\log_a(x)})^{\textcolor{#e6994c}{b}} = x^{\textcolor{#e6994c}{b}}$ (rechts).

---

### 1.4 Basiswechsel (Satz 9.1)

> [!NOTE]
> **Wirkungsweise:** Der Basiswechselsatz ermöglicht die Umrechnung jedes Logarithmus in den natürlichen Logarithmus, wodurch Berechnungen und Ableitungen vereinheitlicht werden.

**Satz 9.1:**
$\forall a, y \in (0; \infty), a \neq 1 \text{ gilt } \log_a(y) = \frac{\ln(y)}{\ln(a)} \quad \textcolor{#e64c4c}{(5)}$

*Beweis:*
$\textcolor{#e64c4c}{(5)} \iff \ln(a) \cdot \log_a(y) = \ln(y) \iff e^{\ln(a) \cdot \log_a(y)} = e^{\ln(y)}$
$\iff (e^{\ln(a)})^{\log_a(y)} = y \iff a^{\log_a(y)} = y$, was gemäß $\textcolor{#e64c4c}{(3)}$ wahr ist.

#### Beispiel 9.5 – 9.6: Anwendungen des Basiswechsels
**Beispiel 9.5:**
$\log_{10}(e^2) \stackrel{\textcolor{#e64c4c}{(5)}}{=} \frac{\ln(e^2)}{\ln(10)} = \frac{2}{\ln(10)}$

**Beispiel 9.6:** Zeige $\log_3(\sqrt{11}-\sqrt{2}) = 2 - \log_3(\sqrt{11}+\sqrt{2}) \quad \textcolor{#e64c4c}{(6)}$
Umformung: $\log_3(\sqrt{11}-\sqrt{2}) + \log_3(\sqrt{11}+\sqrt{2}) = 2$.
Nutze Additionsregel $\log_a(x) + \log_a(y) = \log_a(xy)$:
$\implies \log_3((\sqrt{11}-\sqrt{2})(\sqrt{11}+\sqrt{2})) = 2$
$\implies \log_3(11 - 2) = \log_3(9) = 2$. (Wahr, da $3^2=9$).

> [!NOTE]
> **Mentifrage:** Bestimme alle Lösungen der Gleichung $\log_2(x) = \log_4(x-2)$!
> Wie viele Lösungen hat sie?
> (1) keine (2) eine (3) zwei (4) unendlich viele (5) keine der obigen (6) keine Ahnung.

---

## 2. Trigonometrische Funktionen (Sinus, Cosinus)

> [!NOTE]
> **Wirkungsweise:** Sinus und Cosinus projizieren Winkel im Einheitskreis auf kartesische Koordinaten. Sie sind periodische Funktionen, die fundamentale Symmetrien und Additionseigenschaften aufweisen.

<div align="right">18.12.23</div>

**Definition am Einheitskreis:**
Für einen Winkel $0 < \varphi < \frac{\pi}{2}$ im Einheitskreis (Radius $OA=1$) gilt:
*   $\textcolor{4ce6e6}{\cos \varphi} = \text{x-Koordinate}$
*   $\textcolor{99e64c}{\sin \varphi} = \text{y-Koordinate}$

![](Vorlesungen_16-17/Vorlesungen_16-17_p2_Einheitskreis_Polardarstellung.excalidraw)
![](Vorlesungen_16-17/Vorlesungen_16-17_p2_Dreieck_Definition_Cos_Sin.excalidraw)

### 2.1 Eigenschaften und Symmetrien
Für alle $x \in \mathbb{R}$ und $k \in \mathbb{Z}$ gelten folgende Identitäten:

| Eigenschaft | Formel | Beschreibung |
| :--- | :--- | :--- |
| **(i) Symmetrie** | $\sin(-x) = -\sin(x)$ | Sinus ist ungerade |
| | $\cos(-x) = \cos(x)$ | Cosinus ist gerade |
| **(ii) Verschiebung** | $\sin(x+\pi) = -\sin(x)$ | Halbperioden-Verschiebung |
| | $\cos(x+\pi) = -\cos(x)$ | |
| **(iii) Periodizität** | $\sin(x+2\pi) = \sin(x)$ | $2\pi$-periodisch |
| | $\cos(x+2\pi) = \cos(x)$ | |
| **(iv) Spiegelung** | $\sin(\pi-x) = \sin(x)$ | |
| | $\cos(\pi-x) = -\cos(x)$ | |
| **(v) Phasenverschiebung** | $\sin(x+\frac{\pi}{2}) = \cos(x)$ | |
| | $\cos(x+\frac{\pi}{2}) = -\sin(x)$ | |
| **(vi) Nullstellen** | $\sin(k\pi) = 0$ | |
| | $\cos(k\pi) = (-1)^k$ | |

**Visualisierung der Symmetrien:**

![](Vorlesungen_16-17/Vorlesungen_16-17_p2_Einheitskreis_Symmetrie_i.excalidraw)
![](Vorlesungen_16-17/Vorlesungen_16-17_p2_Einheitskreis_Symmetrie_iv.excalidraw)

### 2.2 Additionstheoreme und Spezielle Werte
$\cos(x+y) = \cos x \cos y - \sin x \sin y$
$\sin(x+y) = \sin x \cos y + \cos x \sin y$

**Tabelle spezieller Werte:**

| x | $0$ | $\frac{\pi}{6}$ | $\frac{\pi}{4}$ | $\frac{\pi}{3}$ | $\frac{\pi}{2}$ |
| :--- | :--- | :--- | :--- | :--- | :--- |
| $\sin x$ | $0$ | $\frac{1}{2}$ | $\frac{\sqrt{2}}{2}$ | $\frac{\sqrt{3}}{2}$ | $1$ |
| $\cos x$ | $1$ | $\frac{\sqrt{3}}{2}$ | $\frac{\sqrt{2}}{2}$ | $\frac{1}{2}$ | $0$ |

#### Herleitung geometrischer Werte
**Für $\frac{\pi}{4}$ (45°):**
Im gleichschenkligen rechtwinkligen Dreieck gilt $|AB| = |AC| = a$. Hypotenuse $|BC| = a\sqrt{2}$.
$\sin \frac{\pi}{4} = \frac{a}{a\sqrt{2}} = \frac{1}{\sqrt{2}}$.

![](Vorlesungen_16-17/Vorlesungen_16-17_p3_Triangle_Pi4.excalidraw)

**Für $\frac{\pi}{3}$ (60°):**
Im gleichseitigen Dreieck ist die Höhe $AM$ auch Seitenhalbierende ($a/2$).
Höhe per Pythagoras: $|AM| = \frac{a\sqrt{3}}{2}$.
$\sin \frac{\pi}{3} = \frac{\text{Gegenkathete}}{\text{Hypotenuse}} = \frac{\sqrt{3}}{2}$.

![](Vorlesungen_16-17/Vorlesungen_16-17_p3_Triangle_Pi3.excalidraw)

### Beispiel 9.8: Berechnung mit Periodizität
**Bestimme $\cos (\frac{437\pi}{6})$ und $\sin (\frac{437\pi}{6})$.**

1.  Zerlegung des Arguments:
    $\frac{437\pi}{6} = \frac{437}{12} \cdot 2\pi$.
    Division mit Rest: $437 = 12 \cdot 36 + 5$.
2.  Reduktion:
    Argument $= 36 \cdot 2\pi + \frac{5\pi}{6}$.
    Aufgrund der $2\pi$-Periodizität gilt: $\cos(\frac{437\pi}{6}) = \cos(\frac{5\pi}{6})$.
3.  Berechnung:
    $\cos(\frac{5\pi}{6}) = \cos(\pi - \frac{\pi}{6}) \stackrel{(iv)}{=} -\cos(\frac{\pi}{6}) = -\frac{\sqrt{3}}{2}$.
    $\sin(\frac{5\pi}{6}) = \sin(\pi - \frac{\pi}{6}) \stackrel{(iv)}{=} \sin(\frac{\pi}{6}) = \frac{1}{2}$.

---

## 3. Arkusfunktionen (Inverse Trigonometrie)

> [!NOTE]
> **Wirkungsweise:** Trigonometrische Funktionen sind auf $\mathbb{R}$ nicht bijektiv. Durch Einschränkung des Definitionsbereichs auf Monotonie-Intervalle können Umkehrfunktionen (Arkusfunktionen) definiert werden, die einem Wert den zugehörigen "Hauptwert"-Winkel zuordnen.

### 3.1 Arcuscosinus
Die Funktion $\cos: \mathbb{R} \to [-1;1]$ ist nicht injektiv.
Eingeschränkt auf $\textcolor{#e64c4c}{[0;\pi]}$ ist $\cos$ jedoch bijektiv und streng monoton fallend.

**Definition:**
$\arccos : \textcolor{#e6994c}{[-1;1]} \to \textcolor{#e64c4c}{[0;\pi]}$

![](Vorlesungen_16-17/Vorlesungen_16-17_p3_RestrictedCosine.excalidraw)
![](Vorlesungen_16-17/Vorlesungen_16-17_p3_Arccosine.excalidraw)

#### Beispiel 9.9: Arcuscosinus-Werte
Gesucht: $\arccos(\frac{1}{2})$.
Frage: Welcher Winkel in $\textcolor{#e64c4c}{[0; \pi]}$ hat den Cosinus $\frac{1}{2}$?
*   $\arccos(\frac{1}{2}) = \textcolor{#e64c4c}{\frac{\pi}{3}}$
*   $\arccos(0) = \textcolor{#e64c4c}{\frac{\pi}{2}}$
*   $\arccos(-1) = \textcolor{#e64c4c}{\pi}$

> [!IMPORTANT]
> **Achtung:** $\cos(\frac{7\pi}{3}) = \frac{1}{2}$, aber $\arccos(\frac{1}{2}) \neq \frac{7\pi}{3}$, da $\frac{7\pi}{3} \notin [0;\pi]$.
> Allgemein gilt: $\cos(a) = b \implies \arccos(b)=a$ **nur wenn** $a \in [0;\pi]$.

### 3.2 Arcussinus
Einschränkung des Sinus auf $\textcolor{#e64c4c}{[-\frac{\pi}{2}; \frac{\pi}{2}]}$ ermöglicht Bijektivität.

**Definition:**
$\textcolor{4ce6e6}{\arcsin : [-1;1]} \to \textcolor{#e64c4c}{[-\frac{\pi}{2}; \frac{\pi}{2}]}$

*   $\arcsin(0) = 0$
*   $\arcsin(1) = \frac{\pi}{2}$
*   $\arcsin(-1) = -\frac{\pi}{2}$

![](Vorlesungen_16-17/Vorlesungen_16-17_p4_RestrictedSineGraph.excalidraw)
![](Vorlesungen_16-17/Vorlesungen_16-17_p4_ArcSineGraph.excalidraw)

> [!WARNING]
> **Mentifrage:** Gelten folgende Gleichheiten für alle definierten $x$?
> (a) $\sin(\arcsin x)=x$
> (b) $\arcsin(\sin x) = x$
> Antwortmöglichkeiten: (1) Beide, (2) nur (a), (3) nur (b), (4) keine, (5) keine Ahnung.

### 3.3 Tangens und Arcustangens
Der Tangens ist definiert als $\tan(x) = \frac{\sin(x)}{\cos(x)}$ für $x \neq \frac{\pi}{2} + k\pi$.
Auf dem Intervall $\textcolor{#e64c4c}{(-\frac{\pi}{2}; \frac{\pi}{2})}$ ist er streng monoton wachsend und bijektiv.

**Grenzwerte:**
$\lim_{\varphi \to \frac{\pi}{2}-} \tan \varphi = +\infty, \quad \lim_{\varphi \to -\frac{\pi}{2}+} \tan \varphi = -\infty$.

**Definition Arcustangens:**
$\arctan : \textcolor{#e6994c}{\mathbb{R}} \to \textcolor{#e64c4c}{(-\frac{\pi}{2}; \frac{\pi}{2})}$

![](Vorlesungen_16-17/Vorlesungen_16-17_p4_UnitCircleTan.excalidraw)
![](Vorlesungen_16-17/Vorlesungen_16-17_p4_TanGraph.excalidraw)
![](Vorlesungen_16-17/Vorlesungen_16-17_p4_ArcTanGraph.excalidraw)

#### Beispiel 9.10: Arcustangens-Werte
*   $\arctan(1) = \textcolor{#e64c4c}{\frac{\pi}{4}}$
*   $\arctan(0) = 0$
*   $\lim_{x \to \infty} \arctan x = \frac{\pi}{2}$

---

## 4. Anwendung: Polardarstellung Komplexer Zahlen

> [!NOTE]
> **Wirkungsweise:** Jede komplexe Zahl $z$ kann durch Betrag $|z|$ und Winkel (Argument) $\varphi$ dargestellt werden. Die Berechnung von $\varphi$ aus den kartesischen Koordinaten erfolgt mittels Arcuscosinus, wobei das Vorzeichen des Imaginärteils den Quadranten bestimmt.

<div align="right">19.12.23</div>

Sei $z = a + bi$ mit $a, b \in \mathbb{R}$. Dann existiert $\textcolor{#994ce6}{\varphi \in (-\pi; \pi]}$ so dass:
$z = |z|(\cos \textcolor{#994ce6}{\varphi} + i \sin \textcolor{#994ce6}{\varphi})$.

![](Vorlesungen_16-17/Vorlesungen_16-17_p5_Complex_Plane_Arccos_Illustration.excalidraw)

**Berechnung des Arguments $\varphi$:**
Es gilt $\cos \textcolor{#994ce6}{\varphi} = \frac{a}{|z|} = \frac{a}{\sqrt{a^2+b^2}}$.
Da der Wertebereich des $\arccos$ jedoch nur $[0; \pi]$ ist, müssen Fälle unterschieden werden:

1.  **Fall 1 ($b \ge 0$):** $\varphi \in [0; \pi] \implies \textcolor{#994ce6}{\varphi} = \arccos(\frac{a}{|z|})$.
2.  **Fall 2 ($b < 0$):** $\varphi \in (-\pi; 0)$. Da $\cos(\varphi) = \cos(-\varphi)$, gilt $\textcolor{#994ce6}{\varphi} = -\arccos(\frac{a}{|z|})$.

### Beispiel 9.11: Argumentberechnung
**1. $z = \sqrt{3} + 3i$**
$b = 3 \ge 0$ (Fall 1).
$\varphi = \arccos(\frac{\sqrt{3}}{\sqrt{3 + 9}}) = \arccos(\frac{\sqrt{3}}{\sqrt{12}}) = \arccos(\sqrt{\frac{1}{4}}) = \arccos(\frac{1}{2}) = \textcolor{#994ce6}{\frac{\pi}{3}}$.

**2. $z = 1 - i$**
$b = -1 < 0$ (Fall 2).
$\varphi = -\arccos(\frac{1}{\sqrt{1+1}}) = -\arccos(\frac{1}{\sqrt{2}}) = \textcolor{#994ce6}{-\frac{\pi}{4}}$.