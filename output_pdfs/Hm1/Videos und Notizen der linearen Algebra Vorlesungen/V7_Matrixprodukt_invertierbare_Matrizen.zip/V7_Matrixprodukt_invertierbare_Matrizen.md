# V7: Matrixprodukt und Invertierbare Matrizen

## 1. Produkt von Matrizen (1.12)

Seien $n, \textcolor{#4ce64c}{m}, \textcolor{#4ce6e6}{q} \in \mathbb{N}$.
Gegeben seien die Matrizen $A \in \mathbb{R}^{n \times \textcolor{#4ce64c}{m}}$ und $B \in \mathbb{R}^{\textcolor{#4ce64c}{m} \times \textcolor{#4ce6e6}{q}}$.

Ist $A=(a_{jk})_{j=1, k=1}^{n, \textcolor{#4ce64c}{m}}$ und $B=(b_{kl})_{k=1, l=1}^{\textcolor{#4ce64c}{m}, \textcolor{#4ce6e6}{q}}$, dann ist das Produkt $AB=C \in \mathbb{R}^{n \times \textcolor{#4ce6e6}{q}}$ mit $C=(c_{jl})_{j=1, l=1}^{n, \textcolor{#4ce6e6}{q}}$ definiert durch:

$$
c_{jl} = \sum_{k=1}^{\textcolor{#4ce64c}{m}} a_{jk} b_{kl}
$$

**Visuelle Darstellung (Zeile mal Spalte):**

$$
\begin{array}{cc}
\textcolor{#e64c4c}{j}\text{-te Zeile von A } (a_{\textcolor{#e64c4c}{j}1} \ a_{\textcolor{#e64c4c}{j}2} \ \dots \ a_{\textcolor{#e64c4c}{j}\textcolor{#4ce64c}{m}}) \cdot \begin{pmatrix} b_{1\textcolor{#4ce6e6}{l}} \\ b_{2\textcolor{#4ce6e6}{l}} \\ \vdots \\ b_{\textcolor{#4ce64c}{m}\textcolor{#4ce6e6}{l}} \end{pmatrix} & \textcolor{#4ce6e6}{l}\text{-te Spalte von B}
\end{array}
$$

**Alternative Spaltenschreibweise:**
$A \underbrace{(\vec{b}_1 | \dots | \vec{b}_q)}_{\substack{\text{Spalten} \\ \text{von } B}} = \underbrace{(A\vec{b}_1 | \dots | A\vec{b}_q)}_{\substack{\text{Spalten von} \\ AB}}$

> [!NOTE]
> Das Matrixprodukt verknüpft zwei Matrizen, indem die Zeilenvektoren der ersten Matrix mit den Spaltenvektoren der zweiten Matrix skalar multipliziert werden. Damit die Multiplikation definiert ist, muss die Spaltenanzahl der ersten Matrix zwingend gleich der Zeilenanzahl der zweiten Matrix sein.

### Beispiel 1.12.1: Berechnung
Berechnung des Produkts $A \cdot B$:

$$
\underbrace{\begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix}}_{A} \underbrace{\begin{pmatrix} 1 & 1 \\ 0 & 0,5 \end{pmatrix}}_{\vec{b}_{\textcolor{#e6994c}{1}}, \vec{b}_{\textcolor{#e6994c}{2}}} = \begin{pmatrix} 1 \cdot 1 + (-2) \cdot 0 & 1 \cdot 1 + (-2) \cdot 0,5 \\ 0 \cdot 1 + 2 \cdot 0 & 0 \cdot 1 + 2 \cdot 0,5 \end{pmatrix} = \underbrace{\begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}}_{A\vec{b}_{\textcolor{#e6994c}{1}} \quad A\vec{b}_{\textcolor{#e6994c}{2}}}
$$

**Alternative Berechnung über Spalten:**
*   $A\vec{b}_{\textcolor{#e6994c}{1}} = \begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix} \binom{\textcolor{#e6994c}{1}}{\textcolor{#e6994c}{0}} = \textcolor{#e6994c}{1} \binom{1}{0} + \textcolor{#e6994c}{0} \binom{-2}{2} = \binom{1}{0}$
*   $A\vec{b}_{\textcolor{#e6994c}{2}} = \begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix} \binom{\textcolor{#e6994c}{1}}{\textcolor{#e6994c}{0,5}} = \textcolor{#e6994c}{1} \binom{1}{0} + \textcolor{#e6994c}{0,5} \binom{-2}{2} = \binom{0}{1}$

Also gilt: $A (\vec{b}_{\textcolor{#e6994c}{1}} | \vec{b}_{\textcolor{#e6994c}{2}}) = (A\vec{b}_{\textcolor{#e6994c}{1}} | A\vec{b}_{\textcolor{#e6994c}{2}}) = \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}$.

### Eigenschaften der Matrixmultiplikation
Für alle $\alpha, \beta, \gamma \in K$ und alle Matrizen $A, B, C$, für die die Produkte definiert sind, gelten folgende Rechenregeln:

| Eigenschaft | Formel |
| :--- | :--- |
| **Distributivität (rechts)** | $(\alpha A + \beta B) C = \alpha AC + \beta BC$ |
| **Distributivität (links)** | $A (\beta B + \gamma C) = \beta AB + \gamma AC$ |
| **Assoziativität** | $(AB)C = A(BC)$ |

> [!WARNING]
> **Achtung:** Die Kommutativität ($AB = BA$) gilt im Allgemeinen **nicht**!

### Beispiel 1.12.2: Nicht-Kommutativität
Gegeben seien: $A = \begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix}, \ B = \begin{pmatrix} 1 & 0 \\ 1 & 1 \end{pmatrix}, \ C = \binom{2}{3}$.

**Vergleich $AB$ und $BA$:**
$$
\left.
\begin{aligned}
AB &= \overset{\rightarrow}{\begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix}} \overset{\downarrow}{\begin{pmatrix} 1 & 0 \\ 1 & 1 \end{pmatrix}} = \begin{pmatrix} 1 \cdot 1 + 1 \cdot 1 & 1 \cdot 0 + 1 \cdot 0 \\ 0 \cdot 1 + 0 \cdot 0 & 0 \cdot 0 + 0 \cdot 0 \end{pmatrix} = \begin{pmatrix} 2 & 0 \\ 0 & 0 \end{pmatrix} \\
BA &= \overset{\rightarrow}{\begin{pmatrix} 1 & 0 \\ 1 & 1 \end{pmatrix}} \overset{\downarrow}{\begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix}} = \begin{pmatrix} 1 \cdot 1 + 0 \cdot 0 & 1 \cdot 1 + 0 \cdot 0 \\ 1 \cdot 1 + 0 \cdot 0 & 1 \cdot 1 + 0 \cdot 0 \end{pmatrix} = \begin{pmatrix} 1 & 1 \\ 1 & 1 \end{pmatrix}
\end{aligned}
\right\} AB \neq BA
$$

**Definitionsbereich prüfen:**
*   $AC = \begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix} \binom{2}{3} = 2 \cdot \binom{1}{0} + 3 \cdot \binom{1}{0} = \binom{5}{0}$
*   $CA = \binom{2}{3} \begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix}$ ist **nicht definiert**, da $C \in \mathbb{R}^{2 \times \textcolor{#994ce6}{1}}$ aber $A \in \mathbb{R}^{\textcolor{#994ce6}{2} \times 2}$ (und $\textcolor{#994ce6}{1 \neq 2}$).

**Fazit:**
1.  $AB = BA$ gilt nicht immer.
2.  Möglicherweise ist $AC$ definiert, aber $CA$ nicht.

---

## 2. Invertierbare Matrizen (1.13)

### 2.1 Die Einheitsmatrix $I_n$
Sei das Kronecker-Delta definiert als:
$\delta_{jk} = \begin{cases} 1, & j=k \\ 0, & j \neq k \end{cases}$

Die Matrix $I_n = (\delta_{jk})_{j=1, k=1}^{n, n}$ heißt **Einheitsmatrix**.

**Beispiele:**
*   $I_2 = \begin{matrix} \textcolor{#4ce6e6}{1} & \textcolor{#4ce6e6}{2} \\ \textcolor{#e64c4c}{1} \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \\ \textcolor{#e64c4c}{2} \phantom{\begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}} \end{matrix}$
    *   $\delta_{\textcolor{#e64c4c}{1}\textcolor{#4ce6e6}{1}} = 1$ (da $\textcolor{#e64c4c}{1} = \textcolor{#4ce6e6}{1}$), $\delta_{\textcolor{#e64c4c}{1}\textcolor{#4ce6e6}{2}} = 0$ (da $\textcolor{#e64c4c}{1} \neq \textcolor{#4ce6e6}{2}$)
*   $I_3 = \begin{pmatrix} 1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 1 \end{pmatrix}$

**Eigenschaften:**
Es gilt für alle $A \in K^{n \times n}$ und $\vec{x} \in K^n$:
1.  $I_n A = A I_n = A$
2.  $I_n \vec{x} = \vec{x} \quad \textcolor{#e64c4c}{(1)}$

**Beweis zu (1) für n=2:**
$I_2 \begin{pmatrix} x_1 \\ x_2 \end{pmatrix} = \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \begin{pmatrix} x_1 \\ x_2 \end{pmatrix} = x_1 \cdot \begin{pmatrix} 1 \\ 0 \end{pmatrix} + x_2 \cdot \begin{pmatrix} 0 \\ 1 \end{pmatrix} = \begin{pmatrix} x_1 \\ x_2 \end{pmatrix}$

**Beweis $I_2 A = A$ für n=2:**
$\begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \begin{pmatrix} a & c \\ b & d \end{pmatrix} = \left( \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \begin{pmatrix} a \\ b \end{pmatrix} \middle| \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \begin{pmatrix} c \\ d \end{pmatrix} \right) \overset{\textcolor{#e64c4c}{(1)}}{=} \begin{pmatrix} a & c \\ b & d \end{pmatrix}$

> [!NOTE]
> Die Einheitsmatrix $I_n$ ist das neutrale Element der Matrixmultiplikation. Sie verhält sich analog zur Zahl 1 bei der Multiplikation reeller Zahlen: Eine Multiplikation mit $I_n$ verändert weder Vektoren noch Matrizen.

> [!TIP]
> **MentiFrage:** Sei $B \in \mathbb{R}^{2 \times 2}$. Wenn es Vektoren $\vec{v}_1, \vec{v}_2 \in \mathbb{R}^2$ gibt mit $B\vec{v}_1 = \binom{1}{0}$ und $B\vec{v}_2 = \binom{0}{1}$, dann gilt:
> 1. Bild $B = \mathbb{R}^2$
> 2. Bild $B \neq \mathbb{R}^2$
> 3. Es ist unklar, ob (1) oder (2) gilt
> 4. Keine Ahnung.

### 2.2 Definition & Motivation der Invertierbarkeit
Sei $A\vec{x} = \vec{b}$. Falls es eine Matrix $B$ gibt mit $BA = I_n$, dann gilt:
$A\vec{x}=\vec{b} \Rightarrow B(A\vec{x}) = B\vec{b} \Rightarrow I_n \vec{x} = B\vec{b} \Rightarrow \vec{x} = B\vec{b}$.

**Definition:**
$A \in K^{n \times n}$ heißt **invertierbar**, wenn ein $B \in \mathbb{R}^{n \times n}$ existiert mit $AB=BA=I_n$.
Man schreibt dann $B=A^{-1}$ (Inverse von A).

**Bemerkung 1.6:**
Ein $A \in \mathbb{R}^{n \times n}$ ist invertierbar $\Leftrightarrow \exists B \in \mathbb{R}^{n \times n}$ mit $AB=I_n$.
Es reicht also, eine der beiden Gleichheiten ($AB=I_n$ oder $CA=I_n$) zu überprüfen.

> [!NOTE]
> Die Invertierbarkeit einer Matrix garantiert, dass die durch sie beschriebene lineare Abbildung umkehrbar ist. Ist $A$ invertierbar, so lässt sich jedes Gleichungssystem $A\vec{x}=\vec{b}$ eindeutig durch $\vec{x}=A^{-1}\vec{b}$ lösen.

#### Beispiel 1.13.1: Prüfung der Inversen
Da $\begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix} \begin{pmatrix} 1 & 1 \\ 0 & 0.5 \end{pmatrix} \overset{\text{Bsp.}}{\underset{1.12.1}{=}} \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}$, folgt aus Bem. 1.6:
*   $\begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix}$ ist invertierbar.
*   Die Inverse ist $\begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix}^{-1} = \begin{pmatrix} 1 & 1 \\ 0 & 0.5 \end{pmatrix}$.

### 2.3 Berechnung von $A^{-1}$ (Gauß-Jordan-Algorithmus)
Ist $A \in \mathbb{R}^{n \times m}$ invertierbar, so kann die Inverse durch Zeilenumformungen (ZUF) an der erweiterten Matrix berechnet werden:
$$
(A \mid I_n) \xrightarrow{\text{ZUF}} (I_n \mid A^{-1})
$$

> [!NOTE]
> Um die Inverse zu berechnen, schreibt man die Matrix $A$ und die Einheitsmatrix $I_n$ nebeneinander. Durch elementare Zeilenoperationen wird $A$ in die Einheitsmatrix überführt; parallel dazu transformiert sich die ursprüngliche Einheitsmatrix zur gesuchten Inversen $A^{-1}$.

#### Beispiel 1.13.2: 2x2 Matrix
Sei $A = \begin{pmatrix} 1 & 2 \\ 2 & 6 \end{pmatrix} \in \mathbb{R}^{2 \times 2}$.

$\left( \begin{array}{cc|cc} 1 & 2 & \textcolor{#e6994c}{1} & \textcolor{#e6994c}{0} \\ 2 & 6 & \textcolor{#99e64c}{0} & \textcolor{#99e64c}{1} \end{array} \right) \xrightarrow{Z_2 \to Z_2 - 2Z_1} \left( \begin{array}{cc|cc} 1 & 2 & \textcolor{#e6994c}{1} & \textcolor{#e6994c}{0} \\ 0 & 2 & -2 & 1 \end{array} \right) \xrightarrow{Z_1 \to Z_1 - Z_2} \left( \begin{array}{cc|cc} 1 & 0 & 3 & -1 \\ 0 & 2 & -2 & 1 \end{array} \right) \xrightarrow{Z_2 \to 0.5 Z_2} \left( \begin{array}{cc|cc} 1 & 0 & \textcolor{#e6994c}{3} & \textcolor{#e6994c}{-1} \\ 0 & 1 & \textcolor{#99e64c}{-1} & \textcolor{#99e64c}{0.5} \end{array} \right)$

Also ist $A^{-1} = \begin{pmatrix} 3 & -1 \\ -1 & 0.5 \end{pmatrix}$.

**Wieso funktioniert dieser Algorithmus?**
Betrachten wir nur die erste Spalte der rechten Seite (Lösung für $\vec{e}_1$):
$\left( \begin{array}{cc|c} 1 & 2 & \textcolor{#99e64c}{1} \\ 2 & 6 & \textcolor{#99e64c}{0} \end{array} \right) \xrightarrow{\text{gleiche}}{\text{Umformungen}} \left( \begin{array}{cc|c} 1 & 0 & \textcolor{#99e64c}{3} \\ 0 & 1 & \textcolor{#99e64c}{-1} \end{array} \right)$

Dies entspricht dem Lösen von:
$1x_1 + 2x_2 = 1$
$2x_1 + 6x_2 = 0$
$\Rightarrow x_1 = \textcolor{#99e64c}{3}, \ x_2 = \textcolor{#99e64c}{-1}$.

Es gilt also:
$\begin{pmatrix} 1 & 2 \\ 2 & 6 \end{pmatrix} \begin{pmatrix} \textcolor{#99e64c}{3} \\ \textcolor{#99e64c}{-1} \end{pmatrix} = \begin{pmatrix} \textcolor{#99e64c}{1} \\ \textcolor{#99e64c}{0} \end{pmatrix}$ und analog $\begin{pmatrix} 1 & 2 \\ 2 & 6 \end{pmatrix} \begin{pmatrix} \textcolor{#e6994c}{-1} \\ \textcolor{#e6994c}{0.5} \end{pmatrix} = \begin{pmatrix} \textcolor{#e6994c}{0} \\ \textcolor{#e6994c}{1} \end{pmatrix}$.

Kombiniert ergibt dies:
$\begin{pmatrix} 1 & 2 \\ 2 & 6 \end{pmatrix} \begin{pmatrix} \textcolor{#99e64c}{3} & \textcolor{#e6994c}{-1} \\ \textcolor{#99e64c}{-1} & \textcolor{#e6994c}{0.5} \end{pmatrix} = \begin{pmatrix} \textcolor{#99e64c}{1} & \textcolor{#e6994c}{0} \\ \textcolor{#99e64c}{0} & \textcolor{#e6994c}{1} \end{pmatrix}$.

#### Beispiel 1.13.3: Nicht-invertierbare Matrix
<span style="color:#4d4d4d">Sei $B = \begin{pmatrix} 1 & 2 \\ 2 & 4 \end{pmatrix}$.</span>

<span style="color:#4d4d4d">$(B \,|\, I_2) = \left( \begin{array}{cc:cc} 1 & 2 & 1 & 0 \\ 2 & 4 & 0 & 1 \end{array} \right) \xrightarrow{z_2 \to z_2 - 2z_1} \left( \begin{array}{cc:cc} 1 & 2 & 1 & 0 \\ 0 & 0 & -2 & 1 \end{array} \right)$</span>

<span style="color:#4d4d4d">Hier sieht man, dass $B\vec{x} = \binom{1}{0}$ keine Lösung hat (denn die letzte Zeile impliziert $0x_1 + 0x_2 = -2$, was unmöglich ist). Also ist $B$ **nicht invertierbar**.</span>

#### Beispiel 1.13.4: 3x3 Matrix
Gesucht ist $\left( \begin{array}{ccc} 1 & 1 & 1 \\ 1 & 2 & 1 \\ 2 & 2 & 4 \end{array} \right)^{-1}$.

1.  Start:
    $\left( \begin{array}{ccc:ccc} 1 & 1 & 1 & 1 & 0 & 0 \\ 1 & 2 & 1 & 0 & 1 & 0 \\ 2 & 2 & 4 & 0 & 0 & 1 \end{array} \right) \xrightarrow[\substack{z_2 \to z_2 - z_1 \\ z_3 \to z_3 - 2z_1}]{} \left( \begin{array}{ccc:ccc} 1 & 1 & 1 & 1 & 0 & 0 \\ 0 & 1 & 0 & -1 & 1 & 0 \\ 0 & 0 & 2 & -2 & 0 & 1 \end{array} \right)$

2.  Normierung und Rückwärtselimination:
    $\xrightarrow[\substack{z_3 \to \frac{1}{2}z_3 \\ z_1 \to z_1 - z_2}]{} \left( \begin{array}{ccc:ccc} 1 & 0 & 1 & 2 & -1 & 0 \\ 0 & 1 & 0 & -1 & 1 & 0 \\ 0 & 0 & 1 & -1 & 0 & \frac{1}{2} \end{array} \right)$

3.  Finalisierung:
    $\xrightarrow{z_1 \to z_1 - z_3} \left( \begin{array}{ccc:ccc} 1 & 0 & 0 & 3 & -1 & -\frac{1}{2} \\ 0 & 1 & 0 & -1 & 1 & 0 \\ 0 & 0 & 1 & -1 & 0 & \frac{1}{2} \end{array} \right)$

<span style="color:#4d4d4d">Ergebnis:</span> $\left( \begin{array}{ccc} 1 & 1 & 1 \\ 1 & 2 & 1 \\ 2 & 2 & 4 \end{array} \right)^{-1} = \left( \begin{array}{ccc} 3 & -1 & -\frac{1}{2} \\ -1 & 1 & 0 \\ -1 & 0 & \frac{1}{2} \end{array} \right)$

---

## 3. Existenzsätze für Inversen (Satz 1.4)
<span style="color:#4d4d4d">Sei $A \in \mathbb{R}^{n \times n}$. Folgende Aussagen sind äquivalent:</span>
1.  <span style="color:#4d4d4d">$A$ ist invertierbar.</span>
2.  <span style="color:#4d4d4d">Bild $A = \mathbb{R}^n$ (d.h. $A\vec{x}=\vec{b}$ ist für alle $\vec{b}$ lösbar).</span>
3.  <span style="color:#4d4d4d">Kern $A = \{0\}$.</span>

> [!NOTE]
> Dieser Satz verknüpft die algebraische Eigenschaft der Invertierbarkeit mit den geometrischen Eigenschaften des Bildes und des Kerns. Eine Matrix ist genau dann invertierbar, wenn sie vollen Rang hat, also den gesamten Raum aufspannt (surjektiv) und der Nullraum nur den Nullvektor enthält (injektiv).

### 3.1 Beweisführung
**Teil 1: $A$ invertierbar $\Rightarrow$ Kern $A = \{0\}$**
<span style="color:#4d4d4d">Sei $A\vec{x} = \vec{0}$.</span>
<span style="color:#4d4d4d">$\Rightarrow A^{-1}(A\vec{x}) = \vec{0}$</span>
<span style="color:#4d4d4d">$\Rightarrow (A^{-1}A)\vec{x} = \vec{0}$</span>
<span style="color:#4d4d4d">$\Rightarrow I_n \vec{x} = \vec{0}$</span>
<span style="color:#4d4d4d">$\Rightarrow \vec{x} = \vec{0}$.</span>

**Teil 2: Bild $A = \mathbb{R}^n \Rightarrow A$ invertierbar (für $n=2$)**
<span style="color:#4d4d4d">$A\vec{x} = \binom{1}{0}$ hat eine Lösung $\vec{x}_1$, da $\binom{1}{0} \in$ Bild $A = \mathbb{R}^2$.</span>
<span style="color:#4d4d4d">Also $A\vec{x}_1 = \binom{1}{0}$. Ähnlich existiert ein $\vec{x}_2$ mit $A\vec{x}_2 = \binom{0}{1}$.</span>
<span style="color:#4d4d4d">Daraus folgt $A(\vec{x}_1 \,|\, \vec{x}_2) = (A\vec{x}_1 \,|\, A\vec{x}_2) = \left( \begin{smallmatrix} 1 & 0 \\ 0 & 1 \end{smallmatrix} \right) = I_2$.</span>

**Teil 3: $A$ invertierbar $\Rightarrow$ Bild $A = \mathbb{R}^n$**
<span style="color:#4d4d4d">Zu zeigen: $A\vec{x} = \vec{b}$ hat eine Lösung für alle $\vec{b} \in \mathbb{R}^n$.</span>

$A\vec{x} = \vec{b} \Leftrightarrow A^{-1}(A\vec{x}) = A^{-1}\vec{b}$
$\Leftrightarrow \underbrace{(A^{-1}A)}_{I_n}\vec{x} = A^{-1}\vec{b}$
$\Leftrightarrow I_n\vec{x} = \vec{x} = A^{-1}\vec{b}$
<span style="color:#4d4d4d">Die Lösung ist also explizit konstruierbar durch $\vec{x} = A^{-1}\vec{b}$.</span>