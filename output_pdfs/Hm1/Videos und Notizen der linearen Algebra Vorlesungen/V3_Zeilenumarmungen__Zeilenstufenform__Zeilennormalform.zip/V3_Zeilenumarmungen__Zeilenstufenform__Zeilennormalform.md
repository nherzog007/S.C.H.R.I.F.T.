# V3 Zeilenumformungen, Zeilenstufenform, Zeilennormalform

<span style="background-color:#994ce6">Zeilenumformungen, Zeilenstufenform, Zeilennormalform</span> (Helfen uns lineare Gleichungssysteme zu lösen, wie wir in 2 Wochen sehen werden).

## 1. Matrix-Grundlagen und Zeilenoperationen

Wir betrachten eine Matrix $V$:

$$
V = \begin{pmatrix} v_{11}, v_{12}, \dots, v_{1m} \\ v_{21}, v_{22}, \dots, v_{2m} \\ v_{n1}, v_{n2}, \dots, v_{nm} \end{pmatrix}
$$

**Definition der Elemente:**
*   $\textcolor{#e64c4c}{v_{k,l}}$: Element der $\textcolor{#e64c4c}{k}$-ten Zeile und $\textcolor{#4ce6e6}{l}$-ten Spalte (Zeilen zuerst, Spalten später).
*   $V$ ist dann eine $\textcolor{#e64c4c}{n} \times \textcolor{#4ce6e6}{m}$ Matrix ($\textcolor{#e64c4c}{n}$ Zeilen, $\textcolor{#4ce6e6}{m}$ Spalten).

> [!NOTE]
> Matrizen dienen als strukturierte Datentabellen, die lineare Gleichungssysteme kompakt darstellen; die Indizes ermöglichen den präzisen Zugriff auf Koeffizienten basierend auf Zeile und Spalte.

### 1.1 Elementare Zeilenumformungen
Im Zusammenhang mit **LGS (linearen Gleichungssystemen)** entsprechen diese Operationen den folgenden Äquivalenzumformungen:

| Typ | Operation | Mathematische Notation | Bedeutung im LGS |
| :--- | :--- | :--- | :--- |
| **(U1)** | Skalierung | $Z_j \to \alpha Z_j$ , $\alpha \in K \setminus \{0\}$ | Multiplikation einer Gleichung mit $\alpha \neq 0$ |
| **(U2)** | Addition | $Z_j \to Z_j + \beta Z_k$ , $\beta \in K$ , $k \neq j$ | Addition eines Vielfachen einer Gleichung zu einer anderen |
| **(U3)** | Vertauschung | $Z_i \leftrightarrow Z_j$ | Vertauschung von zwei Gleichungen |

*Anmerkung:* $K=\mathbb{R}$ oder $K=\mathbb{C}$.

> [!NOTE]
> Elementare Zeilenumformungen verändern die Gestalt der Matrix, erhalten aber die Lösungsmenge des zugehörigen linearen Gleichungssystems (Äquivalenzumformungen).

### Beispiel 1.5.1: Anwendung der Operationen

Gegeben sei die Matrix mit den Zeilen $z_1, z_2, z_3$:
$$
\begin{pmatrix} 1 & 3 & 4 \\ 2 & -5 & 8 \\ \textcolor{#4ce6e6}{4} & \textcolor{#4ce6e6}{2} & \textcolor{#4ce6e6}{1} \end{pmatrix}
$$

**Durchgeführte Schritte:**

1.  **Skalierung:** Die dritte Zeile wird verdoppelt ($z_3 \to 2z_3$).
    $$
    \xrightarrow{z_3 \to 2z_3} \begin{pmatrix} 1 & 3 & 4 \\ 2 & -5 & 8 \\ \textcolor{#e6994c}{2} \cdot \textcolor{#4ce6e6}{4} & \textcolor{#e6994c}{2} \cdot \textcolor{#4ce6e6}{2} & \textcolor{#e6994c}{2} \cdot \textcolor{#4ce6e6}{1} \end{pmatrix}
    $$

2.  **Vertauschung:** Zeile 3 und Zeile 2 werden getauscht ($z_3 \leftrightarrow z_2$).
    $$
    \xrightarrow{z_3 \leftrightarrow z_2} \begin{pmatrix} 1 & 3 & 4 \\ \textcolor{#4ce6e6}{4} & \textcolor{#4ce6e6}{2} & \textcolor{#4ce6e6}{1} \\ 2 & -5 & 8 \end{pmatrix}
    $$

3.  **Addition:** Zur ersten Zeile wird das 5-fache der dritten Zeile addiert ($z_1 \to z_1 + 5z_3$).
    $$
    \xrightarrow{z_1 \to z_1 + 5z_3} \begin{pmatrix} 1+\textcolor{#e64c4c}{5}\cdot\textcolor{#4ce6e6}{4} & 3+\textcolor{#e64c4c}{5}\cdot\textcolor{#4ce6e6}{2} & 4+\textcolor{#e64c4c}{5}\cdot\textcolor{#4ce6e6}{1} \\ 2 & -5 & 8 \\ \textcolor{#4ce6e6}{4} & \textcolor{#4ce6e6}{2} & \textcolor{#4ce6e6}{1} \end{pmatrix} = \begin{pmatrix} 21 & 13 & 9 \\ 2 & -5 & 8 \\ \textcolor{#4ce6e6}{4} & \textcolor{#4ce6e6}{2} & \textcolor{#4ce6e6}{1} \end{pmatrix}
    $$

---

## 2. Zeilenstufenform (ZSF)

### 2.1 Definition
Eine Matrix $C$ ist in <span style="text-decoration:underline">Zeilenstufenform</span> (ZSF), falls es ein $\textcolor{#e6994c}{r} \in \{0, \dots, n\}$ und Indizes $1 \leqslant \textcolor{#e64c4c}{k_1} < \textcolor{#e64c4c}{k_2} < \dots < \textcolor{#e64c4c}{k_r} \leqslant \textcolor{#e6994c}{m}$ gibt, sodass folgende Bedingungen erfüllt sind:

1.  **(i) Stufenstruktur:** Für $\textcolor{#e64c4c}{j} = 1, \dots, \textcolor{#e6994c}{r}$ gilt:
    *   $c_{jl}=0$ für alle $l=1, \dots, \textcolor{#e64c4c}{k_j}-1$.
    *   Das Pivotelement $\textcolor{#4ce64c}{d_j} := c_{j\textcolor{#e64c4c}{k_j}} \neq 0$.
    *   <span style="text-decoration:underline">In Worten:</span> Das <span style="color:#99e64c">erste Element</span> einer Zeile, <span style="color:#99e64c">das $\neq 0$ ist</span>, kommt immer später (weiter rechts) als in der vorigen Zeile.

2.  **(ii) Nullzeilen:** Für $j = \textcolor{#e6994c}{r}+1, \dots, \textcolor{#e6994c}{n}$ gilt $c_{jk}=0 \quad \forall k=1, \dots, \textcolor{#e6994c}{m}$.
    *   Alle Zeilen nach der $\textcolor{#e6994c}{r}$-ten sind komplett 0.
    *   Wenn $\textcolor{#e6994c}{r=n}$, setzt Bedingung (ii) nichts voraus.
    *   Wenn z.B. $\textcolor{#e6994c}{r=n-2}$, dann impliziert (ii), dass die Zeilen $z_{n-1}, z_n$ Null sind.

**Visualisierung:**
![](V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform/V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform_p1_Diagram_1.excalidraw)

> [!NOTE]
> Die Zeilenstufenform organisiert ein Gleichungssystem in einer "Treppenstruktur", bei der Variablen systematisch eliminiert wurden, was das Lösen durch Rückwärtseinsetzen ermöglicht.

### Beispiel 1.5.2: Identifikation der ZSF

Die folgende Matrix $C$ ist in Zeilenstufenform (ZSF):

$$
\begin{array}{cl}
& \begin{matrix} \textcolor{#4ce6e6}{1} & \textcolor{#4ce6e6}{2} & \textcolor{#4ce6e6}{3} & \textcolor{#4ce6e6}{4} & \textcolor{#4ce6e6}{5} \end{matrix} \\
\begin{matrix} \textcolor{#e64c4c}{1} \\ \textcolor{#e64c4c}{2} \\ \textcolor{#e64c4c}{3} \\ \textcolor{#e64c4c}{4} \end{matrix} & \left( \begin{matrix} \textcolor{#99e64c}{3} & 0 & 1 & 2 & 3 \\ 0 & 0 & \textcolor{#99e64c}{5} & 0 & 4 \\ 0 & 0 & 0 & \textcolor{#99e64c}{1} & 1 \\ 0 & 0 & 0 & 0 & 0 \end{matrix} \right)
\end{array}
$$

**Analyse:**
*   $\textcolor{#99e64c}{\text{Grüne Elemente}}$: Erstes Element, das nicht 0 ist.
*   $C_{32} = 0$: Die Treppen können länger als 1 Schritt sein, aber die Höhe darf nicht höher als 1 Zeile sein.

**Parameter:**
*   $\left. \begin{aligned} k_1 &= \textcolor{#4ce6e6}{1} \\ d_1 &= \textcolor{#99e64c}{3} \end{aligned} \right\}$ (Erstes Element der \textcolor{#e64c4c}{1.} Zeile $\neq 0$ ist in Spalte \textcolor{#4ce6e6}{1} und Wert \textcolor{#99e64c}{3})
*   $\begin{aligned} k_2 &= \textcolor{#4ce6e6}{3}, & d_2 &= \textcolor{#99e64c}{5} \\ k_3 &= \textcolor{#4ce6e6}{4}, & d_3 &= \textcolor{#99e64c}{1} \end{aligned}$
*   Es gilt $\textcolor{#e64c4c}{k_1 < k_2 < k_3}$.
*   Rang $\textcolor{#e6994c}{r=3}$ (alle Zeilen nach der 3. sind 0).

**Gegenbeispiel (Nicht in ZSF):**
$\begin{pmatrix} 1 & 2 & 7 & 4 & 5 \\ 0 & 5 & 9 & 10 & -1 \\ 0 & 4 & 8 & 6 & 0 \\ 0 & 0 & 0 & 1 & 0 \end{pmatrix}$ (Hier steht unter der 5 eine 4 $\neq 0$).

![](V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform/V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform_p2_Stufenlinie_in_Matrix_C.excalidraw)

**Interaktions-Frage:**
Warum könnte das Verständnis solcher abstrakter Definitionen relevant für die Elektrotechnik sein?

### 2.2 Satz 1.3.1: Algorithmus zur ZSF

Jede Matrix $C \in K^{n \times m}$ ($n$ Zeilen, $m$ Spalten) kann durch endlich viele Zeilenumformungen in ZSF überführt werden.

**Beweisidee / Verfahren (Gauß-Algorithmus):**
Wir betrachten die erste Spalte:
1.  **Fall 1:** Sie ist überall $0$. Dann wird sie gestrichen (wir ignorieren sie und rücken nach rechts).
2.  **Fall 2 (sonst):** Wir suchen <span style="color:#4ce6e6">das erste Element, das $\neq 0$ ist</span>, sei dies $\textcolor{#4ce6e6}{c_{j1}}$.
    *   Elimination: Für alle Zeilen $\textcolor{#e64c4c}{l=j+1, \dots, n}$ ziehen wir von der $\textcolor{#e64c4c}{l}$-ten Zeile das $\frac{\textcolor{#e64c4c}{c_{l1}}}{\textcolor{#4ce6e6}{c_{j1}}}$-fache der $j$-ten Zeile ab:
        $$z_l \rightarrow z_l - \frac{\textcolor{#e64c4c}{c_{l1}}}{\textcolor{#4ce6e6}{c_{j1}}} z_j$$
    *   Dadurch wird das erste Element der Zeilen $j+1, \dots, n$ zu $\textcolor{#99e64c}{0}$.
    *   Sortieren: Falls $\textcolor{#e6994c}{j} > 1$, tauschen wir $z_j \leftrightarrow z_1$.
    *   Iteration: Die erste Zeile und Spalte werden nun "gedanklich gestrichen/fixiert", und das Verfahren wird auf den Rest der Matrix wiederholt, bis ZSF erreicht ist.

> [!NOTE]
> Dieser Algorithmus entspricht der Gauß-Elimination, welche systematisch Spalte für Spalte Nullen unterhalb der Diagonalen erzeugt, um die Matrix in eine lösbare Dreiecksform zu bringen.

### Beispiel 1.5.3: Schrittweise Berechnung

Startmatrix (Wir wählen $j=2$ als Pivot, da $c_{21}=1$ praktisch ist):
$$
\textcolor{#e6994c}{j=2} \leftarrow \begin{pmatrix} 0 & 0 & 3 & -5 \\ \textcolor{#4ce6e6}{1} & 0 & -2 & 4 \\ \textcolor{#e64c4c}{2} & 0 & -13 & 23 \\ \textcolor{#e64c4c}{1} & 0 & 1 & -2 \end{pmatrix}
$$

**Schritt 1: Elimination in Spalte 1**
Wir eliminieren die Einträge unterhalb des Pivots (Zeilen 3 und 4):
$$
\begin{matrix}
z_3 \rightarrow z_3 - \frac{\textcolor{#e64c4c}{2}}{\textcolor{#4ce6e6}{1}} z_2 \\
\xrightarrow{\hspace*{2cm}} \\
z_4 \rightarrow z_4 - \frac{\textcolor{#e64c4c}{1}}{\textcolor{#4ce6e6}{1}} z_2
\end{matrix}
\begin{pmatrix} 0 & 0 & 3 & -5 \\ \textcolor{#4ce6e6}{1} & 0 & -2 & 4 \\ \textcolor{#99e64c}{0} & 0 & -9 & 15 \\ \textcolor{#99e64c}{0} & 0 & 3 & -6 \end{pmatrix}
$$

**Schritt 2: Sortieren**
Tausch der Pivotzeile nach oben ($z_2 \leftrightarrow z_1$), da $\textcolor{#e6994c}{2} > 1$:
$$
\begin{matrix}
z_2 \leftrightarrow z_1 \\
\xrightarrow{\hspace*{1cm}}
\end{matrix}
\begin{pmatrix} 1 & 0 & -2 & 4 \\ \colorbox{#d3d3d3}{\( 0 \)} & \colorbox{#d3d3d3}{\( 0 \)} & 3 & -5 \\ 0 & 0 & -9 & 15 \\ 0 & 0 & 3 & -6 \end{pmatrix}
$$
*Die 2. Spalte wird gestrichen/ignoriert, da sie im relevanten Bereich nur Nullen enthält (Fall 1).*

**Schritt 3: Elimination im nächsten Block**
Pivot ist nun $3$ in der neuen 2. Zeile. Elimination darunter:
$$
\begin{matrix}
z_3 \rightarrow z_3 - \frac{-9}{3} z_2 \\
\xrightarrow{\hspace*{2cm}} \\
z_4 \rightarrow z_4 - \frac{3}{3} z_2
\end{matrix}
\begin{pmatrix} 1 & 0 & -2 & 4 \\ 0 & 0 & 3 & 5 \\ 0 & 0 & \textcolor{#99e64c}{0} & 0 \\ 0 & 0 & \textcolor{#99e64c}{0} & -1 \end{pmatrix}
$$

**Schritt 4: Abschluss**
Letzter Tausch ($z_3 \leftrightarrow z_4$), um die Nullzeile nach unten zu bringen:
$$
\begin{matrix}
z_3 \leftrightarrow z_4 \\
\xrightarrow{\hspace*{1cm}}
\end{matrix}
\begin{pmatrix} 1 & 0 & -2 & 4 \\ 0 & 0 & 3 & 5 \\ 0 & 0 & 0 & -1 \\ 0 & 0 & 0 & 0 \end{pmatrix}
$$

> [!CAUTION]
> Das "Streichen" von Spalten im Algorithmus dient nur der Illustration der Fokus-Region. In Aufgaben muss man dies nicht physisch tun.

---

## 3. Zeilennormalform (ZNF)

### 3.1 Definition
Eine Matrix in Zeilenstufenform (ZSF) ist in <span style="text-decoration:underline">Zeilennormalform</span> (ZNF), wenn zusätzlich gilt:

**(iii) Normierung und Bereinigung:**
*   $\forall j=1,...,r$ gilt $\textcolor{#e64c4c}{d_j=1}$. (Für jede Zeile ist das erste Element $\neq 0$ immer 1).
*   $\textcolor{#e6994c}{C_{lk_j}=0 \quad \forall l=1,...,j-1}$.
*   <span style="text-decoration:underline">In Worten:</span> $\textcolor{#e6994c}{\text{Oberhalb von } \textcolor{#e64c4c}{d_j} \text{ stehen nur Nullen}}$.

**Beispiel einer ZNF:**
$$
\begin{pmatrix}
\textcolor{#e64c4c}{1} & \textcolor{#e6994c}{0} & 3 & \textcolor{#e6994c}{0} & 2 \\
0 & \textcolor{#e64c4c}{1} & 5 & \textcolor{#e6994c}{0} & 1 \\
0 & 0 & 0 & \textcolor{#e64c4c}{1} & 0 \\
0 & 0 & 0 & 0 & 0
\end{pmatrix}
$$

> [!NOTE]
> Die Zeilennormalform (Gauß-Jordan-Form) führt die Vereinfachung weiter: Jedes Pivotelement ist 1 und ist der einzige Eintrag ungleich Null in seiner Spalte, was das direkte Ablesen der Lösung ermöglicht.

### 3.2 Satz und Berechnung
**Satz:** Jede Matrix in ZSF kann in ZNF durch endlich viele Umformungen überführt werden.

### Beispiel 1.5.5: Überführung ZSF in ZNF

Ausgangsmatrix (aus vorigem Beispiel in ZSF):
$$
\begin{pmatrix}
1 & 2 & -2 & 4 \\
0 & 0 & 3 & -5 \\
0 & 0 & 0 & -1 \\
0 & 0 & 0 & 0
\end{pmatrix}
$$

**Schritt 1: Normierung der Pivots auf 1**
Wir teilen $z_2$ durch 3 und $z_3$ durch -1:
$$
\xrightarrow[\substack{z_3 \to -1 z_3}]{z_2 \to \frac{1}{3} z_2}
\begin{pmatrix}
\textcolor{#e64c4c}{1} & 2 & -2 & 4 \\
0 & 0 & \textcolor{#e64c4c}{1} & -\frac{5}{3} \\
0 & 0 & 0 & \textcolor{#e64c4c}{1} \\
0 & 0 & 0 & 0
\end{pmatrix}
$$

**Schritt 2: Rückwärts-Elimination (Erzeugen von Nullen oberhalb)**
Wir nutzen die Pivot-Eins in Zeile 3, um darüber aufzuräumen:
$$
\xrightarrow[\substack{z_1 \to z_1 - 4 z_3}]{z_2 \to z_2 + \frac{5}{3} z_3}
\begin{pmatrix}
\textcolor{#e64c4c}{1} & 2 & -2 & 0 \\
0 & 0 & \textcolor{#e64c4c}{1} & 0 \\
0 & 0 & 0 & \textcolor{#e64c4c}{1} \\
0 & 0 & 0 & 0
\end{pmatrix}
$$

**Schritt 3: Abschluss**
Wir nutzen die Pivot-Eins in Zeile 2, um in Zeile 1 die -2 zu eliminieren:
$$
\xrightarrow{z_1 \to z_1 + 2 z_2}
\begin{pmatrix}
\textcolor{#e64c4c}{1} & 2 & 0 & 0 \\
0 & 0 & \textcolor{#e64c4c}{1} & 0 \\
0 & 0 & 0 & \textcolor{#e64c4c}{1} \\
0 & 0 & 0 & 0
\end{pmatrix}
$$

---

## 4. Anwendung: Lineare Unabhängigkeit

**Bemerkung:** Nächstes Mal werden wir illustrieren, dass:

1.  Die Zeilen einer Matrix sind linear unabhängig $\iff$ die Zeilen der umgeformten Matrix sind linear unabhängig.
2.  Die Zeilen einer Matrix in ZSF sind linear unabhängig $\iff$ wenn die Matrix keine Nullzeile hat.

**Schlussfolgerung:**
Aus (1) und (2) folgt ein Verfahren zur Prüfung der linearen Unabhängigkeit von Vektoren $\vec{v}_1, ..., \vec{v}_n$:
1.  Wir überführen die Matrix $C = \begin{pmatrix} \vec{v}_1 \\ \vdots \\ \vec{v}_n \end{pmatrix}$ in ZSF.
2.  Dann gilt: $\vec{v}_1, ..., \vec{v}_n$ sind linear unabhängig $\iff$ die Matrix in ZSF hat **keine Nullzeilen**.

*Beispiel:* $\vec{v}_1 = (0;0;3;-5)$, $\vec{v}_2 = (1;0;-2;4)$, $\vec{v}_3 = (2;0;-13;23)$, $\vec{v}_4 = (1;0;1;2)$ sind **linear abhängig**, da im Bsp. 1.5.3 eine Nullzeile entstand.

> [!NOTE]
> Die Überführung in ZSF dient als algorithmischer Test auf lineare Unabhängigkeit: Verschwindet eine Zeile komplett (wird zur Nullzeile), war der ursprüngliche Vektor eine Linearkombination der anderen.

![](V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform/V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform_p3_Diagram_1.excalidraw)

![](V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform/V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform_p3_Diagram_2.excalidraw)

![](V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform/V3_Zeilenumarmungen__Zeilenstufenform__Zeilennormalform_p3_Diagram_3.excalidraw)