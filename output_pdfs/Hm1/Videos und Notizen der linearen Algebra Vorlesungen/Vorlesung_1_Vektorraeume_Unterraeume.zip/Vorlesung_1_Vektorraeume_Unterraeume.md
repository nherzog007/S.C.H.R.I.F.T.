# Vorlesung 1: Vektorräume und Unterräume

## 1. Motivation und Problemstellung

<div style="text-align: right;">06.11.25</div>

![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p1_Electrical_Circuit_Network.excalidraw)

Das folgende Netzwerkproblem lässt sich durch ein lineares Gleichungssystem beschreiben. Dabei gelten folgende Zuordnungen:

*   $\textcolor{#e64c4c}{I_j}$: <span style="color:#e64c4c">Ströme (unbekannt)</span>
*   $\textcolor{#99e64c}{U}$: <span style="color:#99e64c">Spannung (bekannt)</span>
*   $\textcolor{#4c99e6}{R_j}$: <span style="color:#4c99e6">Widerstände (bekannt)</span>

Das resultierende System aus Knoten- und Maschengleichungen lautet:

$$
\left\{
\begin{array}{@{}l@{}}
  \left.
  \begin{array}{rcrcrcr}
    \textcolor{#e64c4c}{I_1} & & & -\textcolor{#e64c4c}{I_3} & -\textcolor{#e64c4c}{I_4} & & & = 0 \\
    & -\textcolor{#e64c4c}{I_2} & +\textcolor{#e64c4c}{I_3} & & & +\textcolor{#e64c4c}{I_5} & & = 0 \\
    & & & \textcolor{#e64c4c}{I_4} & & -\textcolor{#e64c4c}{I_5} & -\textcolor{#e64c4c}{I_6} & = 0
  \end{array}
  \quad \right\} \text{ Knotengleichungen} \\[2.5em]
  \left.
  \begin{array}{rcrcrcr}
    \textcolor{#4c99e6}{R_1}\textcolor{#e64c4c}{I_1} & +\textcolor{#4c99e6}{R_2}\textcolor{#e64c4c}{I_2} & +\textcolor{#4c99e6}{R_3}\textcolor{#e64c4c}{I_3} & & & & & = \textcolor{#99e64c}{U} \\
    & & \textcolor{#4c99e6}{R_3}\textcolor{#e64c4c}{I_3} & -\textcolor{#4c99e6}{R_4}\textcolor{#e64c4c}{I_4} & & -\textcolor{#4c99e6}{R_5}\textcolor{#e64c4c}{I_5} & & = 0 \\
    & \textcolor{#4c99e6}{R_2}\textcolor{#e64c4c}{I_2} & & & & +\textcolor{#4c99e6}{R_5}\textcolor{#e64c4c}{I_5} & -\textcolor{#4c99e6}{R_6}\textcolor{#e64c4c}{I_6} & = 0
  \end{array}
  \quad \right\} \text{ Maschengleichungen}
\end{array}
\right.
$$

**Kernfragen der Linearen Algebra:**
1.  Hat das System der Gleichungen Lösungen?
2.  Wie viele Lösungen gibt es?
3.  Wie kann man sie bestimmen?

> [!NOTE]
> **Zusammenfassung**
> Komplexe physikalische oder technische Systeme lassen sich oft als lineare Gleichungssysteme modellieren. Die Lineare Algebra liefert die Werkzeuge, um Existenz und Eindeutigkeit von Lösungen für solche Systeme (Vektoren von Unbekannten) systematisch zu untersuchen.

## 2. Grundlagen der Vektorräume

### 2.1 Der Raum $\mathbb{R}^n$ und $K^n$

Die bekannten Zahlenräume lassen sich systematisch erweitern:

*   **$\mathbb{R}^2$:** $\mathbb{R} \times \mathbb{R} = \{ (a,b) : a \in \mathbb{R}, b \in \mathbb{R} \}$
    ![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p2_2D_Coordinate_System_Point_ab.excalidraw)
*   **$\mathbb{R}^3$:** $\mathbb{R} \times \mathbb{R} \times \mathbb{R} = \{ (a,b,c) : a,b,c \in \mathbb{R} \}$
    ![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p2_3D_Coordinate_System_Point_abc.excalidraw)
*   **$\mathbb{R}^4$:** $\mathbb{R} \times \mathbb{R} \times \mathbb{R} \times \mathbb{R} = \{ (a,b,c,d) : a,b,c,d \in \mathbb{R} \}$

<span style="background-color:#e64c4c">Interaktionsfrage:</span> $\mathbb{R}^n \leadsto$ Warum ergibt es Sinn $\mathbb{R}^n$ für $n>3$ zu studieren?

#### Definition 1.1: Kartesisches Produkt ($K^n$)
Sei $K=\mathbb{R}$ oder $K=\mathbb{C}$.

$$K^n = \underbrace{K \times K \times ... \times K}_{n-\text{mal}} = \{ (x_1, ..., x_n) : x_j \in K, \forall j=1,...,n \}$$

Wir definieren die Operationen Addition ($+$) und Skalarmultiplikation ($\cdot$) wie folgt:

1.  **Addition:** $+: K^n \times K^n \to K^n$
    $$(x_1, ..., x_n) + (y_1, ..., y_n) = (x_1 + y_1, ..., x_n + y_n)$$
2.  **Skalarmultiplikation:** $\cdot: K \times K^n \to K^n$

> [!NOTE]
> **Funktionsweise der Operationen**
> Die Notation $+: \textcolor{#4c99e6}{K^n \times K^n} \to \textcolor{#99e64c}{K^n}$ bedeutet, dass die Addition zwei Vektoren als "\textcolor{#4c99e6}{Input}" nimmt und einen neuen Vektor als "\textcolor{#99e64c}{Output}" liefert. Die Operationen erfolgen komponentenweise.

#### Beispiel 1.1.1: Rechenoperationen in $\mathbb{R}^2$
Sei $\mathbb{R}^2 = \{ (x,y) : x \in \mathbb{R}, y \in \mathbb{R} \}$.
Berechnung:
$$5 \cdot (1,2) + (3,6) = (5,10) + (3,6) = (8,16)$$

Darstellung im $\mathbb{R}^3 = \{ (x,y,z) : x,y,z \in \mathbb{R} \}$:
![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p2_3D_Vector_Example_234.excalidraw)

### 2.2 Axiomatik des Vektorraums

Ein <span style="background-color:#994ce6">K-Vektorraum</span> (oder Vektorraum über $K$) ist eine Menge $V$ mit zwei Verknüpfungen:
*   Addtion: $+: V \times V \to V$
*   Skalarmultiplikation: $\cdot: K \times V \to V$ ($\textcolor{#994ce6}{\longleftarrow \text{Skalar mal Vektor}}$)

Diese müssen folgende Axiome (V1–V7) erfüllen:

| Axiom | Beschreibung | Formel |
| :--- | :--- | :--- |
| **V1** | Assoziativität ($+$) | $(x+y)+z = x+(y+z) \quad \forall x,y,z \in V$ |
| **V2** | Kommutativität ($+$) | $x+y = y+x \quad \forall x,y \in V$ |
| **V3** | Neutrales Element ($+$) | $\exists 0 \in V \text{ mit } x+0=x, \forall x \in V$ |
| **V4** | Inverses Element ($+$) | $\forall x \in V, \exists -x \in V \text{ mit } x+(-x)=0$ |
| **V5** | Assoziativität ($\cdot$) | $\alpha \cdot (\beta x) = (\alpha \beta)x \quad \forall \alpha, \beta \in K, \forall x \in V$ |
| **V6** | Distributivität 1 | $\alpha \cdot (x+y) = \alpha x + \alpha y \quad \forall \alpha \in K, \forall x,y \in V$ |
| **V7** | Neutrales Element ($\cdot$) | $1 \cdot x = x \quad \forall x \in V$ |

> [!TIP]
> Nicht auswendig lernen $\longrightarrow$ siehe Formelsammlung.

> [!NOTE]
> **Zusammenfassung Vektorraum**
> Ein Vektorraum ist eine abstrakte Struktur, die das Verhalten des $\mathbb{R}^n$ verallgemeinert. Sie erlaubt das "Zusammenfassen von Vektoren" und garantiert, dass Rechenregeln (wie Kommutativität oder Distributivität) universell gelten.

#### Beispiel 1.1.2: Funktionenräume
Neben den Standardräumen $\mathbb{R}^n$ (bzw. $\mathbb{C}^n$) ist auch die Menge aller Funktionen auf einem Intervall ein Vektorraum.

Sei $A = \{f: [0,1] \to \mathbb{R}\}$ (Funktionen mit reellen Werten für $0 \le x \le 1$).
Die Operationen sind definiert als:
1.  **Addition:** $(f+g)(x) = f(x) + g(x)$
2.  **Skalarmultiplikation:** $(\alpha \cdot f)(x) = \alpha f(x)$

*Anwendung:*
*   Sei $f(x) = \sin x$ und $g(x) = \cos x$.
*   Dann ist $(f+g)(x) = \sin x + \cos x$.
*   Und $(5 \cdot f)(x) = 5 \sin(x)$.

Dieser Raum $A$ ist ein $\mathbb{R}$-Vektorraum.

#### Beispiel 1.1.3: Gegenbeispiel (Rand des Einheitsquadrats)
Sei $\textcolor{#e6994c}{A} = \{(x,y) \in \mathbb{R}^2 : \max \{|x|, |y|\} = 1 \}$.
Beispielrechnung: $\max \{2,3\} = 3$.

![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p3_MaxNorm_UnitSquare.excalidraw)

Die Bedingung $\max \{|x|, |y|\} = 1$ bedeutet:
*   $(|x|=1 \text{ und } |y| \le 1)$ ODER $(|y|=1 \text{ und } |x| \le 1)$
*   Detailliert:
    *   $\textcolor{#4ce6e6}{x=1 \lor x=-1} \quad \text{und} \quad -1 \le y \le 1$
    *   $\textcolor{#e6994c}{y=1 \lor y=-1} \quad \text{und} \quad -1 \le x \le 1$

**Prüfung der Vektorraumeigenschaft:**
Mit den Standardoperationen von $\mathbb{R}^2$ ist $\textcolor{#e6994c}{A}$ **kein** Vektorraum.
*Grund:* Die Abgeschlossenheit der Addition ist verletzt.
*   $v_1 = (1,1) \in \textcolor{#e6994c}{A}$
*   $v_2 = (1,-1) \in \textcolor{#e6994c}{A}$
*   Aber: $v_1 + v_2 = (1,1) + (1,-1) = (2,0) \notin \textcolor{#e6994c}{A}$

Daraus folgt: $+ : A \times A \to A$ gilt nicht $\textcolor{#e6994c}{!}$.

## 3. Untervektorräume (Lineare Teilräume)

### 3.1 Definition 1.2
Sei $V$ ein $K$-Vektorraum und $\textcolor{#e64c4c}{U} \subseteq V, \textcolor{#e64c4c}{U} \neq \emptyset$.
$\textcolor{#e64c4c}{U}$ heißt **Unter(-vektor-)raum** oder **linearer Teilraum** von $V$, wenn die Menge bezüglich der Operationen "abgeschlossen" ist:

1.  **Abgeschlossenheit bzgl. Addition:**
    $\forall x,y \in \textcolor{#e64c4c}{U}$ gilt $x+y \in \textcolor{#e64c4c}{U}$
2.  **Abgeschlossenheit bzgl. Skalarmultiplikation:**
    $\forall x \in \textcolor{#e64c4c}{U}, \forall \alpha \in K$ gilt $\alpha x \in \textcolor{#e64c4c}{U}$

> [!NOTE]
> **Zusammenfassung Unterraum**
> Ein Unterraum ist eine Teilmenge eines Vektorraums, die selbst wieder eine vollständige Vektorraumstruktur besitzt. Das entscheidende Kriterium ist, dass man durch Addition von Elementen oder Multiplikation mit Skalaren die Teilmenge nie "verlässt".

### 3.2 Beispiele und Gegenbeispiele

#### Beispiel 1.2.1: Die x-Achse im $\mathbb{R}^2$
Sei $V = \mathbb{R}^2$ und $\textcolor{#e64c4c}{U} = \{(x,y) \in \mathbb{R}^2 : \textcolor{#e64c4c}{y=0}\} = \{(x,0) : x \in \mathbb{R}\}$.

![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p3_Subspace_U_Line.excalidraw)

**Überprüfung:**
1.  **Addition:** Seien $a,b \in \textcolor{#e64c4c}{U}$. Dann existieren $x_1, x_2 \in \mathbb{R}$ mit $a=(x_1, 0), b=(x_2, 0)$.
    $$a+b = (x_1+x_2, 0) \in \textcolor{#e64c4c}{U}$$
2.  **Skalarmultiplikation:** Sei $c \in \mathbb{R}$.
    $$c \cdot a = (c x_1, 0) \in \textcolor{#e64c4c}{U}$$
    (z.B. $a \in \textcolor{#e64c4c}{U} \Rightarrow 5a \in \textcolor{#e64c4c}{U}$)

$\textcolor{#e64c4c}{U}$ ist somit ein Unterraum.

![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p3_CoordinatePoint.excalidraw)

#### Gegenbeispiel: Vereinigung der Achsen
Sei $\textcolor{#994ce6}{W} = \{(x,y) \in \mathbb{R}^2 : x \cdot y = 0\}$.
Dies entspricht der Bedingung: $x=0$ oder $\textcolor{#4ce6e6}{y=0}$ (Achsenkreuz).

![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p3_UnionOfAxes_W.excalidraw)

$\textcolor{#994ce6}{W}$ ist **kein** Unterraum von $\mathbb{R}^2$.
*Grund:* Verletzung der Abgeschlossenheit der Addition.
*   $(1,0) \in \textcolor{#994ce6}{W}$ (da $1 \cdot 0 = 0$)
*   $(0,1) \in \textcolor{#994ce6}{W}$ (da $0 \cdot 1 = 0$)
*   Aber: $(1,0) + (0,1) = (1,1) \notin \textcolor{#994ce6}{W}$ (da $1 \cdot 1 \neq 0$).

> [!WARNING] Diagram image not detected for: VectorSum_W_Counterexample

#### Gegenbeispiel: Affine Gerade ($x=1$)
Die Menge $\textcolor{#e6994c}{B} = \{(x,y) \in \mathbb{R}^2 : x=1\}$ ist **kein** Unterraum von $\mathbb{R}^2$.

![](Vorlesung_1_Vektorraeume_Unterraeume/Vorlesung_1_Vektorraeume_Unterraeume_p3_AffineLine_B_Counterexample.excalidraw)

*Grund:* Verletzung der Skalarmultiplikation.
*   $(1,1) \in \textcolor{#e6994c}{B}$
*   $2 \cdot (1,1) = (2,2) \notin \textcolor{#e6994c}{B}$ (da $x=2 \neq 1$).

### 3.3 Ausblick: Homogene Gleichungssysteme
Ein zentrales Resultat der nächsten Wochen vorweggenommen:

Ist $A$ eine Matrix und $A\vec{x}=\vec{0}$ \textcolor{#e64c4c}{(1)} ein homogenes Gleichungssystem in $\mathbb{R}^n$, dann ist die Menge $\textcolor{#e64c4c}{U}$ aller Lösungen von \textcolor{#e64c4c}{(1)} ein Unterraum von $\mathbb{R}^n$.

**Beweisskizze:**
Seien $\vec{x}_1, \vec{x}_2 \in \textcolor{#e64c4c}{U}$. Das bedeutet $A\vec{x}_1 = \vec{0}$ und $A\vec{x}_2 = \vec{0}$.
Daraus folgt:
$$A(\vec{x}_1 + \vec{x}_2) = A\vec{x}_1 + A\vec{x}_2 = \vec{0} + \vec{0} = \vec{0} \quad \Rightarrow \quad \vec{x}_1 + \vec{x}_2 \in \textcolor{#e64c4c}{U}$$
Ähnlich gilt für Skalare $\alpha \in \mathbb{R}$: $\alpha x_1 \in \textcolor{#e64c4c}{U}$.