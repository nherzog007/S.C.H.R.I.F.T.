# V9-V10 Determinanten und Bedeutung davon, Cramersche Regel

<span style="color:#4d4d4d">09.01.23</span>

## 3. Determinanten: Definition und Grundlagen

> [!NOTE]
> **Wirkungsweise:** Die Determinante ist eine Funktion, die jeder quadratischen Matrix eine spezifische reelle Zahl zuordnet und dabei wesentliche Eigenschaften wie Invertierbarkeit und Volumenverzerrung charakterisiert.

$ \det: \underbrace{\mathbb{R}^n \times \mathbb{R}^n \times ... \times \mathbb{R}^n}_{n-mal} \to \mathbb{R} $
$ \qquad = \mathbb{R}^{n \times n} $

### 3.1 Definierende Eigenschaften (Axiome)

Hat $A \in \mathbb{R}^{n \times n}$ die Spalten $\vec{a}_1, ..., \vec{a}_n$, dann ist $\det A := \det(\vec{a}_1, ..., \vec{a}_n)$. Die Determinante wird durch folgende Eigenschaften definiert:

| Axiom | Bezeichnung | Formel / Beschreibung |
| :--- | :--- | :--- |
| **(1)** | $\textcolor{#e64c4c}{(D1)}$ Normierung | $\det(\vec{e}_1, ..., \vec{e}_n) = 1$, $\det I = 1$ |
| **(2)** | $\textcolor{#e64c4c}{(D2)}$ Multilinearität | $\det(\vec{a}_1, ..., \vec{a}_{j-1}, \textcolor{#4ce6e6}{\alpha}\vec{a}_j + \textcolor{#99e64c}{\beta}\vec{b}_j, \vec{a}_{j+1}, ..., \vec{a}_n) = \textcolor{#4ce6e6}{\alpha} \det(\vec{a}_1, ..., \vec{a}_n) + \textcolor{#4c99e6}{\beta} \det(\vec{a}_1, ..., \vec{b}_j, ..., \vec{a}_n)$ |
| **(3)** | $\textcolor{#e64c4c}{(D3)}$ Alternierend | Werden zwei Vektoren vertauscht $\Rightarrow \det$ wird mit -1 multipliziert. |

**Bemerkung:** Genauso kann man $\det$ definieren, wenn man Zeilen statt Spalten betrachtet.

> [!NOTE]
> **Wirkungsweise:** Diese drei Axiome (Normierung, Linearität in jeder Komponente, Vorzeichenwechsel bei Vertauschung) legen das Verhalten der Determinante vollständig fest und dienen als Basis für alle weiteren Berechnungsmethoden.

#### Beispiel 3.1 d: Anwendung der Axiome

**(1) Vorzeichenwechsel bei Zeilentausch:**
$\det \begin{pmatrix} \textcolor{#4c99e6}{0} & \textcolor{#e64c4c}{1} \\ \textcolor{#4c99e6}{1} & \textcolor{#e64c4c}{0} \end{pmatrix} \stackrel{\textcolor{#e64c4c}{(D3)}}{=} - \det \begin{pmatrix} \textcolor{#e64c4c}{1} & \textcolor{#4c99e6}{0} \\ \textcolor{#e64c4c}{0} & \textcolor{#4c99e6}{1} \end{pmatrix} \stackrel{\textcolor{#e64c4c}{(D1)}}{=} -1$

**(2) Linearität (Aufspalten):**
$\det \begin{pmatrix} 3 & 3+\textcolor{#99e64c}{2} \\ 5 & 5+\textcolor{#99e64c}{4} \end{pmatrix} \stackrel{\textcolor{#e64c4c}{(D2)}}{=} \det \begin{pmatrix} 3 & 3 \\ 5 & 5 \end{pmatrix} + \det \begin{pmatrix} 3 & \textcolor{#99e64c}{2} \\ 5 & \textcolor{#99e64c}{4} \end{pmatrix}$

**(3) Faktor herausziehen:**
$\det \begin{pmatrix} 1 & 2 \\ 2 & 4 \end{pmatrix} = \det \begin{pmatrix} 1 & 2 \cdot \textcolor{#4ce6e6}{1} \\ 2 & 2 \cdot \textcolor{#4ce6e6}{2} \end{pmatrix} = 2 \det \begin{pmatrix} 1 & \textcolor{#4ce6e6}{1} \\ 2 & \textcolor{#4ce6e6}{2} \end{pmatrix} = 0$
*Begründung:* $\det \begin{pmatrix} 1 & \textcolor{#4ce6e6}{1} \\ 2 & \textcolor{#4ce6e6}{2} \end{pmatrix} \stackrel{\textcolor{#e64c4c}{(D3)}}{=} - \det \begin{pmatrix} \textcolor{#4ce6e6}{1} & 1 \\ \textcolor{#4ce6e6}{2} & 2 \end{pmatrix} \Rightarrow 2 \det \begin{pmatrix} 1 & 1 \\ 2 & 2 \end{pmatrix} = 0 \quad \textcolor{#e64c4c}{(*)}$

> [!IMPORTANT]
> **Mentimeterfrage:** Sei $A \in \mathbb{R}^{3 \times 3}$ mit $\det(A)=5$. Dann $\det(2A)=$
> (1) 5 , (2) 10 , (3) 20 , **(4) 40** , (5) keine der obigen.
> *Hinweis:* Der Faktor 2 wird aus jeder der 3 Zeilen gezogen ($2^3 \cdot 5 = 8 \cdot 5 = 40$).

### 3.2 Folgerungen aus den Axiomen

Aus den Definitionen lassen sich folgende Regeln für die Praxis ableiten:

*   <span style="color:#e64c4c">(a)</span> Hat $A$ eine **Nullspalte** (oder Nullzeile) $\Rightarrow \det A = 0$.
*   <span style="color:#e64c4c">(b)</span> Hat $A$ **zwei gleiche Zeilen** (oder Spalten) $\Rightarrow \det A = 0$.
*   <span style="color:#e64c4c">(c)</span> $\det A$ ändert sich **nicht**, wenn wir ein <span style="color:#4ce6e6">Mehrfaches</span> einer Spalte (bzw. Zeile) zu einer anderen Spalte (bzw. Zeile) addieren.
*   <span style="color:#e64c4c">(d)</span> Sind die Spalten (bzw. Zeilen) von $A$ **linear abhängig**, dann $\det A = 0$.

> [!NOTE]
> **Wirkungsweise:** Diese Folgerungen vereinfachen die Berechnung drastisch, da Matrizen mit Redundanzen (lineare Abhängigkeit) oder Nulleinträgen sofort als singulär ($\det = 0$) identifiziert werden können.

#### Beweis durch Beispiele (3.2 a - d)

**Zu (a) Nullspalte:**
$\det \begin{pmatrix} 1 & \textcolor{#4ce6e6}{0} & 3 \\ 2 & \textcolor{#4ce6e6}{0} & 6 \\ 5 & \textcolor{#4ce6e6}{0} & 9 \end{pmatrix} = \det \begin{pmatrix} 1 & \textcolor{#4ce6e6}{0} \cdot 0 & 3 \\ 2 & \textcolor{#4ce6e6}{0} \cdot 0 & 6 \\ 5 & \textcolor{#4ce6e6}{0} \cdot 0 & 9 \end{pmatrix} \stackrel{\textcolor{#e64c4c}{(D2)}}{=} \textcolor{#4ce6e6}{0} \det \begin{pmatrix} 1 & 0 & 3 \\ 2 & 0 & 6 \\ 5 & 0 & 9 \end{pmatrix} = 0$

**Zu (b) Gleiche Zeilen:**
Kann ähnlich wie $\textcolor{#e64c4c}{(*)}$ bewiesen werden (Vorzeichenwechsel bei Tausch identischer Zeilen impliziert Wert 0).

**Zu (c) Addition von Vielfachen:**
$\det \begin{pmatrix} 1 & 3+\textcolor{#99e64c}{4} \cdot 1 \\ 2 & 5+\textcolor{#99e64c}{4} \cdot 2 \end{pmatrix} \stackrel{\textcolor{#e64c4c}{(D2)}}{=} \det \begin{pmatrix} 1 & 3 \\ 2 & 5 \end{pmatrix} + \textcolor{#99e64c}{4} \cdot \underbrace{\det \begin{pmatrix} 1 & 1 \\ 2 & 2 \end{pmatrix}}_{=0} = \det \begin{pmatrix} 1 & 3 \\ 2 & 5 \end{pmatrix}$

**Zu (d) Lineare Abhängigkeit (Illustration):**
Wir bringen die Matrix in ZSF. Wenn die Zeilen von $A$ linear abhängig sind, hat die ZSF mindestens eine Nullzeile, deshalb $\det = 0$.

#### Beispiel 3.2 a: Determinante via Zeilenumformung (Null)

$ A = \begin{pmatrix} 1 & 2 & 1 \\ 2 & 5 & 1 \\ 3 & 5 & 4 \end{pmatrix} \xrightarrow[S_3 \to S_3 - S_1]{S_2 \to S_2 - 2S_1} \begin{pmatrix} 1 & 0 & 0 \\ 2 & 1 & -1 \\ 3 & -1 & 1 \end{pmatrix} \xrightarrow{S_3 \to S_3 + S_2} \begin{pmatrix} 1 & 0 & 0 \\ 2 & 1 & 0 \\ 3 & -1 & 0 \end{pmatrix} $
Also $\det A \stackrel{\textcolor{#e64c4c}{(c)}}{=} \det \begin{pmatrix} 1 & 0 & 0 \\ 2 & 1 & 0 \\ 3 & -1 & 0 \end{pmatrix} \stackrel{\textcolor{#e64c4c}{(a)}}{=} 0$

#### Beispiel 3.2 b: Determinante via ZSF (Ungleich Null)

$ A = \begin{pmatrix} 1 & 6 & 2 \\ 2 & 12 & 6 \\ 1 & 9 & 6 \end{pmatrix} \xrightarrow[z_3 \to z_3 - z_1]{z_2 \to z_2 - 2z_1} \begin{pmatrix} 1 & 6 & 2 \\ 0 & 0 & 2 \\ 0 & 3 & 4 \end{pmatrix} \xrightarrow[\textcolor{#99e64c}{(-1)}]{\textcolor{#99e64c}{z_2 \leftrightarrow z_3}} \begin{pmatrix} 1 & 6 & 2 \\ 0 & 3 & 4 \\ 0 & 0 & 2 \end{pmatrix} $

Wir formen weiter um zur Diagonalmatrix (nicht zwingend notwendig für Dreiecksmatrix-Regel, aber zur Illustration der Identität):
$\dots \xrightarrow{...} \begin{pmatrix} 1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 1 \end{pmatrix}$

**Rückrechnung:**
$\mathbb{1} \stackrel{\textcolor{#e64c4c}{(D1)}}{=} \det I \stackrel{\textcolor{#e64c4c}{(D2)}}{=} \textcolor{#4ce6e6}{\frac{1}{3}} \cdot \textcolor{#4ce6e6}{\frac{1}{2}} \cdot \det \begin{pmatrix} 1 & 0 & 0 \\ 0 & 3 & 0 \\ 0 & 0 & 2 \end{pmatrix} \Rightarrow \det \begin{pmatrix} 1 & 0 & 0 \\ 0 & 3 & 0 \\ 0 & 0 & 2 \end{pmatrix} = \textcolor{#4ce6e6}{3 \cdot 2} = 6$
Aufgrund des Zeilentausches: $\det A \cdot \textcolor{#99e64c}{(-1)} = 6 \implies \det A = -6$

---

## 4. Algorithmen zur Berechnung

### 4.1 Gauß-Algorithmus (Dreiecksmatrizen)

Der effizienteste Weg für Computer basiert auf der Überführung in eine Dreiecksform:
$A \xrightarrow[\text{und mehrmals addieren des Mehrfachen einer Zeile zu einer anderen}]{\substack{\text{Zeilenumformungen} \\ \text{m-Zeilenvertauschungen}}} B \text{ (in ZSF)}$

*   $B$ ist eine <span style="color:#99e64c">obere Dreiecksmatrix</span> (alle Elemente unterhalb der <span style="color:#e6994c">Diagonalen</span> sind 0).
*   In diesem Fall gilt: $\det B = \text{Produkt der diagonalen Elemente}$.

**Formel:**
$$ \det A = (-1)^m \det B \quad \textcolor{#e64c4c}{(* *)} $$

**Definitionen:**
*   <span style="color:#99e64c">Obere Dreiecksmatrix</span>: $\begin{pmatrix} \textcolor{#e6994c}{1} & 6 & 2 \\ 0 & \textcolor{#e6994c}{3} & 4 \\ 0 & 0 & \textcolor{#e6994c}{2} \end{pmatrix}$ ($\det = 1 \cdot 3 \cdot 2 = 6$)
*   <span style="color:#4ce6e6">Untere Dreiecksmatrix</span>: $\begin{pmatrix} \textcolor{#e6994c}{1} & 0 & 0 \\ 3 & \textcolor{#e6994c}{3} & 0 \\ 2 & 0 & \textcolor{#e6994c}{4} \end{pmatrix}$ (Elemente oberhalb der Diagonale sind 0)

> [!NOTE]
> **Wirkungsweise:** Durch elementare Zeilenumformungen wird die Matrix vereinfacht. Da Addition von Zeilen die Determinante nicht ändert und Tauschen nur das Vorzeichen wechselt, lässt sich die Determinante am Ende einfach als Produkt der Diagonalelemente der resultierenden Dreiecksmatrix ablesen.

### 4.2 Folgerung (e): Invertierbarkeit

Es gilt: $\forall A \in \mathbb{R}^{n \times n}: \quad \det A \neq 0 \iff A \text{ invertierbar}$

**Illustration für n=3:**
1.  **Nicht invertierbar:** Zeilen sind linear abhängig $\Rightarrow$ ZSF $B$ hat eine Nullzeile $\Rightarrow \det B = 0 \Rightarrow \det A = 0$.
2.  **Invertierbar:** Zeilen linear unabhängig $\Rightarrow B$ hat keine Nullzeilen.
    $B = \begin{pmatrix} a & d_1 & d_2 \\ 0 & b & d_3 \\ 0 & 0 & c \end{pmatrix}, \quad a,b,c \neq 0 \Rightarrow \det B = a \cdot b \cdot c \neq 0 \Rightarrow \det A \neq 0$

> [!NOTE]
> **Wirkungsweise:** Die Determinante dient als binärer Test für die Invertierbarkeit. Ein Wert ungleich Null garantiert, dass die Matrix vollen Rang besitzt und somit invertierbar ist.

### 4.3 Alternative Methoden (Dimension n=2 und n=3)

Für kleine Dimensionen existieren geschlossene Formeln:

**Für n=2:**
$$ \begin{vmatrix} a & b \\ c & d \end{vmatrix} = ad - bc $$
*"Beweis"*: Erfüllt Axiome (D1)-(D3).
*   $\begin{vmatrix} 1 & 0 \\ 0 & 1 \end{vmatrix} = 1-0 = 1$ (D1 erfüllt)
*   $\begin{vmatrix} b & a \\ d & c \end{vmatrix} = bc - ad = - (ad-bc)$ (D3 erfüllt)

**Für n=3 (Sarrus-Regel / Entwicklung):**
$$ \det \begin{pmatrix} a & \textcolor{#4ce6e6}{b} & \textcolor{#4c99e6}{c} \\ u & \textcolor{#4ce6e6}{v} & \textcolor{#4c99e6}{w} \\ x & \textcolor{#4ce6e6}{y} & \textcolor{#4c99e6}{z} \end{pmatrix} = a \begin{vmatrix} \textcolor{#4ce6e6}{v} & \textcolor{#4c99e6}{w} \\ \textcolor{#4ce6e6}{y} & \textcolor{#4c99e6}{z} \end{vmatrix} - \textcolor{#4ce6e6}{b} \begin{vmatrix} u & \textcolor{#4c99e6}{w} \\ x & \textcolor{#4c99e6}{z} \end{vmatrix} + \textcolor{#4c99e6}{c} \begin{vmatrix} u & \textcolor{#4ce6e6}{v} \\ x & \textcolor{#4ce6e6}{y} \end{vmatrix} $$

> [!NOTE]
> **Wirkungsweise:** Diese expliziten Formeln erlauben eine schnelle Berechnung ohne den Gauß-Algorithmus für kleine Matrizen, indem sie direkt auf die Permutationen der Matrixelemente zugreifen.

### 4.4 Der allgemeine Fall: Determinantenentwicklungssatz (Laplace)

Sei $A \in \mathbb{R}^{n \times n}$. Für jedes $\textcolor{#4ce6e6}{l} \in \{1, ..., n\}$ (Spalte) oder $k$ (Zeile) gilt:

$$ \det A = \underbrace{\sum_{\textcolor{#e6994c}{k}=1}^n (-1)^{\textcolor{#e6994c}{k}+\textcolor{#4ce6e6}{l}} a_{\textcolor{#e6994c}{k}\textcolor{#4ce6e6}{l}} \det(A_{\textcolor{#e6994c}{k}\textcolor{#4ce6e6}{l}})}_{\text{Entwicklung bzgl. Spalte } \textcolor{#4ce6e6}{l}} = \underbrace{\sum_{\textcolor{#e6994c}{l}=1}^n (-1)^{k+\textcolor{#e6994c}{l}} a_{k\textcolor{#e6994c}{l}} \det(A_{k\textcolor{#e6994c}{l}})}_{\text{Entwicklung bzgl. Zeile } k} $$

*   **$A_{kl}$**: Die Untermatrix, die entsteht, wenn man die $k$-te Zeile und $l$-te Spalte aus $A$ streicht.
*   **Vorzeichen**: Schachbrettmuster $(-1)^{k+l}$.

> [!NOTE]
> **Wirkungsweise:** Der Entwicklungssatz reduziert das Problem der Determinantenberechnung rekursiv auf Matrizen der Dimension $(n-1) \times (n-1)$, indem er die Matrix entlang einer Zeile oder Spalte "zerlegt".

#### Beispiel 3.4 (d): Entwicklung nach der 2. Spalte
<span style="float:right">15.01.24</span>

Sei $A = \begin{pmatrix} a & \textcolor{#4ce6e6}{b} & \textcolor{#4c99e6}{c} \\ u & \textcolor{#4ce6e6}{v} & \textcolor{#4c99e6}{w} \\ x & \textcolor{#4ce6e6}{y} & \textcolor{#4c99e6}{z} \end{pmatrix}$. Wir entwickeln nach der 2. Spalte ($\textcolor{#4ce6e6}{l=2}$).

**Bestimmung der Untermatrizen:**
*   $k=1$: Streiche Zeile 1, Spalte 2 $\to A_{12} = \begin{pmatrix} u & w \\ x & z \end{pmatrix}$. Element: $b$. Vorzeichen $(-1)^{1+2} = -1$.
*   $k=2$: Streiche Zeile 2, Spalte 2 $\to A_{22} = \begin{pmatrix} a & c \\ x & z \end{pmatrix}$. Element: $v$. Vorzeichen $(-1)^{2+2} = +1$.
*   $k=3$: Streiche Zeile 3, Spalte 2 $\to A_{32} = \begin{pmatrix} a & c \\ u & w \end{pmatrix}$. Element: $y$. Vorzeichen $(-1)^{3+2} = -1$.

**Rechnung:**
$\det A = - \textcolor{#4ce6e6}{b} \begin{vmatrix} u & w \\ x & z \end{vmatrix} + \textcolor{#4ce6e6}{v} \begin{vmatrix} a & c \\ x & z \end{vmatrix} - \textcolor{#4ce6e6}{y} \begin{vmatrix} a & c \\ u & w \end{vmatrix}$

---

## 5. Geometrische Interpretation

### 5.1 Bedeutung der Determinante

Die Determinante ist ein Maß für den Flächeninhalt (in 2D) oder das Volumen (in 3D), das von den Spaltenvektoren aufgespannt wird.

$|\det(\textcolor{#4ce6e6}{\vec{a}}, \textcolor{#e6994c}{\vec{b}})| = F(\textcolor{#4ce6e6}{\vec{a}}, \textcolor{#e6994c}{\vec{b}})$
$\rightarrow$ Flächeninhalt des von $\textcolor{#4ce6e6}{\vec{a}}, \textcolor{#e6994c}{\vec{b}}$ erzeugten Parallelogramms.

![](V9-V10_Determinanten_und_Bedeutung_davon__Cramersche_Regel/ParallelogrammausVektorenaundb_c8GE.excalidraw)

> [!NOTE]
> **Wirkungsweise:** Der Betrag der Determinante gibt den Verzerrungsfaktor an, um den die Einheitsfläche/-volumen durch die lineare Abbildung der Matrix skaliert wird.

### 5.2 Illustration der Eigenschaften

Die definierenden Eigenschaften der Determinante spiegeln geometrische Prinzipien wider:

1.  <span style="color:#994ce6">(1)</span> **Scherung:** $F(\textcolor{#4ce6e6}{\vec{a}}, \textcolor{#e6994c}{\vec{b}}) = F(\textcolor{#4ce6e6}{\vec{a}} + \lambda \textcolor{#e6994c}{\vec{b}}, \textcolor{#e6994c}{\vec{b}})$.
    *   Konsistent mit $\det(\textcolor{#4ce6e6}{\vec{a}}, \textcolor{#e6994c}{\vec{b}}) = \det(\textcolor{#4ce6e6}{\vec{a}} + \lambda \textcolor{#e6994c}{\vec{b}}, \textcolor{#e6994c}{\vec{b}})$.
    *   *Geometrisch:* Scherung ändert die Grundseite und Höhe nicht $\to$ Fläche bleibt gleich.
    ![](V9-V10_Determinanten_und_Bedeutung_davon__Cramersche_Regel/ParallelogrammemitBasisbundHhe_r9SG.excalidraw)

2.  <span style="color:#994ce6">(2)</span> **Normierung:** $F(\vec{e}_1, \vec{e}_2) = 1$.
    *   Konsistent mit $\det I = 1$.
    *   *Geometrisch:* Das Einheitsquadrat hat Fläche 1.
    ![](V9-V10_Determinanten_und_Bedeutung_davon__Cramersche_Regel/Einheitsquadrat_wNfN.excalidraw)

3.  <span style="color:#994ce6">(3)</span> **Symmetrie:** $F(\vec{a}, \vec{b}) = F(\vec{b}, \vec{a})$.
    *   Konsistent mit $|\det(\vec{a}, \vec{b})| = |-\det(\vec{b}, \vec{a})|$.

4.  <span style="color:#994ce6">(4)</span> **Skalierung:** $F(\lambda \vec{a}, \vec{b}) = |\lambda| \cdot F(\vec{a}, \vec{b})$.
    *   Konsistent mit $\det(\lambda \vec{a}, \vec{b}) = \lambda \det(\vec{a}, \vec{b})$.
    ![](V9-V10_Determinanten_und_Bedeutung_davon__Cramersche_Regel/SkaliertesParallelogramm_9E3f.excalidraw)

**Erweiterung auf 3D:**
Sind $\vec{a}, \vec{b}, \vec{c} \in \mathbb{R}^3$, dann ist $|\det(\vec{a}, \vec{b}, \vec{c})| = \text{Volumen des Spates (Parallelepipeds)}$.

**Bemerkung:**
$\det(\vec{a}, \vec{b}, \vec{c}) = 0 \iff$ Volumen ist 0 $\iff$ Vektoren liegen in einer Ebene $\iff$ linear abhängig.

#### Beispiel: Volumen eines Spates

Für welche $a \in \mathbb{R}$ ist das Volumen $V$ des Spates erzeugt von $\vec{v}_1 = \binom{2}{1}_5, \vec{v}_2 = \binom{3}{0}_4, \vec{v}_3 = \binom{a}{0}_{2-a}$ kleiner als 1?

$$
\begin{aligned}
V = \left| \det \begin{pmatrix} 2 & 3 & a \\ 1 & 0 & 0 \\ 5 & 4 & 2-a \end{pmatrix} \right| &= | \ (-1)^{\textcolor{#e6994c}{1+2}} \cdot 1 \cdot \det \binom{3 \quad a}{4 \quad 2-a} + 0 + 0 \ | \\
&= | - (6 - 3a - 4a) | \\
&= | 7a - 6 | \overset{!}{<} 1 \\
&\iff -1 < 7a - 6 < 1 \\
&\iff 5 < 7a < 7 \\
&\overset{7>0}{\iff} \frac{5}{7} < a < 1
\end{aligned}
$$

---

## 6. Algebraische Anwendungen

### 6.1 Determinantenmultiplikationssatz

Sei $A, B \in \mathbb{R}^{n \times n}$, dann gilt:
$$ \det(AB) = \det(A) \cdot \det(B) $$

**Folgerung für Inverse:**
Ist $A$ invertierbar, dann $\det(A^{-1})\det(A) = \det(A^{-1}A) = \det(I) = 1$.
Daraus folgt:
$$ \det(A^{-1}) = \frac{1}{\det(A)} $$

> [!NOTE]
> **Wirkungsweise:** Dieser Satz besagt, dass die Determinante eines Produkts gleich dem Produkt der Determinanten ist. Dies vereinfacht die Berechnung der Determinante der Inversen erheblich (Kehrwert).

### 6.2 Cramersche Regel

Sei $A \in \mathbb{R}^{n \times n}$ eine invertierbare Matrix und $\textcolor{#4ce6e6}{\vec{b}} \in \mathbb{R}^n$. Dann hat das System $\textcolor{#e6994c}{A}\vec{x} = \textcolor{#4ce6e6}{\vec{b}}$ die eindeutige Lösung $\textcolor{#e6994c}{\vec{x}}$, wobei die Komponenten $x_j$ gegeben sind durch:

$$ x_j = \frac{\det(\vec{a}_1, \dots, \vec{a}_{j-1}, \textcolor{#4ce6e6}{\vec{b}}, \vec{a}_{j+1}, \dots, \vec{a}_n)}{\det(A)} $$
*(In der $j$-ten Spalte wird $\vec{a}_j$ durch $\textcolor{#4ce6e6}{\vec{b}}$ ersetzt)*

> [!NOTE]
> **Wirkungsweise:** Die Cramersche Regel liefert eine explizite Lösungsformel für lineare Gleichungssysteme, indem sie die Lösungskomponenten als Quotienten von Determinanten ausdrückt.

#### Beweis für n=2

Gleichungssystem: $\textcolor{#99e64c}{A}\vec{x} = \textcolor{#4ce6e6}{\vec{b}} \iff \textcolor{#e6994c}{x_1} \vec{a}_1 + \textcolor{#e6994c}{x_2} \vec{a}_2 = \textcolor{#4ce6e6}{\vec{b}} \quad \textcolor{#e64c4c}{(*)}$.

Betrachte die Determinante, in der die 2. Spalte durch $\vec{b}$ ersetzt ist:
$$ \det(\vec{a}_1, \textcolor{#4ce6e6}{\vec{b}}) \overset{\textcolor{#e64c4c}{(*)}}{=} \det(\vec{a}_1, \textcolor{#e6994c}{x_1}\vec{a}_1 + \textcolor{#e6994c}{x_2}\vec{a}_2) $$
$$ \stackrel{\text{Linearität}}{=} \textcolor{#e6994c}{x_1} \underbrace{\det(\vec{a}_1, \vec{a}_1)}_{=0} + \textcolor{#e6994c}{x_2} \underbrace{\det(\vec{a}_1, \vec{a}_2)}_{=\det A} $$
$$ \Rightarrow \det(\vec{a}_1, \vec{b}) = x_2 \cdot \det A \implies x_2 = \frac{\det(\vec{a}_1, \vec{b})}{\det A} $$

### 6.3 Formel für die inverse Matrix

Mithilfe der Cramerschen Regel kann eine Formel für die Einträge der inversen Matrix $A^{-1}$ hergeleitet werden.
Sei $A$ invertierbar. Für den Eintrag $(A^{-1})_{\textcolor{#e6994c}{j}\textcolor{#4ce6e6}{k}}$ (Zeile $j$, Spalte $k$ der Inversen? Vorsicht: Indizes beachten) gilt:

$$ (A^{-1})_{\textcolor{#e6994c}{j}\textcolor{#4ce6e6}{k}} = \frac{1}{\det(A)} \cdot \det(\vec{a}_1, \dots, \underbrace{\textcolor{#4ce6e6}{\vec{e}_k}}_{\text{an } j\text{-ter Stelle}}, \dots, \vec{a}_n) $$

> [!WARNING]
> **Index-Achtung:** In der Standardformel der Adjunkten sind Zeilen und Spalten oft vertauscht (Transposition der Kofaktorenmatrix). Hier wird die $j$-te Spalte durch $\vec{e}_k$ ersetzt, um den Eintrag $j,k$ zu finden.

> [!NOTE]
> **Wirkungsweise:** Da die Spalten der inversen Matrix die Lösungen von $A\vec{x} = \vec{e}_k$ sind, lässt sich jeder Eintrag direkt über Determinanten berechnen, ohne den Gauß-Algorithmus durchzuführen.

#### Beispiel: Inverse einer 2x2 Matrix

Sei $A = \begin{pmatrix} 1 & 2 \\ 1 & 4 \end{pmatrix}$. $\det(A) = 2$.
Wir suchen $A^{-1} = C = \begin{pmatrix} c_{11} & c_{12} \\ c_{21} & c_{22} \end{pmatrix}$.

*   **$c_{11}$:** Ersetze 1. Spalte in $A$ durch $\vec{e}_1 = \binom{1}{0}$.
    $c_{11} = \frac{1}{2} \det \begin{pmatrix} \textcolor{#4ce6e6}{1} & 2 \\ \textcolor{#4ce6e6}{0} & 4 \end{pmatrix} = \frac{4}{2} = 2$.
*   **$c_{12}$:** Ersetze 1. Spalte in $A$ durch $\vec{e}_2 = \binom{0}{1}$.
    $c_{12} = \frac{1}{2} \det \begin{pmatrix} \textcolor{#4ce6e6}{0} & 2 \\ \textcolor{#4ce6e6}{1} & 4 \end{pmatrix} = \frac{-2}{2} = -1$.
*   **$c_{21}$:** Ersetze 2. Spalte in $A$ durch $\vec{e}_1$.
    $c_{21} = \frac{1}{2} \det \begin{pmatrix} 1 & \textcolor{#4ce6e6}{1} \\ 1 & \textcolor{#4ce6e6}{0} \end{pmatrix} = \frac{-1}{2}$.
*   **$c_{22}$:** Ersetze 2. Spalte in $A$ durch $\vec{e}_2$.
    $c_{22} = \frac{1}{2} \det \begin{pmatrix} 1 & \textcolor{#4ce6e6}{0} \\ 1 & \textcolor{#4ce6e6}{1} \end{pmatrix} = \frac{1}{2}$.

Ergebnis: $A^{-1} = \begin{pmatrix} 2 & -1 \\ -0.5 & 0.5 \end{pmatrix}$.

**Allgemeine 2x2 Formel:**
$A = \begin{pmatrix} a & b \\ c & d \end{pmatrix} \Rightarrow A^{-1} = \frac{1}{ad-bc} \begin{pmatrix} d & -b \\ -c & a \end{pmatrix}$

---

## 7. Verständnisfragen

> [!IMPORTANT]
> **Mentimeter Frage:**
> Sei $A \in \mathbb{R}^{40 \times 40}$. Die Determinante von $A$ kann berechnet werden mit:
> (a) Determinantenentwicklungssatz (Laplace).
> (b) Zeilenstufenform (Gauß).
>
> **Welche Aussage zur Geschwindigkeit ist richtig?**
>
> 1.  Der Algorithmus (a) ist viel schneller.
> 2.  Der Algorithmus (a) ist ein bisschen schneller.
> 3.  Die Algorithmen sind vergleichbar schnell.
> 4.  Der Algorithmus (b) ist ein bisschen schneller.
> 5.  **Der Algorithmus (b) ist viel schneller.**
>
> *Begründung:* Laplace hat faktorielle Komplexität ($O(n!)$), Gauß kubische Komplexität ($O(n^3)$). Bei $n=40$ ist Laplace unmöglich zu berechnen.