# V7-V8 Matrixprodukt, invertierbare/inverse Matrizen, lineare Abbildungen

## 1.12 Produkt von Matrizen
<div style="text-align: right;">14.12.23</div>

Seien $n, \textcolor{#4ce6e6}{m}, \textcolor{#4ce6e6}{q} \in \mathbb{N}, \ A \in \mathbb{R}^{n \times n}, \ B \in \mathbb{R}^{m \times q}$.
Ist $A=(a_{jk})_{j=1, k=1}^{n, \textcolor{#99e64c}{m}}, \ B=(b_{kl})_{k=1, l=1}^{m, q}$, dann ist das Produkt $AB = C \in \mathbb{R}^{n \times q}$ definiert als Matrix $C=(c_{jl})_{j=1, l=1}^{n, q}$, wobei:

$$
c_{jl} = \sum_{k=1}^{\textcolor{#99e64c}{m}} a_{jk} b_{kl}
$$

**Struktur der Multiplikation:**
$$
\textcolor{#e64c4c}{j}\text{-te Zeile von } A \quad (a_{\textcolor{#e64c4c}{j}\textcolor{#99e64c}{1}} \ a_{\textcolor{#e64c4c}{j}\textcolor{#99e64c}{2}} \ \dots \ a_{\textcolor{#e64c4c}{j}\textcolor{#99e64c}{m}}) \begin{pmatrix} b_{\textcolor{#99e64c}{1}\textcolor{#4ce6e6}{l}} \\ b_{\textcolor{#99e64c}{2}\textcolor{#4ce6e6}{l}} \\ \vdots \\ b_{\textcolor{#99e64c}{m}\textcolor{#4ce6e6}{l}} \end{pmatrix}
$$
<div style="text-align: center; width: 50%; margin-left: 25%;">$\textcolor{#4ce6e6}{l}\text{-te Spalte von } B$</div>

**Alternative Betrachtung über Spaltenvektoren:**
$$
A(\vec{b}_1 | \dots | \vec{b}_q) = (\underbrace{A\vec{b}_1}_{\substack{\text{Spalten} \\ \text{von } B}} | \dots | \underbrace{A\vec{b}_q}_{\substack{\text{Spalten von} \\ AB}})
$$

> [!NOTE]
> Das Matrixprodukt berechnet die Einträge der Ergebnismatrix durch das Skalarprodukt der Zeilenvektoren der ersten Matrix mit den Spaltenvektoren der zweiten Matrix. Es ist nur definiert, wenn die Spaltenanzahl der ersten Matrix mit der Zeilenanzahl der zweiten übereinstimmt.

### Beispiel 1.12.1: Berechnung eines Matrixprodukts

$$
\underbrace{\begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix}}_{A} \underbrace{\begin{pmatrix} 1 & 1 \\ 0 & 0.5 \end{pmatrix}}_{\textcolor{#e6994c}{\vec{b}_1}, \textcolor{#e6994c}{\vec{b}_2}} = \begin{pmatrix} c_{11} & c_{12} \\ c_{21} & c_{22} \end{pmatrix}
$$

**Berechnung der Komponenten:**
$$
\begin{pmatrix} 1 \cdot 1 + (-2) \cdot 0 & 1 \cdot 1 + (-2) \cdot 0,5 \\ 0 \cdot 1 + 2 \cdot 0 & 0 \cdot 1 + 2 \cdot 0,5 \end{pmatrix} = \underbrace{\begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}}_{A\textcolor{#e6994c}{\vec{b}_1} \quad A\textcolor{#e6994c}{\vec{b}_2}}
$$

**Alternative über Vektorzerlegung:**
*   Für $\vec{b}_1$:
    $A\textcolor{#e6994c}{\vec{b}_1} = \begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix} \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 0 \end{pmatrix}} = \textcolor{#e6994c}{1}\begin{pmatrix} 1 \\ 0 \end{pmatrix} + \textcolor{#e6994c}{0}\begin{pmatrix} -2 \\ 2 \end{pmatrix} = \begin{pmatrix} 1 \\ 0 \end{pmatrix}$
*   Für $\vec{b}_2$:
    $A\textcolor{#e6994c}{\vec{b}_2} = \begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix} \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 0.5 \end{pmatrix}} = \textcolor{#e6994c}{1}\begin{pmatrix} 1 \\ 0 \end{pmatrix} + \textcolor{#e6994c}{0.5}\begin{pmatrix} -2 \\ 2 \end{pmatrix} = \begin{pmatrix} 0 \\ 1 \end{pmatrix}$

Also gilt: $A(\textcolor{#e6994c}{\vec{b}_1} | \textcolor{#e6994c}{\vec{b}_2}) = (A\textcolor{#e6994c}{\vec{b}_1} | A\textcolor{#e6994c}{\vec{b}_2}) = \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}$.

### Eigenschaften der Matrixmultiplikation
Für alle $\alpha, \beta, \gamma \in K$ und alle Matrizen $A, B, C$, sodass die Produkte definiert sind, gilt:

| Nr. | Gesetz | Formel |
| :--- | :--- | :--- |
| **(1)** | Distributivgesetz (links) | $(\alpha A + \beta B) C = \alpha AC + \beta BC$ |
| **(2)** | Distributivgesetz (rechts) | $A (\beta B + \gamma C) = \beta AB + \gamma AC$ |
| **(3)** | Assoziativgesetz | $(AB)C = A(BC)$ |

> [!NOTE]
> Die Matrixmultiplikation ist assoziativ und distributiv, jedoch im Allgemeinen **nicht** kommutativ ($AB \neq BA$).

### Beispiel 1.12.2: Nicht-Kommutativität
Gegeben seien:
$A = \begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix}, \ B = \begin{pmatrix} 1 & 0 \\ 1 & 0 \end{pmatrix}, \ C = \begin{pmatrix} 2 \\ 3 \end{pmatrix}$

**Vergleich von AB und BA:**
$$
\left. \begin{aligned} AB = \overset{\to}{(1 \ 1)} \overset{\downarrow}{\begin{pmatrix} 1 & 0 \\ 1 & 0 \end{pmatrix}} = \begin{pmatrix} 1 \cdot 1 + 1 \cdot 1 & 1 \cdot 0 + 1 \cdot 0 \\ 0 \cdot 1 + 0 \cdot 0 & 0 \cdot 0 + 0 \cdot 0 \end{pmatrix} = \begin{pmatrix} 2 & 0 \\ 0 & 0 \end{pmatrix} \\ BA = \overset{\to}{(1 \ 0)} \overset{\downarrow}{\begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix}} = \begin{pmatrix} 1 \cdot 1 + 0 \cdot 0 & 1 \cdot 1 + 0 \cdot 0 \\ 1 \cdot 1 + 0 \cdot 0 & 1 \cdot 1 + 0 \cdot 0 \end{pmatrix} = \begin{pmatrix} 1 & 1 \\ 1 & 1 \end{pmatrix} \end{aligned} \right\} AB \neq BA
$$

**Dimensionsprobleme bei AC vs CA:**
*   $AC = \begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix} \begin{pmatrix} 2 \\ 3 \end{pmatrix} = 2 \cdot \begin{pmatrix} 1 \\ 0 \end{pmatrix} + 3 \cdot \begin{pmatrix} 1 \\ 0 \end{pmatrix} = \begin{pmatrix} 5 \\ 0 \end{pmatrix}$
*   $CA = \begin{pmatrix} 2 \\ 3 \end{pmatrix} \begin{pmatrix} 1 & 1 \\ 0 & 0 \end{pmatrix}$ ist **nicht definiert**, da $C \in \mathbb{R}^{2 \times \textcolor{#994ce6}{1}}$ aber $A \in \mathbb{R}^{\textcolor{#994ce6}{2} \times 2}$ und $1 \neq 2$.

**Fazit:**
(i) $AB = BA$ gilt nicht immer.
(ii) Möglicherweise ist $AC$ definiert, aber $CA$ nicht.

---

## 1.13 Invertierbare Matrizen (Inverse)

### Die Einheitsmatrix $I_n$
Sei das Kronecker-Delta definiert als $\delta_{jk} = \begin{cases} 1, & j=k \\ 0, & j \neq k \end{cases}$.
Dann heißt $I_n = (\delta_{jk})_{j=1, k=1}^{n, n}$ die **Einheitsmatrix**.

**Beispiele:**
*   $I_2 = \begin{pmatrix} \textcolor{#4ce6e6}{1} & \textcolor{#4ce6e6}{2} \\ \textcolor{#e64c4c}{1} & 0 \\ \textcolor{#e64c4c}{0} & 1 \end{pmatrix} \begin{matrix} \delta_{11} = 1 & \text{da } \textcolor{#4ce6e6}{1=1} \\ \delta_{12} = 0 & \text{da } \textcolor{#4ce6e6}{1 \neq 2} \\ \delta_{21} = 0 & \\ \delta_{22} = 1 & \end{matrix}$ (Indizes visualisiert)
*   $I_3 = \begin{pmatrix} 1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 1 \end{pmatrix}$

**Eigenschaften:**
1.  $I_n A = A I_n = A \quad \forall A \in K^{n \times n}$
2.  $I_n \vec{x} = \vec{x} \quad \forall \vec{x} \in K^n \ \textcolor{#e64c4c}{(1)}$

#### Beweise für $n=2$
**Zu Eigenschaft (1):**
$$
I_2 \binom{x_1}{x_2} = \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \binom{x_1}{x_2} = x_1 \cdot \binom{1}{0} + x_2 \cdot \binom{0}{1} = \binom{x_1}{x_2}
$$

**Zu $I_2 A = A$:**
$$
\begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \begin{pmatrix} a & c \\ b & d \end{pmatrix} = \left( \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \binom{a}{b} \;\middle|\; \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix} \binom{c}{d} \right) \stackrel{\textcolor{#e64c4c}{(1)}}{=} \begin{pmatrix} a & c \\ b & d \end{pmatrix}
$$

> [!NOTE]
> Die Einheitsmatrix ist das neutrale Element der Matrixmultiplikation; sie verändert weder Vektoren noch Matrizen, wenn sie mit ihnen multipliziert wird.

> [!IMPORTANT]
> **Mentifrage:** Sei $B \in \mathbb{R}^{2 \times 2}$. Wenn es Vektoren $\vec{v}_1, \vec{v}_2 \in \mathbb{R}^2$ gibt mit $B\vec{v}_1 = \binom{1}{0}$, $B\vec{v}_2 = \binom{0}{1}$. Dann gilt:
> (1) Bild $B = \mathbb{R}^2$
> (2) Bild $B \neq \mathbb{R}^2$
> (3) Es ist unklar, ob (1) oder (2) gilt
> (4) keine Ahnung.

### Definition und Motivation der Inversen
**Motivation:**
Sei $A\vec{x}=\vec{b}$. Falls es eine Matrix $B$ gibt mit $BA=I_n$, dann gilt:
$A\vec{x}=\vec{b} \Rightarrow B(A\vec{x})=B\vec{b} \Rightarrow (BA)\vec{x} = B\vec{b} \Rightarrow I_n \vec{x} = B\vec{b} \Rightarrow \vec{x} = B\vec{b}$.

**Definition:**
Eine Matrix $A \in K^{n \times n}$ heißt **invertierbar**, wenn ein $B \in \mathbb{R}^{n \times n}$ existiert mit $AB=BA=I_n$.
Dann schreibt man oft $B=A^{-1}$ (Inverse von A).

#### Bemerkung 1.6:
$$
\left. \begin{aligned}
A \in \mathbb{R}^{n \times n} \text{ ist invertierbar} & \Leftrightarrow \exists B \in \mathbb{R}^{n \times n} \text{ mit } AB=I_n \\
& \Leftrightarrow \exists C \in \mathbb{R}^{n \times n} \text{ mit } CA=I_n
\end{aligned} \right\} \textcolor{#e6994c}{\text{Es reicht, eine der zwei}\atop\text{Gleichheiten zu überprüfen.}}
$$
In diesem Fall ist $B=A^{-1}$ (bzw. $C=A^{-1}$).

#### Beispiel 1.13.1 (Verknüpfung):
Da $\begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix} \begin{pmatrix} 1 & 1 \\ 0 & 0,5 \end{pmatrix} \xrightarrow[1.12.1]{Bsp.} \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}$, folgt aus Bem. 1.6:
$\begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix}$ ist invertierbar und $\begin{pmatrix} 1 & -2 \\ 0 & 2 \end{pmatrix}^{-1} = \begin{pmatrix} 1 & 1 \\ 0 & 0,5 \end{pmatrix}$.

> [!NOTE]
> Die inverse Matrix kehrt die Wirkung der ursprünglichen Matrix um. Ist $A$ invertierbar, so ist das Gleichungssystem $Ax=b$ stets eindeutig lösbar durch $x=A^{-1}b$.

### Berechnung von $A^{-1}$ (Gauß-Jordan-Algorithmus)
Ist $A \in \mathbb{R}^{n \times n}$ invertierbar, so führt der Ansatz $(A \mid I_n) \xrightarrow{ZUF} (I_n \mid A^{-1})$ zur Inversen.

#### Beispiel 1.13.2: Inversion einer 2x2 Matrix
Sei $A = \begin{pmatrix} 1 & 2 \\ 2 & 6 \end{pmatrix} \in \mathbb{R}^{2 \times 2}$.

$$
\left( \begin{array}{cc:cc} 1 & 2 & \textcolor{#99e64c}{1} & \textcolor{#e6994c}{0} \\ 2 & 6 & \textcolor{#99e64c}{0} & \textcolor{#e6994c}{1} \end{array} \right) \xrightarrow{\textcolor{#4d4d4d}{Z_2 \to Z_2 \textcolor{#4ce6e6}{-2}Z_1}} \left( \begin{array}{cc:cc} 1 & 2 & \textcolor{#99e64c}{1} & \textcolor{#e6994c}{0} \\ 0 & 2 & \textcolor{#99e64c}{-2} & \textcolor{#e6994c}{1} \end{array} \right) \xrightarrow{Z_1 \to Z_1 - Z_2} \left( \begin{array}{cc:cc} 1 & 0 & \textcolor{#99e64c}{3} & \textcolor{#e6994c}{-1} \\ 0 & 2 & \textcolor{#99e64c}{-2} & \textcolor{#e6994c}{1} \end{array} \right) \xrightarrow{Z_2 \to 0,5 Z_2} \left( \begin{array}{cc:cc} 1 & 0 & \textcolor{#99e64c}{3} & \textcolor{#e6994c}{-1} \\ 0 & 1 & \textcolor{#99e64c}{-1} & \textcolor{#e6994c}{0,5} \end{array} \right)
$$
Also ist $A^{-1} = \begin{pmatrix} \textcolor{#99e64c}{3} & \textcolor{#e6994c}{-1} \\ \textcolor{#99e64c}{-1} & \textcolor{#e6994c}{0,5} \end{pmatrix}$.

#### Wieso funktioniert dieser Algorithmus?
Der Algorithmus löst gleichzeitig zwei Gleichungssysteme: $A\vec{x} = \binom{\textcolor{#99e64c}{1}}{\textcolor{#99e64c}{0}}$ und $A\vec{x}=\binom{\textcolor{#e6994c}{0}}{\textcolor{#e6994c}{1}}$.

**Vergleich der Spaltenlösung:**
1.  **Linke Seite (grün):**
    $$
    \begin{cases} 1x_1 + 2x_2 = \textcolor{#e64c4c}{1} \\ 2x_1 + 6x_2 = \textcolor{#99e64c}{0} \end{cases} \xrightarrow{\dots} \begin{cases} x_1 = \textcolor{#99e64c}{3} \\ x_2 = \textcolor{#99e64c}{-1} \end{cases}
    $$
2.  **Rechte Seite (orange):**
    $$
    \begin{cases} 1x_1 + 2x_2 = \textcolor{#e6994c}{0} \\ 2x_1 + 6x_2 = \textcolor{#e6994c}{1} \end{cases} \xrightarrow{\dots} \begin{cases} x_1 = \textcolor{#e6994c}{-1} \\ x_2 = \textcolor{#e6994c}{0,5} \end{cases}
    $$

Zusammengesetzt:
$$
\begin{pmatrix} 1 & 2 \\ 2 & 6 \end{pmatrix} \begin{pmatrix} \textcolor{#99e64c}{3} & \textcolor{#e6994c}{-1} \\ \textcolor{#99e64c}{-1} & \textcolor{#e6994c}{0,5} \end{pmatrix} = \left( \begin{pmatrix} 1 & 2 \\ 2 & 6 \end{pmatrix} \binom{\textcolor{#99e64c}{3}}{\textcolor{#99e64c}{-1}} \;\middle|\; \begin{pmatrix} 1 & 2 \\ 2 & 6 \end{pmatrix} \binom{\textcolor{#e6994c}{-1}}{\textcolor{#e6994c}{0,5}} \right) = \begin{pmatrix} \textcolor{#99e64c}{1} & \textcolor{#e6994c}{0} \\ \textcolor{#99e64c}{0} & \textcolor{#e6994c}{1} \end{pmatrix}
$$

#### Beispiel 1.13.3: Nicht-invertierbarer Fall
Sei $B = \begin{pmatrix} 1 & 2 \\ 2 & 4 \end{pmatrix}$.
$$
(B \mid I_2) = \left( \begin{array}{cc|cc} 1 & 2 & 1 & 0 \\ 2 & 4 & 0 & 1 \end{array} \right) \xrightarrow{Z_2 \to Z_2 - 2Z_1} \left( \begin{array}{cc|cc} 1 & 2 & 1 & 0 \\ 0 & 0 & -2 & 1 \end{array} \right)
$$
Damit sieht man, dass $B\vec{x} = \binom{1}{0}$ keine Lösung hat (denn $0x_1 + 0x_2 = -2$ ist unmöglich). Also ist B **nicht invertierbar**.

> [!NOTE]
> Der Gauß-Jordan-Algorithmus transformiert die Matrix $A$ zur Einheitsmatrix und führt dieselben Operationen auf einer angehängten Einheitsmatrix durch, wodurch diese zu $A^{-1}$ wird. Entsteht dabei eine Nullzeile im linken Teil, ist die Matrix nicht invertierbar.

#### Beispiel 1.13.4: 3x3 Inversion (Zusatzbeispiel)
Gesucht: $\begin{pmatrix} 1 & 1 & 1 \\ 1 & 2 & 1 \\ 2 & 2 & 4 \end{pmatrix}^{-1}$

1.  **Ausgangsmatrix:**
    $$
    \left( \begin{array}{ccc|ccc} 1 & 1 & 1 & 1 & 0 & 0 \\ 1 & 2 & 1 & 0 & 1 & 0 \\ 2 & 2 & 4 & 0 & 0 & 1 \end{array} \right) \xrightarrow[Z_3 \to Z_3 - 2Z_1]{Z_2 \to Z_2 - Z_1} \left( \begin{array}{ccc|ccc} 1 & 1 & 1 & 1 & 0 & 0 \\ 0 & 1 & 0 & -1 & 1 & 0 \\ 0 & 0 & 2 & -2 & 0 & 1 \end{array} \right)
    $$

2.  **Elimination und Normierung:**
    $$
    \xrightarrow[Z_1 \to Z_1 - Z_2]{Z_3 \to \frac{1}{2}Z_3} \left( \begin{array}{ccc|ccc} 1 & 0 & 1 & 2 & -1 & 0 \\ 0 & 1 & 0 & -1 & 1 & 0 \\ 0 & 0 & 1 & -1 & 0 & \frac{1}{2} \end{array} \right)
    $$

3.  **Abschluss:**
    $$
    \xrightarrow{Z_1 \to Z_1 - Z_3} \left( \begin{array}{ccc|ccc} 1 & 0 & 0 & 3 & -1 & -\frac{1}{2} \\ 0 & 1 & 0 & -1 & 1 & 0 \\ 0 & 0 & 1 & -1 & 0 & \frac{1}{2} \end{array} \right)
    $$

Also gilt: $\begin{pmatrix} 1 & 1 & 1 \\ 1 & 2 & 1 \\ 2 & 2 & 4 \end{pmatrix}^{-1} = \begin{pmatrix} 3 & -1 & -\frac{1}{2} \\ -1 & 1 & 0 \\ -1 & 0 & \frac{1}{2} \end{pmatrix}$

### Satz 1.4: Äquivalenzen zur Invertierbarkeit
Sei $A \in \mathbb{R}^{n \times n}$. Dann sind folgende Aussagen äquivalent:

1.  $A$ ist invertierbar.
2.  Bild $A = \mathbb{R}^n$ ($A\vec{x}=\vec{b}$ ist für alle $\vec{b}$ lösbar).
3.  Kern $A = \{0\}$.

**Beweisskizzen:**
*   **A invertierbar $\Rightarrow$ Kern $A = \{0\}$:**
    Ist $A\vec{x} = \vec{0} \Rightarrow A^{-1}(A\vec{x}) = \vec{0} \Rightarrow (A^{-1}A)\vec{x} = \vec{0} \Rightarrow I_n \vec{x} = \vec{0} \Rightarrow \vec{x} = \vec{0}$.
*   **Bild $A = \mathbb{R}^n \Rightarrow A$ invertierbar (für $n=2$):**
    Da $\binom{1}{0} \in$ Bild $A$, existiert $\vec{x}_1$ mit $A\vec{x}_1 = \binom{1}{0}$. Ähnlich existiert $\vec{x}_2$ mit $A\vec{x}_2 = \binom{0}{1}$.
    Daraus folgt $A(\vec{x}_1 \mid \vec{x}_2) = I_2$.
*   **A invertierbar $\Rightarrow$ Bild $A = \mathbb{R}^n$:**
    Zu zeigen: $A\vec{x}=\vec{b}$ hat Lösung $\forall \vec{b} \in \mathbb{R}^n$.
    Setze $\vec{x} = A^{-1}\vec{b}$. Dann gilt $A(A^{-1}\vec{b}) = (AA^{-1})\vec{b} = I_n \vec{b} = \vec{b}$.

#### Zusammenfassung und Erweiterung (21.12.23)
Folgende Aussagen sind äquivalent für $A \in \mathbb{R}^{n \times n}$:

| Bedingung | Bedeutung |
| :--- | :--- |
| **Invertierbarkeit** | $A$ ist invertierbar |
| **Kern** | Kern $A = \{\vec{0}\}$ (injektiv) |
| **Bild** | Bild $A = \mathbb{R}^n$ (surjektiv) |
| **Spalten** | Spalten von $A$ sind linear unabhängig |
| **Zeilen** | Zeilen von $A$ sind linear unabhängig |

*   **Illustration (Zeilen linear abhängig):**
    Siehe Beispiel 1.13.3. Wenn eine Nullzeile entsteht, sind die Zeilen linear abhängig und die Matrix nicht invertierbar.
*   **Illustration (Spalten linear unabhängig):**
    $A$ invertierbar $\Rightarrow$ Kern $A = \{0\}$.
    Wenn $A\vec{x}=\vec{0} \Rightarrow \vec{x}=0$.
    Sei $A=(\vec{v}_1 | ... | \vec{v}_n)$, dann ist $x_1 \vec{v}_1 + ... + x_n \vec{v}_n = 0 \Rightarrow x_1 = ... = x_n = 0$. Dies ist genau die Definition der linearen Unabhängigkeit der Spaltenvektoren $\vec{v}_i$.

> [!NOTE]
> Ein quadratisches lineares Gleichungssystem ist genau dann eindeutig lösbar, wenn die Koeffizientenmatrix invertierbar ist, was äquivalent dazu ist, dass ihre Zeilen (oder Spalten) linear unabhängig sind.

---

## Lineare Abbildungen

### Motivation und Linearisierung
Lineare Abbildungen $f: \mathbb{R} \to \mathbb{R}$ der Form $f(x)=cx$ sind fundamental, weil:
(i) Sie einfach zu handhaben sind.
(ii) Sie komplizierte Abbildungen approximieren können (z.B. Kleinwinkelnäherung beim Fadenpendel).


![](V7-V8_Matrixprodukt__invertierbare_inverse_Matrizen__lineare_Abbildungen/V7-V8_Matrixprodukt__invertierbare_inverse_Matrizen__lineare_Abbildungen_p4_DIAGRAM_Pendulum.excalidraw)


**Beispiel Fadenpendel:**
Die Rückstellkraft ist $F_1(\theta) = F \sin \textcolor{#e64c4c}{\theta}$.
Wenn $\textcolor{#e64c4c}{\theta}$ klein ist, gilt $\sin \textcolor{#e64c4c}{\theta} \approx \textcolor{#e64c4c}{\theta}$.
Taylor-Entwicklung (Januar):
$$
\sin \textcolor{#e64c4c}{\theta} = (\textcolor{#e64c4c}{\theta} - \frac{\textcolor{#e64c4c}{\theta}^3}{3!} + \frac{\textcolor{#e64c4c}{\theta}^5}{5!} - ...) \approx \underset{\substack{\text{lineare} \\ \text{Approximation}}}{\textcolor{#e64c4c}{\theta}}
$$

**Beispiel Lineare Elektrische Netze (LEN):**
Elektrische Netze sind in der Natur nicht immer linear, aber LEN approximieren diese ($V \approx I R$).

### 1.11 Definition linearer Abbildungen
Seien $V, W$ $\mathbb{R}$- (oder $\mathbb{C}$-) Vektorräume.
$\Phi: V \to W$ heißt **linear**, wenn für alle $\vec{x}, \vec{y} \in V$ und alle Skalare $\alpha$:

1.  $\Phi(\vec{x}+\vec{y}) = \Phi(\vec{x}) + \Phi(\vec{y})$ (Additivität)
2.  $\Phi(\alpha \vec{x}) = \alpha \Phi(\vec{x})$ (Homogenität)


![](V7-V8_Matrixprodukt__invertierbare_inverse_Matrizen__lineare_Abbildungen/V7-V8_Matrixprodukt__invertierbare_inverse_Matrizen__lineare_Abbildungen_p4_DIAGRAM_MappingViz.excalidraw)


**Wichtige Begriffe:**
*   $\textcolor{#e64c4c}{\text{Kern } \Phi = \{ \vec{x} \in V : \Phi(\vec{x}) = \vec{0} \}}$ (Alle Vektoren, die auf $\textcolor{#4ce6e6}{\vec{0}}$ abgebildet werden).
*   Bild $\Phi = \{ \Phi(\vec{x}) : \vec{x} \in V \}$.

> [!NOTE]
> Eine lineare Abbildung ist eine strukturerhaltende Transformation zwischen Vektorräumen, die mit Vektoraddition und Skalarmultiplikation verträglich ist. Der Kern misst dabei, wie viele Informationen durch die Abbildung "verloren gehen" (auf Null gesetzt werden).

#### Beispiel 1.11.1: Eindimensionale Abbildungen
(i) $\phi: \mathbb{R} \to \mathbb{R}$ mit $\phi(x)=5x$ ist linear.
    *   $\phi(x_1 + x_2) = 5(x_1 + x_2) = 5x_1 + 5x_2 = \phi(x_1) + \phi(x_2)$
    *   $\phi(\alpha x_1) = 5\alpha x_1 = \alpha \phi(x_1)$
    *   Kern $\phi = \{0\}$, Bild $\phi = \mathbb{R}$.

(ii) $\Psi(x) = 3x+4$ ist **nicht linear**.
    *   Gegenbeispiel: $\Psi(0)=4$.
    *   $\Psi(5 \cdot 0) = \Psi(0) = 4$, aber $5 \cdot \Psi(0) = 5 \cdot 4 = 20$.
    *   Also $\Psi(5 \cdot 0) \neq 5 \cdot \Psi(0)$.

#### Beispiel 1.11.2: Lineare Abbildung im $\mathbb{R}^3$
Sei $\phi : \mathbb{R}^3 \to \mathbb{R}^3$ definiert durch:
$$
\phi \left( \begin{pmatrix} x_1 \\ x_2 \\ x_3 \end{pmatrix} \right) = \begin{pmatrix} \textcolor{#994ce6}{1} x_1 + \textcolor{#994ce6}{1} x_2 + \textcolor{#994ce6}{1} x_3 \\ \textcolor{#994ce6}{1} x_1 + \textcolor{#994ce6}{2} x_2 + \textcolor{#994ce6}{1} x_3 \\ \textcolor{#994ce6}{2} x_1 + \textcolor{#994ce6}{2} x_2 + \textcolor{#994ce6}{4} x_3 \end{pmatrix}
$$

Diese Abbildung lässt sich als Matrix-Vektor-Produkt schreiben: $\phi(\vec{x}) = \textcolor{#994ce6}{A}\vec{x}$ mit
$$
\textcolor{#994ce6}{A} = \begin{pmatrix} \textcolor{#994ce6}{1} & \textcolor{#994ce6}{1} & \textcolor{#994ce6}{1} \\ \textcolor{#994ce6}{1} & \textcolor{#994ce6}{2} & \textcolor{#994ce6}{1} \\ \textcolor{#994ce6}{2} & \textcolor{#994ce6}{2} & \textcolor{#994ce6}{4} \end{pmatrix}
$$

**Analyse:**
*   $\phi$ ist linear, da Matrixmultiplikation linear ist ($\textcolor{#994ce6}{A}(\vec{x}+\vec{y}) = \textcolor{#994ce6}{A}\vec{x} + \textcolor{#994ce6}{A}\vec{y}$, etc.).
*   Kern $\phi = \text{Kern } \textcolor{#994ce6}{A} = \{\vec{0}\}$, da $\textcolor{#994ce6}{A}$ invertierbar ist (siehe Bsp. 1.13.4).
*   Bild $\phi = \text{Bild } \textcolor{#994ce6}{A} = \mathbb{R}^3$.
*   **Bijektivität:** $\phi$ ist surjektiv (Bild ist ganz $\mathbb{R}^3$) und injektiv.

**Beweis der Injektivität via Kern:**
Allgemein gilt für eine lineare Abbildung $\Psi$: $\Psi$ ist injektiv $\iff$ Kern $\Psi = \{0\}$.
1.  $\Psi$ linear $\implies \Psi(\vec{0}) = \vec{0} \quad \textcolor{#e64c4c}{(2)}$.
2.  Annahme: $\Psi(\vec{x}) = \vec{0}$. Wegen $\textcolor{#e64c4c}{(2)}$ gilt $\Psi(\vec{x}) = \Psi(\vec{0})$. Da $\Psi$ injektiv ist, folgt $\vec{x} = \vec{0}$.
3.  Umgekehrt: Sei Kern $\Psi = \{0\}$. Aus $\phi(\vec{x}_1) = \phi(\vec{x}_2)$ folgt $\phi(\vec{x}_1 - \vec{x}_2) = \vec{0}$, also $\vec{x}_1 - \vec{x}_2 \in \text{Kern} \implies \vec{x}_1 = \vec{x}_2$.

### Theorem: Matrixdarstellung und Komposition
1.  **Darstellung:** $\phi : \mathbb{R}^n \to \mathbb{R}^m$ ist linear $\iff \exists \textcolor{#994ce6}{A} \in \mathbb{R}^{m \times n}$ mit $\phi(\vec{x}) = \textcolor{#994ce6}{A}\vec{x} \quad \forall \vec{x} \in \mathbb{R}^n$.
    Es gilt: Kern $\phi = \text{Kern } \textcolor{#994ce6}{A}$ und Bild $\phi = \text{Bild } \textcolor{#994ce6}{A}$.
2.  **Komposition:** Sind $\phi(\vec{x}) = \textcolor{#994ce6}{A}\vec{x}$ und $\Psi(\vec{y}) = \textcolor{#994ce6}{B}\vec{y}$ linear, dann ist die Verkettung $\Psi \circ \phi$ ebenfalls linear und entspricht dem Matrixprodukt:
    $$
    (\Psi \circ \phi)(\vec{x}) = \Psi(\phi(\vec{x})) = \textcolor{#994ce6}{B}(\textcolor{#994ce6}{A}\vec{x}) = (\textcolor{#994ce6}{B}\textcolor{#994ce6}{A})\vec{x}
    $$
3.  **Inversion:** Ist $n=m$ und $\textcolor{#994ce6}{A}$ invertierbar, so ist $\phi$ invertierbar und $\phi^{-1}(\vec{x}) = \textcolor{#994ce6}{A}^{-1}\vec{x}$.

> [!NOTE]
> Jede lineare Abbildung zwischen endlichdimensionalen Vektorräumen kann durch eine Matrix repräsentiert werden. Die Hintereinanderausführung von Abbildungen entspricht dabei der Multiplikation ihrer Matrizen.

---


![](V7-V8_Matrixprodukt__invertierbare_inverse_Matrizen__lineare_Abbildungen/V7-V8_Matrixprodukt__invertierbare_inverse_Matrizen__lineare_Abbildungen_p5_DIAGRAM_Circuit_LEN.excalidraw)


> [!IMPORTANT]
> **Mentimeter Frage:**
> Wir betrachten das LEN der linken Skizze.
> Ist die Abbildung $\phi : \mathbb{R} \to \mathbb{R}^3 \quad \phi(U) = \begin{pmatrix} I_1 \\ I_2 \\ I_3 \end{pmatrix}$ linear?
> (1) Ja
> (2) Nein
> (3) keine Ahnung