# V4 Basen und Dimension

## Interaktionsfrage zur linearen Unabhängigkeit

![](V4_Basen_Dimension/V4_Basen_Dimension_p1_Circuit_NodeAnalysis.excalidraw)

Sind die folgenden Vektoren linear unabhängig?

*   $\textcolor{#4ce6e6}{\begin{pmatrix} 1 \\ 0 \\ -1 \\ -1 \\ 0 \\ 0 \\ 0 \end{pmatrix}}$
*   $\textcolor{#e64c4c}{\begin{pmatrix} 0 \\ -1 \\ 1 \\ 0 \\ 1 \\ 0 \\ 0 \end{pmatrix}}$
*   $\textcolor{#e6994c}{\begin{pmatrix} -1 \\ 1 \\ 0 \\ 0 \\ 0 \\ 1 \\ 0 \end{pmatrix}}$
*   $\textcolor{#99e64c}{\begin{pmatrix} 0 \\ 0 \\ 0 \\ 1 \\ -1 \\ -1 \\ 0 \end{pmatrix}}$

Was bedeutet die Antwort darauf im Zusammenhang mit den Knotengleichungen?

### Knotengleichungen

Die Vektoren korrespondieren mit den Koeffizienten der Ströme in den Knotengleichungen:

| Knoten | Gleichung |
| :--- | :--- |
| $\textcolor{#4ce6e6}{A:}$ | $\textcolor{#4ce6e6}{1}I_1 + \textcolor{#4ce6e6}{0}I_2 + \textcolor{#4ce6e6}{(-1)}I_3 + \textcolor{#4ce6e6}{(-1)}I_4 + \textcolor{#4ce6e6}{0}I_5 + \textcolor{#4ce6e6}{0}I_6 \textcolor{#4ce6e6}{= 0}$ |
| $\textcolor{#e64c4c}{B:}$ | $\textcolor{#e64c4c}{0}I_1 + \textcolor{#e64c4c}{(-1)}I_2 + \textcolor{#e64c4c}{1}I_3 + \textcolor{#e64c4c}{0}I_4 + \textcolor{#e64c4c}{1}I_5 + \textcolor{#e64c4c}{0}I_6 \textcolor{#e64c4c}{= 0}$ |
| $\textcolor{#e6994c}{C:}$ | $\textcolor{#e6994c}{-1}I_1 + \textcolor{#e6994c}{1}I_2 + \textcolor{#e6994c}{0}I_3 + \textcolor{#e6994c}{0}I_4 + \textcolor{#e6994c}{0}I_5 + \textcolor{#e6994c}{1}I_6 \textcolor{#e6994c}{= 0}$ |
| $\textcolor{#99e64c}{D:}$ | $\textcolor{#99e64c}{0}I_1 + \textcolor{#99e64c}{0}I_2 + \textcolor{#99e64c}{0}I_3 + \textcolor{#99e64c}{1}I_4 + \textcolor{#99e64c}{(-1)}I_5 + \textcolor{#99e64c}{(-1)}I_6 \textcolor{#99e64c}{= 0}$ |

> [!NOTE]
> Die lineare Unabhängigkeit dieser Vektoren zeigt an, ob die aufgestellten Knotengleichungen redundante Informationen enthalten oder ob sie ein eindeutig lösbares System zur Bestimmung der Ströme bilden.

---

## 1.6 Basen und Dimension

### Definition und Satz
Sei $V$ ein $K$-Vektorraum und $n \in \mathbb{N}$. Die Vektoren $\textcolor{#e64c4c}{b_1, ..., b_n}$ heißen **Basis** von $V$, falls sie:
1.  Linear unabhängig sind.
2.  Ein Erzeugendensystem bilden: $V = \text{lin} \{ \textcolor{#e64c4c}{b_1, ..., b_n} \}$.

In diesem Fall hat jede Basis von $V$ genau $n$ Elemente und $n$ heißt **Dimension** von $V$ ($n=\dim(V)$).

*In Worten:* Eine Basis von $V$ ist eine möglichst kleine Menge, die $V$ aufspannt.

> [!NOTE]
> Eine Basis dient als minimales Bezugssystem, um jeden Vektor im Raum durch eine eindeutige Kombination zu konstruieren; die Anzahl der dafür nötigen Vektoren definiert die Dimension des Raumes.

### Beispiel 1.6.1: Basisnachweis im $\mathbb{R}^2$
Die Vektoren $\textcolor{#e64c4c}{(1;-1), (1;1)}$ bilden eine Basis von $\mathbb{R}^2$.

**Begründung:**
1.  **Lineare Unabhängigkeit:**
    $\textcolor{#e64c4c}{\alpha (1;1) + \beta (1;-1)} = (0;0) \implies (\alpha+\beta; \alpha-\beta) = (0;0)$
    $\implies \alpha = \beta = 0 \quad (\text{siehe Bsp. 1.4.2})$
2.  **Erzeugendensystem:**
    $\text{lin} \{ \textcolor{#e64c4c}{(1;1), (1;-1)} \} = \mathbb{R}^2$, weil $\forall (x,y) \in \mathbb{R}^2$ gilt:
    $(x;y) = \frac{x+y}{2} \textcolor{#e64c4c}{(1;1)} + \frac{x-y}{2} \textcolor{#e64c4c}{(1;-1)} \quad (\text{siehe Bsp. 1.2.4}).$

Daher gilt: $\dim(\mathbb{R}^2)=2$.

### Standardbasis im $\mathbb{R}^n$
Allgemein gilt $\dim(\mathbb{R}^n) = n$. Die Vektoren $\textcolor{#e64c4c}{e_1, ..., e_n}$ bilden die **Standardbasis** von $\mathbb{R}^n$, wobei:
$\textcolor{#e64c4c}{e_j} = (0;0;...;\underset{\substack{\uparrow \\ \textcolor{#e64c4c}{j\text{-te}} \text{ Komponente}}}{1};0;...;0)$

**Beispiel im $\mathbb{R}^3$:**
*   $\textcolor{#e64c4c}{e_1} = (1;0;0)$
*   $\textcolor{#e64c4c}{e_2} = (0;1;0)$
*   $\textcolor{#e64c4c}{e_3} = (0;0;1)$

> [!NOTE]
> Die Standardbasis besteht aus Einheitsvektoren, die jeweils genau eine Koordinatenachse repräsentieren, was die Darstellung von Vektoren trivial macht (die Komponenten des Vektors sind direkt die Koeffizienten der Basis).

### Beispiel 1.6.2: Dimension von $\mathbb{C}^2$
Die Dimension hängt vom zugrundeliegenden Skalarkörper ab: $\mathbb{C}^2 = \{ (x;y) : x,y \in \mathbb{C} \}$.

| Vektorraum-Typ | Skalarkörper | Basis | Dimension |
| :--- | :--- | :--- | :--- |
| **$\textcolor{#4ce6e6}{\mathbb{C}}$-Vektorraum** | $\textcolor{#4ce6e6}{\mathbb{C}}$ | $\textcolor{#99e64c}{(1;0), (0;1)}$ | **2** |
| **$\textcolor{#e6994c}{\mathbb{R}}$-Vektorraum** | $\textcolor{#e6994c}{\mathbb{R}}$ | $\textcolor{#e64c4c}{(1;0), (i;0), (0;1), (0;i)}$ | **4** |

**Beispielrechnung:**
Vektor $(3+5i ; 4+2i)$ zerlegt in beiden Räumen:
1.  **Über $\mathbb{C}$:**
    $(3+5i ; 4+2i) = \textcolor{#4ce6e6}{(3+5i)} \textcolor{#99e64c}{(1;0)} + \textcolor{#4ce6e6}{(4+2i)} \textcolor{#99e64c}{(0;1)}$
2.  **Über $\mathbb{R}$:**
    $(3+5i ; 4+2i) = \textcolor{#e6994c}{3} \textcolor{#e64c4c}{(1;0)} + \textcolor{#e6994c}{5} \textcolor{#e64c4c}{(i;0)} + \textcolor{#e6994c}{4} \textcolor{#e64c4c}{(0;1)} + \textcolor{#e6994c}{2} \textcolor{#e64c4c}{(0;i)}$

**Allgemeiner Satz:** Ein $\textcolor{#4ce6e6}{\mathbb{C}}$-Vektorraum der Dimension $n$ kann als ein $\textcolor{#e6994c}{\mathbb{R}}$-Vektorraum der Dimension $2n$ betrachtet werden.

> [!NOTE]
> Die Dimension eines Vektorraums ist relativ zum Körper der Skalare; reduziert man den Skalarkörper (z.B. von Komplex auf Real), werden mehr Basisvektoren benötigt, um denselben Raum aufzuspannen.

---

## Bestimmung von Basen mittels Zeilenumformungen

### Invarianz des linearen Aufspanns
Zeilenumformungen ändern den linearen Aufspann (den erzeugten Raum) der Zeilen **nicht**.

**Beweisidee:**
Sei der Übergang $\begin{pmatrix} c_1 \\ c_2 \end{pmatrix} \xrightarrow{z_2 \to z_2 - 2z_1} \begin{pmatrix} c_1 \\ c_2 - 2c_1 \end{pmatrix}$.

1.  **Hinrichtung:** Jeder Vektor im neuen System ist im alten System darstellbar.
    $\textcolor{#4c99e6}{a} c_1 + \textcolor{#4c99e6}{b} (c_2 - 2c_1) = (\textcolor{#4c99e6}{a-2b}) c_1 + \textcolor{#4c99e6}{b} c_2$
    $\implies$ Jeder Vektor im $\text{lin} \{c_1, c_2 - 2c_1\}$ liegt auch im $\text{lin} \{c_1, c_2\}$.

2.  **Rückrichtung:** Jeder Vektor im alten System ist im neuen System darstellbar.
    $a c_1 + b c_2 \stackrel{?}{=} \textcolor{#4c99e6}{x} c_1 + \textcolor{#4c99e6}{y} (c_2 - 2c_1)$
    Durch Koeffizientenvergleich ergibt sich:
    $\textcolor{#4c99e6}{x} = \textcolor{#4c99e6}{a+2b}$ und $\textcolor{#4c99e6}{y} = \textcolor{#4c99e6}{b}$.
    Also: $\textcolor{#4c99e6}{a} c_1 + \textcolor{#4c99e6}{b} c_2 = (\textcolor{#4c99e6}{a+2b}) c_1 + \textcolor{#4c99e6}{b} (c_2 - 2c_1)$.

$\implies \text{lin} \{c_1, c_2\} = \text{lin} \{c_1, c_2 - 2c_1\}$.

**Zusammenfassung des Verfahrens:**
Um eine Basis von $\text{lin} \{\underbrace{c_1, \dots, c_n}_{\text{Zeilenvektoren}}\}$ zu bestimmen:
1.  Schreibe $A = \begin{pmatrix} c_1 \\ \vdots \\ c_n \end{pmatrix}$.
2.  Bringe $A$ in Zeilenstufenform (ZSF).
3.  Die Basis besteht aus den Zeilen der ZSF, die **nicht Null** sind.

> [!NOTE]
> Elementare Zeilenumformungen manipulieren die Vektoren so, dass Redundanzen eliminiert werden (Nullzeilen entstehen), während der gesamte aufgespannte Raum (Information) identisch bleibt.

### Beispiel 1.6.3: Basisbestimmung durch ZSF
Untersuche $\textcolor{#99e64c}{c_1, c_2, c_3}$ auf lineare Unabhängigkeit und bestimme eine Basis von $A = \text{lin} \{ \textcolor{#99e64c}{c_1, c_2, c_3} \}$.
Gegeben: $\textcolor{#99e64c}{c_1=(1;2;3), c_2=(4;5;6), c_3=(7;8;9)}$.

**Lösung:**
$$
\begin{array}{rcccl}
\begin{matrix} \textcolor{#99e64c}{c_1} \\ \textcolor{#99e64c}{c_2} \\ \textcolor{#99e64c}{c_3} \end{matrix} & \begin{pmatrix} 1 & 2 & 3 \\ 4 & 5 & 6 \\ 7 & 8 & 9 \end{pmatrix} & \xrightarrow[z_3 \to z_3-7z_1]{z_2 \to z_2-4z_1} & \begin{matrix} \textcolor{#99e64c}{c_1} \\ \textcolor{#99e64c}{c_2-4c_1} \\ \textcolor{#99e64c}{c_3-7c_1} \end{matrix} \begin{pmatrix} 1 & 2 & 3 \\ 0 & -3 & -6 \\ 0 & -6 & -12 \end{pmatrix} & \xrightarrow{z_3 \to z_3-2z_2} \begin{matrix} \textcolor{#99e64c}{c_1} \\ \textcolor{#99e64c}{c_2-4c_1} \\ \textcolor{#99e64c}{c_3-7c_1-2\cdot(c_2-4c_1)} \end{matrix} \begin{pmatrix} 1 & 2 & 3 \\ 0 & -3 & -6 \\ 0 & 0 & 0 \end{pmatrix} \\
& & & & \qquad \qquad \qquad \qquad \hookrightarrow \text{ZSF erreicht}
\end{array}
$$

**Ergebnis:**
*   **Abhängigkeit:** Da eine Nullzeile entstand, gilt $\textcolor{#99e64c}{c_1 - 2c_2 + c_3} = (0;0;0)$. Die Vektoren sind linear abhängig.
*   **Basis:** Eine Basis von $A$ ist $(1;2;3), (0;-3;-6)$ (die Nicht-Null-Zeilen).

### Zusammenhang: ZSF und lineare Unabhängigkeit
Die ZSF garantiert lineare Unabhängigkeit der verbleibenden Zeilen.

**Beispiel:**
$$
\begin{pmatrix} 1 & 2 & 3 \\ 0 & 3 & 4 \\ 0 & 0 & 5 \end{pmatrix}
$$
Ansatz für Unabhängigkeit: $\alpha (1,2,3) + \beta (0,3,4) + \gamma (0,0,5) = (0,0,0)$

Lösung durch "Rückwärtseinsetzen" (wegen Stufenform):
1.  Erste Komponente: $1\alpha = 0 \implies \textcolor{#4c4ce6}{\alpha = 0}$.
2.  Reduzierte Gleichung: $\beta (0,3,4) + \gamma (0,0,5) = (0,0,0)$.
3.  Zweite Komponente: $3\beta = 0 \implies \textcolor{#4c4ce6}{\beta = 0}$.
4.  Dritte Komponente: $5\gamma = 0 \implies \textcolor{#4c4ce6}{\gamma = 0}$.

> [!NOTE]
> Die Stufenform einer Matrix ermöglicht es, Variablen sukzessive zu isolieren, wodurch zwangsläufig folgt, dass nur die triviale Lösung (alle Koeffizienten Null) existiert, was lineare Unabhängigkeit beweist.

---

## Koordinaten und Basiswechsel

### Definition 1.6: Eindeutigkeit der Koeffizienten
Ist $\textcolor{#e64c4c}{b_1, \dots, b_n}$ eine Basis von $V$ und $\textcolor{#99e64c}{v} \in V$, dann gibt es **eindeutig bestimmte** $\textcolor{#4c99e6}{\alpha_1, \dots, \alpha_n} \in K$ mit:
$$
\textcolor{#99e64c}{v} = \sum_{j=1}^n \textcolor{#4c99e6}{\alpha_j} \textcolor{#e64c4c}{b_j}
$$
Die Skalare $\textcolor{#4c99e6}{\alpha_1, \dots, \alpha_n}$ heißen **Koordinaten** von $v$ bzgl. der Basis $\textcolor{#e64c4c}{b_1, \dots, b_n}$.

> [!NOTE]
> Koordinaten sind die "Wegbeschreibung" zu einem Vektor; sie sind nur eindeutig und sinnvoll, wenn man sich auf eine feste Basis (das Bezugssystem) bezieht.

### Beispiele: Koordinatenberechnung im $\mathbb{R}^2$

**1. Bezüglich der Standardbasis:**
Basis: $\textcolor{#e64c4c}{(1,0), (0,1)}$
Darstellung: $\textcolor{#99e64c}{(x,y)} = \textcolor{#4c99e6}{x} \textcolor{#e64c4c}{(1,0)} + \textcolor{#4c99e6}{y} \textcolor{#e64c4c}{(0,1)}$
*   Die Koordinaten sind einfach $\textcolor{#4c99e6}{x}$ und $\textcolor{#4c99e6}{y}$.

**2. Bezüglich einer alternativen Basis:**
Basis: $\textcolor{#e64c4c}{(1,1), (1,-1)}$
Darstellung: $\textcolor{#99e64c}{(x,y)} = \textcolor{#4c99e6}{\frac{x+y}{2}} \textcolor{#e64c4c}{(1,1)} + \textcolor{#4c99e6}{\frac{x-y}{2}} \textcolor{#e64c4c}{(1,-1)}$
*   Die Koordinaten sind hier $\textcolor{#4c99e6}{\frac{x+y}{2}}$ und $\textcolor{#4c99e6}{\frac{x-y}{2}}$.

---

## Motivation und Anwendung

### Warum verschiedene Basen?

![](V4_Basen_Dimension/V4_Basen_Dimension_p3_Pendulum_Vector_Decomposition.excalidraw)

Ein Beispiel ist das Pendel.
Wir haben gesehen, dass wir die Erdanziehungskraft $\vec{E}$ als Linearkombination bzgl. der Basis $\textcolor{#e64c4c}{\vec{v}_1, \vec{v}_2}$ (tangential und normal zur Bahn) schreiben müssen, um die Bewegung zu verstehen.
Da sich das Pendel bewegt, ändern sich die Basisvektoren $\textcolor{#e64c4c}{\vec{v}_1, \vec{v}_2}$ mit der Zeit.

> [!NOTE]
> Die Wahl einer geeigneten Basis richtet sich oft nach der Symmetrie oder den physikalischen Gegebenheiten eines Problems, um die mathematische Beschreibung (Koordinaten) so einfach wie möglich zu gestalten.