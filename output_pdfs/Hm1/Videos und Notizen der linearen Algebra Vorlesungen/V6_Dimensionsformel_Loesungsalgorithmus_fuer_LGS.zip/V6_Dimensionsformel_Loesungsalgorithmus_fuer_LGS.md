# V6 Dimensionsformel & Lösungsalgorithmus für LGS

## 1. Die Dimensionsformel für Matrizen

> [!NOTE]
> **Wirkungsweise:** Die Dimensionsformel (auch Rangsatz genannt) verknüpft die Dimension des Bildraums (Rang) und die Dimension des Kerns (Defekt) einer Matrix additiv mit der Anzahl ihrer Spalten. Sie ist ein fundamentales Werkzeug zur Bestimmung der Lösungsstruktur linearer Abbildungen.

### 1.1 Grundlagen und Definition
Sei die Matrix $A \in \mathbb{R}^{2 \times 3}$:
$$
A = \begin{pmatrix} 1 & 2 & 3 \\ 2 & 4 & 6 \end{pmatrix}
$$

Diese erfüllt die Dimensionsformel:
$$
\dim \operatorname{Bild} A + \dim \ker A = 2 + 1 = \textcolor{#4ce6e6}{3}
$$

**Allgemeiner Satz:**
Für $A \in \mathbb{R}^{n \times m}$ gilt:
$$
\dim \operatorname{Bild} A + \dim \ker A = \textcolor{#4ce6e6}{m} \quad (\text{Anzahl der Spalten von A})
$$

### 1.2 Konstruktion von Bild und Kern (Beispiel A)

> [!NOTE]
> **Wirkungsweise:** Man wählt linear unabhängige Spalten als Basis des Bildes. Jede verbleibende Spalte ist eine Linearkombination dieser Basisvektoren; die Koeffizienten dieser Kombination liefern direkt die Vektoren des Kerns.

Das Bild ist definiert als der lineare Spann der Spalten:
$$
\operatorname{Bild}(A) = \operatorname{lin} \{ \text{Spalten von A} \}
$$

Für $A = \begin{pmatrix} 1 & 2 & 3 \\ 2 & 4 & 6 \end{pmatrix}$:
$$
\operatorname{Bild}(A) = \operatorname{lin} \left\{ \textcolor{#4ce64c}{\begin{pmatrix} 1 \\ 2 \end{pmatrix}}, \textcolor{#4ce64c}{\begin{pmatrix} 2 \\ 4 \end{pmatrix}}, \textcolor{#4ce64c}{\begin{pmatrix} 3 \\ 6 \end{pmatrix}} \right\} \to \text{3 Vektoren}
$$

**Analyse der Abhängigkeiten:**
Wir wählen $\begin{pmatrix} 1 \\ 2 \end{pmatrix}$ als Basisvektor. Die anderen Spalten werden durch diesen ausgedrückt, was Vektoren im Kern "liefert":

| Spaltenvektor | Linearkombination | Umformung zur Null | Kernvektor (geliefert) |
| :--- | :--- | :--- | :--- |
| $\textcolor{#4ce64c}{\begin{pmatrix} 2 \\ 4 \end{pmatrix}}$ | $= 2 \cdot \begin{pmatrix} 1 \\ 2 \end{pmatrix}$ | $\textcolor{#e64c4c}{-2} \cdot \begin{pmatrix} 1 \\ 2 \end{pmatrix} + \textcolor{#4ce64c}{1} \cdot \begin{pmatrix} 2 \\ 4 \end{pmatrix} + \textcolor{#e64c4c}{0} \cdot \begin{pmatrix} 3 \\ 6 \end{pmatrix} = \vec{0}$ | $\begin{pmatrix} \textcolor{#e64c4c}{-2} \\ \textcolor{#4ce64c}{1} \\ \textcolor{#e64c4c}{0} \end{pmatrix} \in \ker A$ |
| $\textcolor{#4ce64c}{\begin{pmatrix} 3 \\ 6 \end{pmatrix}}$ | $= 3 \cdot \begin{pmatrix} 1 \\ 2 \end{pmatrix}$ | $\textcolor{#e64c4c}{-3} \cdot \begin{pmatrix} 1 \\ 2 \end{pmatrix} + \textcolor{#e64c4c}{0} \cdot \begin{pmatrix} 2 \\ 4 \end{pmatrix} + \textcolor{#4ce64c}{1} \cdot \begin{pmatrix} 3 \\ 6 \end{pmatrix} = \vec{0}$ | $\begin{pmatrix} \textcolor{#e64c4c}{-3} \\ \textcolor{#e64c4c}{0} \\ \textcolor{#4ce64c}{1} \end{pmatrix} \in \ker A$ |

### 1.3 Vertiefung: Beispiel Matrix B

Betrachte $B = \begin{pmatrix} 1 & 1 & 2 \\ 1 & 0 & 1 \\ 0 & 1 & 1 \end{pmatrix}$.

1.  **Bestimmung des Bildes:**
    $$
    \operatorname{Bild} B = \operatorname{lin} \left\{ \begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}, \begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix}, \begin{pmatrix} 2 \\ 1 \\ 1 \end{pmatrix} \right\}
    $$
    Da $\begin{pmatrix} 2 \\ 1 \\ 1 \end{pmatrix} = \begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix} + \begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix}$, ist der dritte Vektor redundant.
    Die ersten zwei Vektoren sind linear unabhängig (nicht parallel).
    $$
    \Rightarrow \operatorname{Bild} B = \operatorname{lin} \left\{ \begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}, \begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix} \right\} \quad \text{und} \quad \dim \operatorname{Bild} B = 2
    $$

2.  **Bestimmung des Kerns:**
    Da der dritte Vektor eine Summe der ersten beiden ist:
    $$
    \textcolor{#e64c4c}{(-1)} \begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix} + \textcolor{#e64c4c}{(-1)} \begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix} + \textcolor{#e64c4c}{1} \begin{pmatrix} 2 \\ 1 \\ 1 \end{pmatrix} = \begin{pmatrix} 0 \\ 0 \\ 0 \end{pmatrix}
    $$
    $$
    \Longrightarrow \underbrace{B \begin{pmatrix} -1 \\ -1 \\ 1 \end{pmatrix} = \begin{pmatrix} 0 \\ 0 \\ 0 \end{pmatrix}}_{\text{Dies "liefert" den Kernvektor } \begin{pmatrix} -1 \\ -1 \\ 1 \end{pmatrix}}
    $$
    *Fazit:* Der Vektor $\begin{pmatrix} 2 \\ 1 \\ 1 \end{pmatrix}$ liefert nichts Neues für das Bild, aber etwas Neues für den Kern.

## 2. Lösungsalgorithmus für Lineare Gleichungssysteme

> [!NOTE]
> **Wirkungsweise:** Der Algorithmus (Gauß-Elimination) überführt die erweiterte Koeffizientenmatrix systematisch in die Zeilenstufenform (ZSF) und anschließend in die Zeilen-Normalform (ZNF), um die Lösbarkeit zu entscheiden und die Lösungsmenge parametrisch darzustellen.

### <span style="background-color:#994ce6">2.1 Der Algorithmus (Eliminationsverfahren von Gauß)</span>

Für ein System $A\vec{x}=\vec{b}$ mit $A \in \mathbb{R}^{n \times m}$:

1.  **Erweiterung:** Matrix $A$ um $\vec{b}$ als letzte Spalte erweitern: $(A \mid \vec{b})$.
2.  **Elimination:** Die erweiterte Matrix in Zeilenstufenform (ZSF) bringen. Sei $\textcolor{#4ce64c}{C}$ diese ZSF.
3.  **Analyse:**
    *   **(i) Lösbarkeit:** Das System ist **nicht lösbar**, wenn $\textcolor{#4ce64c}{C}$ eine Zeile der Form $(0, 0, \dots, 0 \mid d)$ mit $d \neq 0$ enthält (Widerspruch).
    *   **(ii) Lösung:** Falls lösbar, bringe $\textcolor{#4ce64c}{C}$ in Zeilen-Normalform (ZNF). Variablen mit Pivot-Koeffizient $\textcolor{#e64c4c}{1}$ werden nach den freien Variablen aufgelöst.

### 2.2 Beispiel 1.10.1: Fallunterscheidung
Gegeben sei $A = \begin{pmatrix} 2 & 4 & 10 & 12 \\ 0 & 1 & 2 & 3 \\ 1 & 4 & 9 & 12 \end{pmatrix}$.

#### Fall (i): Inhomogenes System (Unlösbar)
Sei $\vec{b} = \begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}$.

$$
(A \mid \vec{b}) = \begin{pmatrix} 2 & 4 & 10 & 12 & \vdots & 1 \\ 0 & 1 & 2 & 3 & \vdots & 1 \\ 1 & 4 & 9 & 12 & \vdots & 0 \end{pmatrix}
\xrightarrow{z_3 \to z_3 - \frac{1}{2} z_1}
\begin{pmatrix} 2 & 4 & 10 & 12 & \vdots & 1 \\ 0 & 1 & 2 & 3 & \vdots & 1 \\ 0 & 2 & 4 & 6 & \vdots & \frac{1}{2} \end{pmatrix}
$$

$$
\xrightarrow{z_3 \to z_3 - 2z_2}
\begin{pmatrix} 2 & 4 & 10 & 12 & \vdots & 1 \\ 0 & 1 & 2 & 3 & \vdots & 1 \\ 0 & 0 & 0 & 0 & \vdots & \colorbox{#e6e64c}{\( -\frac{5}{2} \)} \end{pmatrix}
$$

**Ergebnis:** Das System ist nicht lösbar, da die letzte Zeile $0x_1 + \dots + 0x_4 = -\frac{5}{2}$ impliziert.

#### Fall (ii): Homogenes System (Kern-Berechnung)
Sei $\vec{b} = \begin{pmatrix} 0 \\ 0 \\ 0 \end{pmatrix}$.

Die Umformungen verlaufen identisch, jedoch bleibt die rechte Seite 0.
$$
\begin{pmatrix} 2 & 4 & 10 & 12 & \vdots & 0 \\ 0 & 1 & 2 & 3 & \vdots & 0 \\ 0 & 0 & 0 & 0 & \vdots & 0 \end{pmatrix}
\to \text{Lösbarkeit erkennbar (ZSF)}
$$

**Weiterführung zur Zeilen-Normalform (ZNF):**
$$
\xrightarrow{z_1 \rightarrow z_1 - 4z_2}
\begin{pmatrix}
2 & 0 & 2 & 0 & \vdots & 0 \\
0 & 1 & 2 & 3 & \vdots & 0 \\
0 & 0 & 0 & 0 & \vdots & 0
\end{pmatrix}
\xrightarrow{z_1 \rightarrow \frac{z_1}{2}}
\begin{pmatrix}
\textcolor{#e64c4c}{1} & 0 & 1 & 0 & \vdots & 0 \\
0 & \textcolor{#e64c4c}{1} & 2 & 3 & \vdots & 0 \\
0 & 0 & 0 & 0 & \vdots & 0
\end{pmatrix}
$$

**Auflösen nach Pivot-Variablen ($x_1, x_2$):**
$$
\left\{
\begin{aligned}
\textcolor{#e64c4c}{1}x_1 + 1x_3 &= 0 \\
\textcolor{#e64c4c}{1}x_2 + 2x_3 + 3x_4 &= 0
\end{aligned}
\right\}
\implies
\begin{aligned}
x_1 &= -1x_3 \\
x_2 &= -2x_3 - 3x_4
\end{aligned}
$$

**Darstellung der Lösungsmenge:**
$$
\begin{pmatrix} x_1 \\ x_2 \\ x_3 \\ x_4 \end{pmatrix}
=
\begin{pmatrix} -1x_3 \\ -2x_3 - 3x_4 \\ x_3 \\ x_4 \end{pmatrix}
=
x_3 \begin{pmatrix} -1 \\ -2 \\ 1 \\ 0 \end{pmatrix}
+ x_4 \begin{pmatrix} 0 \\ -3 \\ 0 \\ 1 \end{pmatrix}
$$

**Ergebnis Kern:**
$$
\ker A = \operatorname{lin} \left\{ \begin{pmatrix} -1 \\ -2 \\ 1 \\ 0 \end{pmatrix}, \begin{pmatrix} 0 \\ -3 \\ 0 \\ 1 \end{pmatrix} \right\}
$$
Da die zwei Vektoren linear unabhängig sind, bilden sie eine Basis des Kerns.

### 2.3 Vergleich: Matrix- vs. Gleichungssystem-Ebene

> [!NOTE]
> **Wirkungsweise:** Dieser Vergleich demonstriert, dass Zeilenumformungen in einer Matrix exakt den arithmetischen Operationen (Addition/Subtraktion von Gleichungen) im zugehörigen linearen Gleichungssystem entsprechen.

| Matrix-Darstellung | Gleichungssystem-Darstellung |
| :--- | :--- |
| **Start:**<br>$\begin{pmatrix} 2 & 4 & 10 & 12 & \vdots & 1 \\ 0 & 1 & 2 & 3 & \vdots & 1 \\ 1 & 4 & 9 & 12 & \vdots & 0 \end{pmatrix}$ | **Start:**<br>$2x_1 + 4x_2 + 10x_3 + 12x_4 = 1 \quad \textcolor{#e64c4c}{(1)}$<br>$0x_1 + 1x_2 + 2x_3 + 3x_4 = 1 \quad \textcolor{#e64c4c}{(2)}$<br>$1x_1 + 4x_2 + 9x_3 + 12x_4 = 0 \quad \textcolor{#e64c4c}{(3)}$ |
| **Schritt 1:** $\textcolor{#e64c4c}{z_3 \rightarrow z_3 - \frac{1}{2}z_1}$<br>$\begin{pmatrix} 2 & 4 & 10 & 12 & \vdots & 1 \\ 0 & 1 & 2 & 3 & \vdots & 1 \\ 0 & 2 & 4 & 6 & \vdots & \frac{1}{2} \end{pmatrix}$ | **Schritt 1:** $\textcolor{#e64c4c}{(3) \rightarrow (3) - \frac{1}{2}(1)}$<br>$2x_1 + 4x_2 + 10x_3 + 12x_4 = 1 \quad \textcolor{#e6994c}{(1)}$<br>$0x_1 + 1x_2 + 2x_3 + 3x_4 = 1 \quad \textcolor{#e6994c}{(2)}$<br>$0x_1 + 2x_2 + 4x_3 + 6x_4 = \frac{1}{2} \quad \textcolor{#e6994c}{(3)}$ |
| **Schritt 2:** $\textcolor{#4c99e6}{z_3 \rightarrow z_3 - 2z_2}$<br>$\begin{pmatrix} 2 & 4 & 10 & 12 & \vdots & 1 \\ 0 & 1 & 2 & 3 & \vdots & 1 \\ 0 & 0 & 0 & 0 & \vdots & -\frac{5}{2} \end{pmatrix}$ | **Schritt 2:** $\textcolor{#e6994c}{(3) \rightarrow (3) - 2(2)}$<br>$2x_1 + 4x_2 + 10x_3 + 12x_4 = 1$<br>$0x_1 + 1x_2 + 2x_3 + 3x_4 = 1$<br>$0x_1 + 0x_2 + 0x_3 + 0x_4 = \colorbox{#e6e64c}{\( -\frac{5}{2} \)}$ |

## 3. Konzept-Check: Invarianz unter Umformungen

> [!NOTE]
> **Wirkungsweise:** Elementare Zeilenumformungen verändern den Zeilenraum nicht, weshalb der Lösungsraum (Kern) invariant bleibt. Der Spaltenraum (Bild) ändert sich jedoch, obwohl die Dimension des Bildes gleich bleibt.

### <u>Mentimeterfrage</u>: Ändern Zeilenumformungen das Bild und den Kern einer Matrix?

1.  Sowohl den Kern als auch das Bild
2.  Den Kern ja, das Bild nein
3.  Den Kern nein, das Bild ja
4.  Weder den Kern noch das Bild
5.  Keine Ahnung