# Vorlesung 2: Linearkombinationen, linearer Aufspann, lineare Unabhängigkeit

**Datum:** 07.11.2024

**Einstiegsfrage:** Beschreibe alle Unterräume von $\mathbb{R}^2$.
*(Interaktionsfrage für $\mathbb{R}^3$?)*

*   (i) $\mathbb{R}^2$
*   (ii) Alle Geraden, die durch $(0,0)$ gehen
*   (iii) $\{(0,0)\}$

## 1. Definitionen und Lineare Hülle (Def. 1.4)

Sei $V$ ein $K$-Vektorraum ($K=\mathbb{R}$ oder $K=\mathbb{C}$), $\textcolor{#e6994c}{v_1, ..., v_n} \in V$ und $\textcolor{#4ce6e6}{\alpha_1, ..., \alpha_n} \in K$.

Der Vektor $\textcolor{#4ce6e6}{\alpha_1}\textcolor{#e6994c}{v_1} + \textcolor{#4ce6e6}{\alpha_2}\textcolor{#e6994c}{v_2} + ... + \textcolor{#4ce6e6}{\alpha_n}\textcolor{#e6994c}{v_n}$ heißt **Linearkombination** von $\textcolor{#e6994c}{v_1, ..., v_n}$.

Sei $\textcolor{#99e64c}{M} \subseteq V$ mit $\textcolor{#99e64c}{M} \neq \emptyset$. Dann ist:
$$ \textcolor{#99e64c}{lin(M)} = \{ \textcolor{#4ce6e6}{\alpha_1}\textcolor{#e6994c}{v_1} + ... + \textcolor{#4ce6e6}{\alpha_n}\textcolor{#e6994c}{v_n} : n \in \mathbb{N}, \textcolor{#4ce6e6}{\alpha_j} \in K, \textcolor{#e6994c}{v_j} \in \textcolor{#99e64c}{M} \quad \forall j=1,...,n \} $$
Dies ist ein Unterraum von $V$ und heißt **linearer Aufspann** von $M$.

> [!NOTE]
> **Funktionsweise:** Eine Linearkombination ist das Ergebnis der Skalierung und Addition von Vektoren. Der lineare Aufspann (auch lineare Hülle) beschreibt die Gesamtmenge aller Vektoren, die theoretisch durch Kombination der Vektoren aus $M$ erreicht werden können (z. B. eine ganze Ebene, die durch zwei Vektoren aufgespannt wird).

### Beispiel 1.2.4: Linearkombination im $\mathbb{R}^2$

Gegeben sei $V=\mathbb{R}^2$.

**Berechnung:**
$$ \textcolor{#4ce6e6}{4} \cdot \textcolor{#e6994c}{(1;1)} + \textcolor{#4ce6e6}{3} \cdot \textcolor{#e6994c}{(1;-1)} = \underline{(4;4)} + \underline{(3;-3)} = (7;1) $$

*(siehe Skizze unten)*

Also ist $(7;1)$ eine Linearkombination von $\textcolor{#e6994c}{(1;1)}$ und $\textcolor{#e6994c}{(1;-1)}$.

**Linearer Aufspann:**
Sei $\textcolor{#99e64c}{M} = \{ \textcolor{#e6994c}{(1;1)}, \textcolor{#e6994c}{(1;-1)} \}$. Dann gilt $lin(\textcolor{#99e64c}{M}) = \mathbb{R}^2$.

**Beweis (z.z. $\mathbb{R}^2 \subseteq \textcolor{#99e64c}{lin(M)}$):**
Wir zeigen, dass jeder Vektor $(x,y) \in \mathbb{R}^2$ als Linearkombination dargestellt werden kann. Wir suchen Zahlen $\textcolor{#4ce6e6}{\alpha_1, \alpha_2}$ mit:

$$ \underset{\text{bekannt} \nearrow}{(x;y)} = \underset{\nwarrow \text{unbekannt}}{\textcolor{#4ce6e6}{\alpha_1}(1;1) + \textcolor{#4ce6e6}{\alpha_2}(1;-1)} $$

$$ \Leftrightarrow \quad (x;y) = (\textcolor{#4ce6e6}{\alpha_1} + \textcolor{#4ce6e6}{\alpha_2} \ ; \ \textcolor{#4ce6e6}{\alpha_1} - \textcolor{#4ce6e6}{\alpha_2}) $$

Dies führt zu folgendem Gleichungssystem:

$$ \begin{cases} \textcolor{#4ce6e6}{\alpha_1} + \textcolor{#4ce6e6}{\alpha_2} = x & \textcolor{#e64c4c}{(1)} \\ \textcolor{#4ce6e6}{\alpha_1} - \textcolor{#4ce6e6}{\alpha_2} = y & \textcolor{#e64c4c}{(2)} \end{cases} $$

**Lösungsschritte:**
*   $\textcolor{#e64c4c}{(1)+(2)}: \quad 2\textcolor{#4ce6e6}{\alpha_1} = x+y \quad \Rightarrow \textcolor{#4ce6e6}{\alpha_1} = \frac{x+y}{2}$
*   $\textcolor{#e64c4c}{(1)-(2)}: \quad 2\textcolor{#4ce6e6}{\alpha_2} = x-y \quad \Rightarrow \textcolor{#4ce6e6}{\alpha_2} = \frac{x-y}{2}$

Da für jedes $x,y$ Lösungen für $\alpha$ existieren, wird der gesamte $\mathbb{R}^2$ aufgespannt.

![](Vorlesung_2_Linearkombinationen__linearer_Aufspann__lineare_Unabhaengigkeit/Vorlesung_2_Linearkombinationen__linearer_Aufspann__lineare_Unabhaengigkeit_p1_VektorAddition_R2.excalidraw)

### Beispiel 1.2.3: Linearkombination im $\mathbb{R}^3$

Seien $\textcolor{#e6994c}{\vec{v}_1} = \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix}}, \textcolor{#e6994c}{\vec{v}_2} = \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}}$.
($\hookrightarrow$ alternative Notation für $(1;0;1)$).

**Fall 1: Erfolgreiche Linearkombination**
Es gilt: $\begin{pmatrix} 2 \\ 1 \\ 1 \end{pmatrix} = \textcolor{#4ce6e6}{1} \cdot \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix}} + \textcolor{#4ce6e6}{1} \cdot \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}}$.
Also ist $\begin{pmatrix} 2 \\ 1 \\ 1 \end{pmatrix}$ eine Linearkombination von $\textcolor{#e6994c}{\vec{v}_1}, \textcolor{#e6994c}{\vec{v}_2}$.
$$ \text{Notation: } \begin{pmatrix} 2 \\ 1 \\ 1 \end{pmatrix} \in lin \left\{ \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix}}, \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}} \right\} $$

**Fall 2: Keine Linearkombination**
$\begin{pmatrix} 1 \\ 1 \\ 1 \end{pmatrix}$ ist **keine** Linearkombination von $\textcolor{#e6994c}{\vec{v}_1}, \textcolor{#e6994c}{\vec{v}_2}$.

*Beweis durch Widerspruch:*
Gäbe es $\textcolor{#4ce6e6}{\alpha, \beta} \in \mathbb{R}$ mit $\begin{pmatrix} 1 \\ 1 \\ 1 \end{pmatrix} = \textcolor{#4ce6e6}{\alpha} \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix}} + \textcolor{#4ce6e6}{\beta} \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}}$, dann folgte:
$$ \begin{pmatrix} 1 \\ 1 \\ 1 \end{pmatrix} = \begin{pmatrix} \alpha + \beta \\ \beta \\ \alpha \end{pmatrix} \Rightarrow \left\{ \begin{smallmatrix} \alpha + \beta &=& 1 \\ \beta &=& 1 \\ \alpha &=& 1 \end{smallmatrix} \right. $$
Einsetzen von $\alpha=1$ und $\beta=1$ in die erste Gleichung ergibt $1+1=2 \neq 1$. Dies ist widersprüchlich.
$$ \Rightarrow \begin{pmatrix} 1 \\ 1 \\ 1 \end{pmatrix} \notin lin \left\{ \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 0 \\ 1 \end{pmatrix}}, \textcolor{#e6994c}{\begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}} \right\} $$

### Geometrische Interpretation & Physikalische Anwendung

**Geometrie:**
Wenn $\textcolor{#e6994c}{\vec{v}_1, \vec{v}_2}$ nicht parallel sind, ist $lin \left\{ \textcolor{#e6994c}{\vec{v}_1, \vec{v}_2} \right\}$ die <span style="color:#4c99e6">Ebene</span>, die $\textcolor{#e6994c}{\vec{v}_1, \vec{v}_2}$ enthält.

![](Vorlesung_2_Linearkombinationen__linearer_Aufspann__lineare_Unabhaengigkeit/Vorlesung_2_Linearkombinationen__linearer_Aufspann__lineare_Unabhaengigkeit_p1_PlaneSpannedByVectors.excalidraw)

**Anwendung (Kräftezerlegung):**
Linearkombinationen sind zentral für Anwendungen, z.B. bei der Analyse eines Pendels.

![](Vorlesung_2_Linearkombinationen__linearer_Aufspann__lineare_Unabhaengigkeit/Vorlesung_2_Linearkombinationen__linearer_Aufspann__lineare_Unabhaengigkeit_p2_Pendulum_Force_Decomposition.excalidraw)

*   $\textcolor{#e64c4c}{\vec{v}_1}$: parallel zur Schnur.
*   $\textcolor{#e64c4c}{\vec{v}_2}$: senkrecht zur Schnur.

Um die Bewegung des Balles zu analysieren, muss man die Erdanziehungskraft $\vec{E}$ als Linearkombination von $\textcolor{#e64c4c}{\vec{v}_1}, \textcolor{#e64c4c}{\vec{v}_2}$ schreiben:

$$ \vec{E} = \underbrace{\textcolor{#4ce6e6}{\alpha_1} \textcolor{#e64c4c}{\vec{v}_1}}_{= \textcolor{#99e64c}{\vec{E}_1}} + \underbrace{\textcolor{#4ce6e6}{\alpha_2} \textcolor{#e64c4c}{\vec{v}_2}}_{= \textcolor{#99e64c}{\vec{E}_2}} $$

*   $\textcolor{#99e64c}{\vec{E}_1}$: Komponente von $\vec{E}$ parallel zur Schnur (wird von der Schnur ausgeglichen).
*   $\textcolor{#99e64c}{\vec{E}_2}$: Komponente von $\vec{E}$ senkrecht zur Schnur (beschleunigt den Ball).

## 2. Lineare Unabhängigkeit (1.4)

**Definition:** Sei $V$ ein $K$-Vektorraum. $n$ Vektoren $\textcolor{#e6994c}{\vec{v}_1, ..., \vec{v}_n} \in V$ heißen **linear unabhängig**, wenn $\textcolor{#4ce6e6}{\forall \alpha_1, ..., \alpha_n} \in K$ gilt:

$$ \sum_{j=1}^n \textcolor{#4ce6e6}{\alpha_j} \textcolor{#e6994c}{\vec{v}_j} = \vec{0} \Rightarrow \textcolor{#4ce6e6}{\alpha_1 = \alpha_2 = ... = \alpha_n = 0} $$

Sonst heißen die Vektoren **linear abhängig**.

> [!NOTE]
> **Funktionsweise:** Lineare Unabhängigkeit bedeutet Redundanzfreiheit. Vektoren sind unabhängig, wenn keiner von ihnen durch eine Kombination der anderen dargestellt werden kann. Die einzige Möglichkeit, durch Kombination den Nullvektor zu erzeugen, ist, alle Skalare trivialerweise auf 0 zu setzen.

### Beispiel 1.4.1 – 1.4.2: Überprüfung der Unabhängigkeit

| Vektoren | Status | Begründung / Berechnung |
| :--- | :--- | :--- |
| $\textcolor{#e6994c}{(1;0)}, \textcolor{#e6994c}{(0;1)}$ | **Unabhängig** | $\textcolor{#4ce6e6}{\alpha_1} \textcolor{#e6994c}{(1;0)} + \textcolor{#4ce6e6}{\alpha_2} \textcolor{#e6994c}{(0;1)} = (0;0) \Rightarrow \textcolor{#4ce6e6}{\alpha_1 = \alpha_2 = 0}$ |
| $\textcolor{#e6994c}{\binom{1}{3}}, \textcolor{#e6994c}{\binom{2}{6}}$ | **Abhängig** | Skalierbar: $\textcolor{#4ce6e6}{1} \cdot \textcolor{#e6994c}{\binom{2}{6}} + \textcolor{#4ce6e6}{(-2)} \textcolor{#e6994c}{\binom{1}{3}} = 0$ |
| $\textcolor{#e6994c}{\binom{1}{1}}, \textcolor{#e6994c}{\binom{0}{0}}$ | **Abhängig** | Nullvektor dabei: $\textcolor{#4ce6e6}{0} \textcolor{#e6994c}{\binom{1}{1}} + \underset{\textcolor{#e64c4c}{\neq 0}}{\textcolor{#e64c4c}{\boxed{5}}} \textcolor{#e6994c}{\binom{0}{0}} = 0$ |

**Detaillierte Prüfung (Bsp 1.4.2):**

**(i)** Vektoren: $\textcolor{#e6994c}{(1;1)}$ und $\textcolor{#e6994c}{(1;-1)}$
Ansatz: $\textcolor{#4ce6e6}{\alpha_1} \textcolor{#e6994c}{(1;1)} + \textcolor{#4ce6e6}{\alpha_2} \textcolor{#e6994c}{(1;-1)} = (0;0)$
$$ \Rightarrow (\textcolor{#4ce6e6}{\alpha_1 + \alpha_2} ; \textcolor{#4ce6e6}{\alpha_1 - \alpha_2}) = (0;0) $$
$$ \Rightarrow \begin{cases} \textcolor{#4ce6e6}{\alpha_1} + \textcolor{#4ce6e6}{\alpha_2} = 0 & \textcolor{#e64c4c}{(1)} \\ \textcolor{#4ce6e6}{\alpha_1} - \textcolor{#4ce6e6}{\alpha_2} = 0 & \textcolor{#e64c4c}{(2)} \end{cases} $$
Durch Addition $\textcolor{#e64c4c}{(1)+(2)}$ folgt $2\textcolor{#4ce6e6}{\alpha_1} = 0 \Rightarrow \textcolor{#4ce6e6}{\alpha_1} = 0$. Daraus folgt auch $\textcolor{#4ce6e6}{\alpha_2} = 0$.
$\rightarrow$ **Linear unabhängig**.

**(ii)** Vektoren: $\textcolor{#e6994c}{\binom{1}{2}{3}}, \textcolor{#e6994c}{\binom{4}{5}{6}}, \textcolor{#e6994c}{\binom{7}{8}{9}}$
Diese sind **linear abhängig**, da eine nicht-triviale Nullsumme existiert:
$$ \textcolor{#4ce6e6}{-1} \textcolor{#e6994c}{\binom{1}{2}{3}} + \textcolor{#4ce6e6}{2} \textcolor{#e6994c}{\binom{4}{5}{6}} + \textcolor{#4ce6e6}{(-1)} \textcolor{#e6994c}{\binom{7}{8}{9}} = \binom{0}{0}{0} $$
Hier ist der Koeffizientenvektor $\textcolor{#4ce6e6}{(-1; 2; -1) \neq (0;0;0)}$.

**Wichtige Bemerkung:** Zwei Vektoren sind linear abhängig $\Leftrightarrow$ sie sind parallel.

### Verständnis-Check (Mentimeter Frage)

Drei Vektoren $\vec{a}, \vec{b}, \vec{c}$ im $\mathbb{R}^3$ mit Anfangspunkt (0;0;0) sind **linear abhängig** genau dann, wenn:

1.  $\vec{a} \parallel \vec{b} \parallel \vec{c}$ ("//" bedeutet parallel)
2.  $\vec{a} \parallel \vec{b}$ oder $\vec{a} \parallel \vec{c}$ oder $\vec{b} \parallel \vec{c}$.
3.  $\vec{a}, \vec{b}, \vec{c}$ liegen auf einer Ebene.
4.  Keine der obigen Antworten.
5.  Keine Ahnung.