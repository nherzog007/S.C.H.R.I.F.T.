# V5 Lineare Gleichungssysteme, Bild, Kern

## <span style="background-color:#994ce6">Matrixoperationen: Addition und Skalarmultiplikation</span>

Die grundlegenden Rechenoperationen für Matrizen basieren auf der komponentenweisen Verknüpfung der Einträge.

$$
\textcolor{#99e64c}{5} \cdot \begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix} = \begin{pmatrix} 1 \cdot \textcolor{#99e64c}{5} & 2 \cdot \textcolor{#99e64c}{5} \\ 3 \cdot \textcolor{#99e64c}{5} & 4 \cdot \textcolor{#99e64c}{5} \end{pmatrix} = \begin{pmatrix} 5 & 10 \\ 15 & 20 \end{pmatrix}
$$

$$
\begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix} + \begin{pmatrix} 5 & 6 \\ 7 & 8 \end{pmatrix} = \begin{pmatrix} 1+5 & 2+6 \\ 3+7 & 4+8 \end{pmatrix} = \begin{pmatrix} 6 & 8 \\ 10 & 12 \end{pmatrix}
$$

> [!CAUTION]
> **Dimensionskompatibilität:**
> $$
> \begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix} + \begin{pmatrix} 1 & 2 \\ 3 & 4 \\ 5 & 6 \end{pmatrix} \quad \text{ist nicht definiert (unterschiedliche Dimensionen).}
> $$

> [!NOTE]
> Matrizen werden elementweise addiert oder mit einem Skalar multipliziert, was die Linearität der Struktur erhält; Operationen sind nur bei identischen Dimensionen definiert.

## <span style="background-color:#994ce6">1.7 Lineare Gleichungssysteme (LGS)</span>

Ein <span style="color:#994ce6">(LGS)</span> beschreibt lineare Beziehungen zwischen Variablen und Konstanten. Es hat die allgemeine Form:

$$
\left. \begin{matrix} \textcolor{#4ce6e6}{a_{11}}\textcolor{#e64c4c}{x_1} + \textcolor{#4ce6e6}{a_{12}}\textcolor{#e64c4c}{x_2} + \dots + \textcolor{#4ce6e6}{a_{1m}}\textcolor{#e64c4c}{x_m} = \textcolor{#4ce6e6}{b_1} \\ \vdots \qquad \vdots \qquad \qquad \qquad \vdots \qquad \vdots \\ \textcolor{#4ce6e6}{a_{n1}}\textcolor{#e64c4c}{x_1} + \textcolor{#4ce6e6}{a_{n2}}\textcolor{#e64c4c}{x_2} + \dots + \textcolor{#4ce6e6}{a_{nm}}\textcolor{#e64c4c}{x_m} = \textcolor{#4ce6e6}{b_n} \end{matrix} \right\} \textcolor{#e64c4c}{(*)} \quad \begin{matrix} \textcolor{#4ce6e6}{\text{bekannt}} \\ \textcolor{#e64c4c}{\text{gesucht}} \end{matrix}
$$

### 1.7.1 Matrix-Vektor-Schreibweise

Das LGS lässt sich kompakt als Matrix-Vektor-Multiplikation darstellen: $\textcolor{#4ce6e6}{A}\textcolor{#e64c4c}{\vec{x}} = \textcolor{#4ce6e6}{\vec{b}}$.

| Komponente | Darstellung | Dimension |
| :--- | :--- | :--- |
| **Koeffizientenmatrix** | $\textcolor{#4ce6e6}{A} = \begin{pmatrix} \textcolor{#4ce6e6}{a_{11}} & \dots & \textcolor{#4ce6e6}{a_{1m}} \\ \vdots & & \vdots \\ \textcolor{#4ce6e6}{a_{n1}} & \dots & \textcolor{#4ce6e6}{a_{nm}} \end{pmatrix}$ | $\mathbb{R}^{\textcolor{#e6994c}{n \times m}}$ |
| **Lösungsvektor** | $\textcolor{#e64c4c}{\vec{x}} = \begin{pmatrix} \textcolor{#e64c4c}{x_1} \\ \vdots \\ \textcolor{#e64c4c}{x_m} \end{pmatrix}$ | $\mathbb{R}^{\textcolor{#e6994c}{m}}$ |
| **Ergebnisvektor** | $\textcolor{#4ce6e6}{\vec{b}} = \begin{pmatrix} \textcolor{#4ce6e6}{b_1} \\ \vdots \\ \textcolor{#4ce6e6}{b_n} \end{pmatrix}$ | $\mathbb{R}^{\textcolor{#e6994c}{n}}$ |

Die Multiplikation $\textcolor{#4ce6e6}{A}\textcolor{#e64c4c}{\vec{x}}$ ist definiert als Linearkombination der Spaltenvektoren von $A$:

$$
\underset{\text{erste Spalte}}{\begin{pmatrix} \textcolor{#4ce6e6}{a_{11}} \\ \vdots \\ \textcolor{#4ce6e6}{a_{n1}} \end{pmatrix}} \textcolor{#e64c4c}{x_1} + \dots + \underset{\text{m-te Spalte}}{\begin{pmatrix} \textcolor{#4ce6e6}{a_{1m}} \\ \vdots \\ \textcolor{#4ce6e6}{a_{nm}} \end{pmatrix}} \textcolor{#e64c4c}{x_m}
$$

> [!NOTE]
> Ein LGS wird als Abbildung verstanden, bei der eine Matrix $A$ einen Vektor $\vec{x}$ transformiert, um einen Zielvektor $\vec{b}$ zu erreichen; dies entspricht einer Linearkombination der Spaltenvektoren.

### Beispiel: Explizite Berechnung

$$
\begin{pmatrix} \textcolor{#4c99e6}{1} & \textcolor{#4c99e6}{2} \\ \textcolor{#4c99e6}{3} & \textcolor{#4c99e6}{5} \end{pmatrix} \begin{pmatrix} \textcolor{#e64c4c}{x_1} \\ \textcolor{#e64c4c}{x_2} \end{pmatrix} = \textcolor{#e64c4c}{x_1} \begin{pmatrix} \textcolor{#4c99e6}{1} \\ \textcolor{#4c99e6}{3} \end{pmatrix} + \textcolor{#e64c4c}{x_2} \begin{pmatrix} \textcolor{#4c99e6}{2} \\ \textcolor{#4c99e6}{5} \end{pmatrix} = \begin{pmatrix} \textcolor{#4c99e6}{1}\textcolor{#e64c4c}{x_1} + \textcolor{#4c99e6}{2}\textcolor{#e64c4c}{x_2} \\ \textcolor{#4c99e6}{3}\textcolor{#e64c4c}{x_1} + \textcolor{#4c99e6}{5}\textcolor{#e64c4c}{x_2} \end{pmatrix} \quad \textcolor{#994ce6}{(1)}
$$

Daraus folgt die Äquivalenz zum klassischen Gleichungssystem:

$$
\begin{matrix} \textcolor{#4c99e6}{1}\textcolor{#e64c4c}{x_1} + \textcolor{#4c99e6}{2}\textcolor{#e64c4c}{x_2} = \textcolor{#4ce6e6}{6} \\ \textcolor{#4c99e6}{3}\textcolor{#e64c4c}{x_1} + \textcolor{#4c99e6}{5}\textcolor{#e64c4c}{x_2} = \textcolor{#4ce6e6}{7} \end{matrix} \quad \Leftrightarrow \quad \begin{pmatrix} \textcolor{#4c99e6}{1} & \textcolor{#4c99e6}{2} \\ \textcolor{#4c99e6}{3} & \textcolor{#4c99e6}{5} \end{pmatrix} \begin{pmatrix} \textcolor{#e64c4c}{x_1} \\ \textcolor{#e64c4c}{x_2} \end{pmatrix} = \begin{pmatrix} \textcolor{#4ce6e6}{6} \\ \textcolor{#4ce6e6}{7} \end{pmatrix}
$$

### Mentifrage zum Verständnis (Bild und Kern)

Sei $A = \begin{pmatrix} a & c \\ b & d \end{pmatrix}$ und $\text{Kern}A = \text{lin}\{ \begin{pmatrix} 1 \\ 1 \end{pmatrix} \}$.

| Frage | Antwortoptionen | Hinweis |
| :--- | :--- | :--- |
| **(i)** Ist es möglich, dass $\text{Bild} A = \mathbb{R}^2$? | (1) Ja<br>(2) Nein<br>(3) Keine Ahnung | <u>Hinweis 1:</u> Verwende $\begin{pmatrix} 1 \\ 1 \end{pmatrix} \in \text{Kern}A$ um $c,d$ mittels $a,b$ zu schreiben. |
| **(ii)** Ist es möglich, dass $\text{Bild} A = \{ \vec{0} \}$? | (4) Ja<br>(5) Nein<br>(6) Keine Ahnung | <u>Hinweis 2:</u> $\vec{y} \in \text{Bild} A \Leftrightarrow \exists \vec{x} : \vec{y} \in \text{lin} \left\{ \begin{pmatrix} a \\ b \end{pmatrix}, \begin{pmatrix} c \\ d \end{pmatrix} \right\}$. |

![](V5_lineare_Gleichungssysteme__Bild__Kern/V5_lineare_Gleichungssysteme__Bild__Kern_p1_Diagram_1.excalidraw)

## <span style="background-color:#dcdcdc">1.9 Lösungsmenge, Bild und Kern</span>

Wir untersuchen die Lösbarkeit des Systems $A\textcolor{#4ce6e6}{\vec{x}} = \textcolor{#4ce6e6}{\vec{b}}$ mit $A \in \mathbb{R}^{\textcolor{#e6994c}{n} \times \textcolor{#e6994c}{m}}$.

### 1.9.1 Definitionen

1.  **Lösbarkeit (Bild):** Für welche $\textcolor{#4ce6e6}{\vec{b}}$ existiert eine Lösung?
    *   $\text{Bild}(A) = \{ A\vec{x} : \vec{x} \in \mathbb{R}^m \} \subseteq \mathbb{R}^n$
    *   *Interpretation:* $\textcolor{#4ce6e6}{\vec{b}} \in \text{Bild}(A)$ genau dann, wenn $A\vec{x} = \textcolor{#4ce6e6}{\vec{b}}$ lösbar ist.
2.  **Homogene Lösung (Kern):** Wie sieht die Lösungsmenge für $\vec{b} = \vec{0}$ aus?
    *   $\text{Kern}(A) = \{ \vec{x} \in \mathbb{R}^m : A \cdot \vec{x} = \vec{0} \} \subseteq \mathbb{R}^m$
    *   *Interpretation:* $\vec{x}_0 \in \text{Kern}(A)$, wenn $\vec{x}_0$ das <span style="background-color:#99e64c">homogene System</span> löst.

> [!NOTE]
> Der Kern umfasst alle Vektoren, die durch die Matrix auf den Nullvektor abgebildet werden (Verlust an Information), während das Bild den Raum aller möglichen Ergebnisse der Transformation darstellt.

### Beispiel 1.9.1: Bestimmung von Kern und Bild

Sei $A = \begin{pmatrix} 1 & 2 & 3 \\ 2 & 4 & 6 \end{pmatrix}$.

**A. Überprüfung einzelner Vektoren:**
*   $\textcolor{#e64c4c}{\begin{pmatrix} 3 \\ 0 \\ -1 \end{pmatrix}} \in \text{Kern}(A)$, denn:
    $$
    3 \cdot \begin{pmatrix} 1 \\ 2 \end{pmatrix} + 0 \cdot \begin{pmatrix} 2 \\ 4 \end{pmatrix} + (-1) \cdot \begin{pmatrix} 3 \\ 6 \end{pmatrix} = \begin{pmatrix} 3 \\ 6 \end{pmatrix} - \begin{pmatrix} 3 \\ 6 \end{pmatrix} = \begin{pmatrix} 0 \\ 0 \end{pmatrix}
    $$
*   $\textcolor{#e64c4c}{\begin{pmatrix} 1 \\ 0 \\ 0 \end{pmatrix}} \notin \text{Kern}(A)$, da das Ergebnis $\begin{pmatrix} 1 \\ 2 \end{pmatrix} \neq \vec{0}$ ist.
*   $\textcolor{#4ce6e6}{\begin{pmatrix} 2 \\ 4 \end{pmatrix}} \in \text{Bild}(A)$, da $A \textcolor{#e64c4c}{\begin{pmatrix} 0 \\ 1 \\ 0 \end{pmatrix}} = \textcolor{#4ce6e6}{\begin{pmatrix} 2 \\ 4 \end{pmatrix}}$.
*   $\textcolor{#4ce6e6}{\begin{pmatrix} 2 \\ 3 \end{pmatrix}} \notin \text{Bild}(A)$, da das System $A\vec{x} = \begin{pmatrix} 2 \\ 3 \end{pmatrix}$ zum Widerspruch $4 \neq 3$ führt.

**B. Systematische Berechnung von Bild(A) und Kern(A):**

1.  **Bestimmung des Bildes:**
    Wann ist $A\vec{x} = \begin{pmatrix} a \\ b \end{pmatrix}$ lösbar?
    $$
    \begin{cases} 1x_1 + 2x_2 + 3x_3 = \textcolor{#4ce6e6}{a} \quad \textcolor{#e64c4c}{(3)} \\ 2x_1 + 4x_2 + 6x_3 = \textcolor{#4ce6e6}{b} \quad \textcolor{#e64c4c}{(4)} \end{cases}
    $$
    Da $(4)$ genau $2 \times (3)$ ist, muss gelten: $\textcolor{#4ce6e6}{b} = \textcolor{#4ce6e6}{2a}$.
    $$
    \text{Bild}(A) = \left\{ \textcolor{#4ce6e6}{a} \begin{pmatrix} 1 \\ 2 \end{pmatrix} : a \in \mathbb{R} \right\} = \text{lin} \left\{ \begin{pmatrix} 1 \\ 2 \end{pmatrix} \right\}
    $$
    Das Bild ist ein Unterraum von $\mathbb{R}^{\textcolor{#e6994c}{2}}$.

2.  **Bestimmung des Kerns:**
    Löse $A\vec{x} = \vec{0}$:
    $$
    x_1 + 2x_2 + 3x_3 = 0 \iff \textcolor{#e64c4c}{x_1} = -2x_2 - 3x_3
    $$
    Einsetzen in den Vektor:
    $$
    \begin{pmatrix} \textcolor{#e64c4c}{x_1} \\ x_2 \\ x_3 \end{pmatrix} = \begin{pmatrix} -2x_2 - 3x_3 \\ x_2 \\ x_3 \end{pmatrix} = x_2 \begin{pmatrix} -2 \\ 1 \\ 0 \end{pmatrix} + x_3 \begin{pmatrix} -3 \\ 0 \\ 1 \end{pmatrix}
    $$
    $$
    \text{Kern}(A) = \text{lin} \left\{ \begin{pmatrix} -2 \\ 1 \\ 0 \end{pmatrix}, \begin{pmatrix} -3 \\ 0 \\ 1 \end{pmatrix} \right\}
    $$
    Diese beiden Vektoren bilden eine Basis des Kerns (linear unabhängig). Der Kern ist ein Unterraum von $\mathbb{R}^3$.

## <span style="text-decoration:underline">Satz 1.2: Eigenschaften von Bild und Kern</span>

Sei $A \in \mathbb{R}^{\textcolor{#e6994c}{n} \times \textcolor{#e6994c}{m}}$.

1.  $\text{Kern}(A)$ ist Unterraum von $\mathbb{R}^{\textcolor{#e6994c}{m}}$ und $\text{Bild}(A)$ ist Unterraum von $\mathbb{R}^{\textcolor{#e6994c}{n}}$.
2.  $\text{Bild}(A) = \text{lin} \{ \text{Spalten von } A \}$.
3.  **Struktur der Lösungsmenge:** Ist $A \vec{x}_0 = \vec{b}$ (partikuläre Lösung), dann ist die Gesamtmenge aller Lösungen:
    $$
    \textcolor{#e6994c}{B} = \{ \vec{x} \in \mathbb{R}^{\textcolor{#e6994c}{m}} : A\vec{x} = \vec{b} \} = \underbrace{\textcolor{#99e64c}{\vec{x}_0}}_{\text{Partikulär}} + \underbrace{\text{Kern}(A)}_{\text{Homogen}}
    $$

> [!NOTE]
> Dieser Satz sichert die Vektorraumstruktur von Bild und Kern und besagt, dass sich jede Lösung eines inhomogenen Systems als Summe aus einer speziellen Lösung und einer beliebigen Lösung des homogenen Systems darstellen lässt (Affiner Unterraum).

### Beweise zu Satz 1.2

**Zu (2): Bild als Spann der Spalten ($A \in \mathbb{R}^{2 \times 2}$)**
$$
\text{Bild}(A) = \left\{ \begin{pmatrix} a_{11} & a_{12} \\ a_{21} & a_{22} \end{pmatrix} \begin{pmatrix} x_1 \\ x_2 \end{pmatrix} \right\} = \left\{ x_1 \begin{pmatrix} a_{11} \\ a_{21} \end{pmatrix} + x_2 \begin{pmatrix} a_{12} \\ a_{22} \end{pmatrix} \right\}
$$
Dies entspricht exakt $\text{lin} \left\{ \text{Spalte 1}, \text{Spalte 2} \right\}$.

**Zu (3): Affine Struktur der Lösungsmenge**
Sei $A \cdot \textcolor{#e64c4c}{\vec{x}_0} = \vec{b}$. Dann gilt für ein beliebiges $\vec{x}$:
$$
A\vec{x} = \vec{b} \iff A\vec{x} = A\textcolor{#e64c4c}{\vec{x}_0} \iff A(\vec{x} - \textcolor{#e64c4c}{\vec{x}_0}) = \vec{0}
$$
Dies ist äquivalent dazu, dass der Differenzvektor im Kern liegt:
$$
(\vec{x} - \textcolor{#e64c4c}{\vec{x}_0}) \in \text{Kern } A \iff \vec{x} \in \textcolor{#e64c4c}{\vec{x}_0} + \text{Kern } A
$$

![](V5_lineare_Gleichungssysteme__Bild__Kern/V5_lineare_Gleichungssysteme__Bild__Kern_p3_Diagram_1.excalidraw)

### Beispiel 1.9.3: Anwendung des Satzes

**Aufgabe:** Bestimme die Lösungsmenge $\textcolor{#e6994c}{B}$ für $A\vec{x} = \begin{pmatrix} 1 \\ 2 \end{pmatrix}$ mit $A = \begin{pmatrix} 1 & 2 & 3 \\ 2 & 4 & 6 \end{pmatrix}$.

**Lösung:**
1.  **Partikuläre Lösung ($\vec{x}_0$):**
    Wir sehen durch scharfes Hinsehen:
    $$
    A \begin{pmatrix} 1 \\ 0 \\ 0 \end{pmatrix} = 1 \cdot \begin{pmatrix} 1 \\ 2 \end{pmatrix} = \begin{pmatrix} 1 \\ 2 \end{pmatrix} \implies \textcolor{#99e64c}{\vec{x}_0 = \begin{pmatrix} 1 \\ 0 \\ 0 \end{pmatrix}}
    $$
2.  **Kern (aus Bsp 1.9.1):**
    $$
    \text{Kern}(A) = \text{lin} \left\{ \begin{pmatrix} -3 \\ 0 \\ 1 \end{pmatrix}, \begin{pmatrix} -2 \\ 1 \\ 0 \end{pmatrix} \right\}
    $$
3.  **Gesamtlösung:**
    $$
    \textcolor{#e6994c}{B} = \textcolor{#99e64c}{\begin{pmatrix} 1 \\ 0 \\ 0 \end{pmatrix}} + \left\{ s \begin{pmatrix} -3 \\ 0 \\ 1 \end{pmatrix} + t \begin{pmatrix} -2 \\ 1 \\ 0 \end{pmatrix} : s,t \in \mathbb{R} \right\}
    $$

***[DIAGRAM_Lösungsmenge_Ebene]***