# Riemann-Integral, Partielle Integration, Substitution

<span style="background-color:#994ce6">Riemann Integral</span> (Animationen am Anfang zeigen)

Sei $a,b \in \mathbb{R}, a < b$, und $f : [a;b] \to \mathbb{R}$ eine beschränkte Funktion (d.h. $f([a;b])$ ist beschränkt: $\exists c,d$ mit $c \leq f(x) \leq d \quad \forall x \in [a;b]$).

## 1. Definition und Konstruktion des Riemann-Integrals

### 1.1 Zerlegungen und Intervall-Basis
**Def. 1.1.1:** $Z = \{x_0, x_1, ..., x_n\}$ heißt **Zerlegung** von $[a;b]$, falls $a = x_0 < x_1 < ... < x_n = b$.

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p1_LineSegment_Zero_to_N.excalidraw)

Sei $Z$ eine Zerlegung von $[a;b]$. Für $j=1,...,n$ definieren wir folgende Parameter für das $j$-te Intervall:

| Parameter | Definition | Beschreibung |
| :--- | :--- | :--- |
| **Intervall** | $\textcolor{#4ce64c}{I_j} = [x_{j-1}; x_j]$ | Das $j$-te Teilintervall. |
| **Länge** | $| \textcolor{#4ce64c}{I_j} | = x_j - x_{j-1}$ | Die Breite des Rechtecks. |
| **Infimum** | $\textcolor{#e6994c}{m_j} = \inf f(\textcolor{#4ce64c}{I_j})$ | Der kleinste Funktionswert im Intervall. |
| **Supremum** | $\textcolor{#4ce6e6}{M_j} = \sup f(\textcolor{#4ce64c}{I_j})$ | Der größte Funktionswert im Intervall. |

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p1_Riemann_Function_Graph.excalidraw)
*Flächeninhalt Obersummen-Rechteck:* $\textcolor{#4ce6e6}{M_j} |\textcolor{#4ce64c}{I_j}|$
*Flächeninhalt Untersummen-Rechteck:* $\textcolor{#e6994c}{m_j} |\textcolor{#4ce64c}{I_j}|$

### 1.2 Ober- und Untersummen
Wir definieren die Summen der Rechtecksflächen:

*   **Untersumme:** $\textcolor{#e6994c}{s_f}(Z) = \sum_{j=1}^n \textcolor{#e6994c}{m_j} |\textcolor{#4ce64c}{I_j}|$ (Summe der Flächeninhalte der <span style="color:#e6994c">kleinen</span> Rechtecke).
*   **Obersumme:** $\textcolor{#4ce6e6}{S_f}(Z) = \sum_{j=1}^n \textcolor{#4ce6e6}{M_j} |\textcolor{#4ce64c}{I_j}|$ (Summe der Flächeninhalte der <span style="color:#4ce6e6">großen</span> Rechtecke).

**Eigenschaften von Zerlegungen:**
Seien $Z_1, Z_2$ Zerlegungen von $[a;b]$. Dann gilt:
1.  $\textcolor{#e6994c}{s_f}(Z_1) \leq \textcolor{#4ce6e6}{S_f}(Z_2)$ $\textcolor{#e64c4c}{(*)}$
2.  $Z_1 \subseteq Z_2 \Rightarrow \textcolor{#e6994c}{s_f}(Z_1) \leq \textcolor{#e6994c}{s_f}(Z_2) \leq \textcolor{#4ce6e6}{S_f}(Z_2) \leq \textcolor{#4ce6e6}{S_f}(Z_1)$ (Verfeinerung der Zerlegung verbessert die Annäherung).

*Illustration von $\textcolor{#e64c4c}{(*)}$:*
![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p1_Refinement_Illustration.excalidraw)

### 1.3 Definition des Integrals und Integrierbarkeit
**Def. 1.1.2:**
*   **Unteres Integral:** $\textcolor{#e6994c}{s_f} := \sup \{ \textcolor{#e6994c}{s_f}(Z) : Z \text{ Zerlegung von } [a;b] \}$
*   **Oberes Integral:** $\textcolor{#4ce6e6}{S_f} := \inf \{ \textcolor{#4ce6e6}{S_f}(Z) : Z \text{ Zerlegung von } [a;b] \}$

Aus $\textcolor{#e64c4c}{(*)}$ folgt stets $\textcolor{#e6994c}{s_f} \leq \textcolor{#4ce6e6}{S_f}$.

**Def. 1.1.3 (Riemann-Integrierbarkeit):**
$f$ heißt (Riemann-) integrierbar in $[a;b]$, falls $\textcolor{#e6994c}{s_f} = \textcolor{#4ce6e6}{S_f}$.
In diesem Fall heißt der gemeinsame Wert das **Riemann Integral** von $f$ über $[a;b]$:
$$ \int_a^b f \, dx := \int_{\underline{a}}^b f(x) \, dx := \textcolor{#4ce6e6}{S_f} (= \textcolor{#e6994c}{s_f}) $$

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p1_Integral_Definition_Area.excalidraw)

### 1.4 Riemannsche Summen und Konvergenz
Für eine Zerlegung $Z$ sei die **Feinheit** definiert als $||Z|| = \max \{ | \textcolor{#4ce64c}{I_j} | \ j=1,...,n \}$.
Wählen wir Stützstellen $c_j \in \textcolor{#4ce64c}{I_j}$ für alle $j=1,...,n$, so gilt:

$$
\underbrace{\sum_{j=1}^n \textcolor{#e6994c}{m_j} |\textcolor{#4ce64c}{I_j}|}_{\textcolor{#e6994c}{\text{Untersumme}}} \leq \underbrace{\sum_{j=1}^n f(c_j) |\textcolor{#4ce64c}{I_j}|}_{\text{Riemannsche Summe}} \leq \underbrace{\sum_{j=1}^n \textcolor{#4ce6e6}{M_j} |\textcolor{#4ce64c}{I_j}|}_{\textcolor{#4ce6e6}{\text{Obersumme}}}
$$

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p1_Riemann_Sum_Approximation.excalidraw)

**Satz:** Wenn $||Z|| \to 0$ (Breite der Rechtecke geht gegen Null), dann konvergiert die Riemannsche Summe gegen das Integral.

> [!NOTE]
> **Wirkungsweise:** Das Riemann-Integral nähert den Flächeninhalt unter einer Kurve an, indem das Intervall in immer feinere vertikale Streifen zerlegt wird. Wenn das Supremum der Untersummen (Einschachtelung von unten) gleich dem Infimum der Obersummen (Einschachtelung von oben) ist, ist die Fläche eindeutig bestimmt und die Funktion integrierbar.

#### Interaktionsfrage: Effizienzvergleich
<span style="background-color:#994ce6">Frage:</span> Ist es allgemein effizienter das Integral einer Funktion mit Untersummen, mit Obersummen oder mit Riemannschen Summen zu approximieren?

---

## 2. Eigenschaften des Riemann-Integrals

Wir betrachten die Menge $R[a;b] = \{ g: [a;b] \to \mathbb{R}, \, g \text{ beschränkt und Riemann-integrierbar} \}$.

### 2.1 Grundlegende Eigenschaften
1.  **Konstante Funktionen:** Ist $f(x)=k \;\; \forall x \in [a;b]$, dann $f \in R[a;b]$ und $\int_a^b f \, dx = k \cdot (b-a)$.
2.  **Stetigkeit:** $f: [a;b] \to \mathbb{R}$ stetig $\Rightarrow f \in R[a;b]$.
3.  **Monotonie:**
    *   $f \le g \Rightarrow \int_a^b f \, dx \le \int_a^b g \, dx$
    *   ![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p2_Inequality_Graph.excalidraw)
4.  **Linearität:** $\forall \alpha, \beta \in \mathbb{R}$ gilt $\alpha f + \beta g \in R[a;b]$ und:
    $$ \int_a^b (\alpha f + \beta g) dx = \alpha \int_a^b f dx + \beta \int_a^b g dx $$
5.  **Produkt:** $f \cdot g \in R[a;b]$, <span style="color:#e64c4c">aber allgemein $\int_a^b fg \, dx \neq \int_a^b f \, dx \int_a^b g \, dx$</span>.
6.  **Betrag (Dreiecksungleichung):** $|f| \in R[a;b]$ und $|\int_a^b f \, dx| \le \int_a^b |f| dx$.

### 2.2 Intervall-Additivität
Wenn $c \in (a;b)$ und $f \in R[a;b]$, dann gilt:
$$ \int_a^b f \, dx = \int_a^c f \, dx + \int_c^b f \, dx $$

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p2_Interval_Split_Graph.excalidraw)

*Erweiterte Definitionen:*
*   Wenn $c < d$, definieren wir $\int_d^c f \, dx = - \int_c^d f \, dx$.
*   Die Additivität gilt unabhängig davon, ob $c$ zwischen $a,b$ liegt, vorausgesetzt alle Integrale existieren.

### 2.3 Vorzeichenbehaftete Flächen
Sei $f$ wie in der Skizze, dann $\int_a^b f \, dx = \textcolor{#e6994c}{F_1} - \textcolor{#4ce6e6}{F_2}$.

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p2_Signed_Area_Graph.excalidraw)

> [!NOTE]
> **Wirkungsweise:** Das Riemann-Integral operiert linear (Skalierung und Addition von Funktionen übertragen sich auf das Integral). Es berechnet die "vorzeichenbehaftete Fläche", wobei Flächen unterhalb der x-Achse negativ gezählt werden.

---

### Interaktionsaufgabe: Integralfunktion skizzieren

Für $f: [a,b] \to \mathbb{R}$ sei $F(x) = \int_a^{\textcolor{#4c99e6}{x}} f(s)ds$.

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p2_Small_Integral_Graph.excalidraw)

**Gegeben:** Sei $f: [0,3] \to \mathbb{R}$ mit den Flächeninhalten $\textcolor{#e64c4c}{F_1} > \textcolor{#4c99e6}{F_2} > \textcolor{#e6994c}{F_3}$.

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p2_Interaction_Graph_Main.excalidraw)

**Aufgabe:** Skizziere grob den Graphen von $F$. Hat $F$ an den Stellen $0, 1, 1.5, 2, 2.5$ (lokales) Min/Max oder keine (lokale) Extremstelle?

---

## 3. Hauptsatz der Differential- und Integralrechnung

Sei $f : [a, b] \to \mathbb{R}$ stetig.

### 3.1 Formulierung des Satzes
$\textcolor{#994ce6}{(1)}$ Sei $F : [a, b] \to \mathbb{R}$ definiert durch $F(\textcolor{#4ce6e6}{x}) = \int_a^{\textcolor{#4ce6e6}{x}} f(\textcolor{#e6994c}{s}) d\textcolor{#e6994c}{s}$. Dann ist $F$ differenzierbar und es gilt:
$$ F' = f \quad \text{auf } [a; b] $$

$\textcolor{#994ce6}{(2)}$ Ist $G : [a; b] \to \mathbb{R}$ eine Stammfunktion (d.h. $G' = f$ auf $[a; b]$), dann gilt:
$$ \int_a^b f(x) dx = G(b) - G(a) = [G(x)]_a^b $$

**Physikalische Illustration von (1):**
Ist $f$ die Geschwindigkeit eines Punktes (Funktion der Zeit), dann ist $F(\textcolor{#4ce6e6}{x})$ der Ort. Es gilt $F' = f$ (Ableitung des Ortes nach der Zeit ist die Geschwindigkeit).

### 3.2 Beweis
**Herleitung von (2) aus (1):**
Da $G' = f = F'$, existiert ein $c \in \mathbb{R}$ mit $G(x) = F(x) + c$.
$$ G(b) - G(a) = (F(b) + c) - (F(a) + c) = F(\textcolor{#4ce6e6}{b}) - F(a) = \int_a^{\textcolor{#4ce6e6}{b}} f dx - \underbrace{\int_a^a f dx}_{=0} = \int_a^b f dx $$

**Beweis von (1):**
Wir zeigen $\lim_{h \to 0+} \frac{F(x_0 + h) - F(x_0)}{h} - f(x_0) = 0$.

$$
\begin{aligned}
\left| \frac{F(x_0 + h) - F(x_0)}{h} - f(x_0) \right| &= \left| \frac{\int_{x_0}^{x_0+h} f dx - \int_{x_0}^{x_0} f dx}{h} - \frac{h \cdot f(x_0)}{h} \right| \\
&\overset{\text{Additivität}}{=} \left| \frac{\int_{x_0}^{x_0+h} f dx - h \cdot f(x_0)}{h} \right| \\
&\overset{\text{Integral konst. Fkt.}}{=} \left| \frac{\int_{x_0}^{x_0+h} f dx - \int_{x_0}^{x_0+h} f(x_0) dx}{h} \right| \\
&\overset{\text{Linearität}}{=} \frac{\left| \int_{x_0}^{x_0+h} (f(x) - f(x_0)) dx \right|}{h} \\
&\overset{\text{Dreiecksungl.}}{\leq} \frac{\int_{x_0}^{x_0+h} |f(x) - f(x_0)| dx}{h} \quad (\textcolor{#99e64c}{\text{ grüner Flächeninhalt}}) \\
&\leq \frac{1}{h} \cdot \textcolor{#4ce6e6}{\max_{s \in [x_0; x_0+h]} |f(s) - f(x_0)|} \cdot \textcolor{#e6994c}{h} \quad (\textcolor{#e64c4c}{\text{ roter Flächeninhalt}}) \\
&= \max_{s \in [x_0; x_0+h]} |f(s) - f(x_0)| \xrightarrow{h \to 0} 0 \quad (\text{da } f \text{ stetig ist})
\end{aligned}
$$

**Visualisierung der Abschätzung:**
![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p3_Green_Max_Area_Graph.excalidraw)
*(Grüne Fläche)*

![](V_20-21_Riemann_integral__partielle_Integration__Substitution/V_20-21_Riemann_integral__partielle_Integration__Substitution_p3_Red_Max_Area_Graph.excalidraw)
*(Rote Fläche)*

> [!NOTE]
> **Wirkungsweise:** Der Hauptsatz verbindet die Differentialrechnung (lokale Änderungsrate) mit der Integralrechnung (globale Akkumulation). Teil (1) besagt, dass Integration die Umkehroperation zur Differentiation ist. Teil (2) erlaubt die einfache Berechnung von Integralen mittels Stammfunktionen.

---

## 4. Berechnung von Integralen (Grundintegrale)

Sei $F$ eine Stammfunktion von $f$ ($F' = f$). Das unbestimmte Integral $\int f(x) \, dx$ bezeichnet die Menge aller Stammfunktionen.

| Funktionstyp | Integralformel | Bedingung |
| :--- | :--- | :--- |
| **Trigonometrisch** | $\int \sin(ax) \, dx = -\frac{\cos(ax)}{a} + c$ | $a \neq 0$ |
| | $\int \cos(ax) \, dx = \frac{\sin(ax)}{a} + c$ | $a \neq 0$ |
| **Exponential** | $\int e^{ax} \, dx = \frac{e^{ax}}{a} + c$ | $a \neq 0$ |
| **Potenz** | $\int x^a \, dx = \frac{x^{a+1}}{a+1} + c$ | $a \neq -1$ |
| **Logarithmisch** | $\int \frac{1}{x} \, dx = \ln |x| + c$ | auf $(-\infty, 0)$ oder $(0, \infty)$ |

---

## 5. Trigonometrische Additionstheoreme und Folgerungen

Diese Identitäten sind essentiell für die Integration von Produkten trigonometrischer Funktionen.

**Basis-Theoreme:**
$$
\begin{aligned}
\cos(\varphi + \theta) &= \cos\varphi \cos\theta - \sin\varphi \sin\theta \\
\sin(\varphi + \theta) &= \sin\varphi \cos\theta + \cos\varphi \sin\theta
\end{aligned}
$$

**Doppelwinkel-Formeln:**
$$ \cos(2\varphi) = 2\cos^2\varphi - 1 = 1 - 2\sin^2\varphi $$
$$ \sin(2\varphi) = 2\sin\varphi \cos\varphi $$

**Quadrat-Formeln (Linearisierung):**
$$ \sin^2\varphi = \frac{1-\cos(2\varphi)}{2} \quad , \quad \cos^2\varphi = \frac{1+\cos(2\varphi)}{2} $$

**Produkt-zu-Summe Formeln:**
$$
\begin{aligned}
\sin\varphi \cos\theta &= \frac{1}{2} (\sin(\varphi + \theta) + \sin(\varphi - \theta)) \quad \textcolor{#e64c4c}{(*)} \\
\sin\varphi \sin\theta &= \frac{1}{2} (\cos(\varphi - \theta) - \cos(\varphi + \theta)) \\
\cos\varphi \cos\theta &= \frac{1}{2} (\cos(\varphi - \theta) + \cos(\varphi + \theta))
\end{aligned}
$$

### Beispiel 11.4 a): Anwendung der Additionstheoreme
Zu berechnen: $\int_0^{\frac{\pi}{2}} \sin(x) \cos(2x) \, dx$

$$
\begin{aligned}
\int_0^{\frac{\pi}{2}} \sin(x) \cos(2x) \, dx &\overset{\textcolor{#e64c4c}{(*)}}{=} \int_0^{\frac{\pi}{2}} \frac{1}{2} (\sin(x+2x) + \underbrace{\sin(x-2x)}_{-\sin(x)}) \, dx \\
&= \frac{1}{2} \left( \int_0^{\frac{\pi}{2}} \sin(3x) \, dx - \int_0^{\frac{\pi}{2}} \sin x \, dx \right) \\
&= \frac{1}{2} \left( \left[ -\frac{\cos(3x)}{3} \right]_0^{\frac{\pi}{2}} + [\cos(x)]_0^{\frac{\pi}{2}} \right) \\
&= \frac{1}{2} \cdot \left[ \frac{\cos(0)-\cos(\frac{3\pi}{2})}{3} + (\cos(\tfrac{\pi}{2}) - \cos(0)) \right] \\
&= \frac{1}{2} \cdot \left( \frac{1-0}{3} + (0-1) \right) = \frac{1}{2} \cdot (-\frac{2}{3}) = -\frac{1}{3}
\end{aligned}
$$

> [!NOTE]
> **Wirkungsweise:** Trigonometrische Identitäten ermöglichen es, Produkte oder Potenzen von Sinus und Kosinus in Summen einfacherer Terme (z.B. lineare Frequenzen) umzuwandeln, die direkt integrierbar sind.

---

## 6. Integrationstechniken

### 6.1 Satz 11.4: Partielle Integration
Diese Technik ist die Umkehrung der Produktregel.

Sei $I$ ein Intervall und $f, g$ differenzierbar auf $I$ mit stetigen Ableitungen.
$\textcolor{#e64c4c}{(1)}$ **Unbestimmt:** $\int f'g \, dx = fg - \int fg' \, dx$ auf $I$.
$\textcolor{#e64c4c}{(2)}$ **Bestimmt:** $\int_a^b f'g \, dx = [f(x)g(x)]_a^b - \int_a^b fg' \, dx$ für $I=[a;b]$.

*Beweisidee:* Integriere die Produktregel $(fg)' = f'g + fg'$ und wende den Hauptsatz an.

> [!NOTE]
> **Wirkungsweise:** Man zerlegt den Integranden in zwei Faktoren $u'$ und $v$. Durch Überwälzen der Ableitung von $u'$ auf $v$ entsteht ein neues Integral. Ziel ist es, dass $\int uv' dx$ einfacher zu lösen ist als das ursprüngliche $\int u'v dx$.

#### Beispiele zur partiellen Integration
**Beispiel 11.4 b):**
$\int x e^x \, dx = \int \underbrace{(e^x)'}_{f'} \underbrace{x}_{g} \, dx \overset{\textcolor{#e64c4c}{(1)}}{=} e^x x - \int e^x \underbrace{(x)'}_{1} \, dx = x e^x - e^x + c$

**Beispiel 11.4 c):**
$\int_1^e x \ln x \, dx = \int_1^e \underbrace{\left( \frac{x^2}{2} \right)'}_{f'} \underbrace{\ln x}_{g} \, dx$
$$
\begin{aligned}
&\overset{\textcolor{#e64c4c}{(2)}}{=} \left[ \frac{x^2}{2} \ln x \right]_1^e - \int_1^e \frac{x^2}{2} (\ln x)' \, dx \\
&= \frac{e^2 \ln e - 0}{2} - \int_1^e \frac{x^2}{2} \cdot \frac{1}{x} \, dx \\
&= \frac{e^2}{2} - \frac{1}{2} \int_1^e x \, dx = \frac{e^2}{2} - \frac{1}{2} \left[ \frac{x^2}{2} \right]_1^e \\
&= \frac{e^2}{2} - \frac{e^2 - 1}{4} = \frac{2e^2 - e^2 + 1}{4} = \frac{e^2 + 1}{4}
\end{aligned}
$$

### 6.2 Satz 11.5: Integration durch Substitution
Diese Technik ist die Umkehrung der Kettenregel.

Sei $f$ stetig, $u$ differenzierbar.
$\textcolor{#e64c4c}{(i)}$ **Unbestimmt:** $\int f(u(x)) u'(x) \, dx = F(u(x)) + c$, wobei $F'=f$.
$\textcolor{#e64c4c}{(ii)}$ **Bestimmt:** $\int_a^b f(u(x)) u'(x) \, dx = \int_{u(a)}^{u(b)} f(u) \, du$.

*Merkregel:*
Wir substituieren $\textcolor{#4ce6e6}{u} = u(x)$. Dann ist $\frac{\textcolor{#4ce6e6}{du}}{dx} = u'(x) \implies \textcolor{#4ce6e6}{du} = u'(x) dx$.
Die Grenzen transformieren sich von $x \in [a,b]$ zu $u \in [u(a), u(b)]$.

> [!NOTE]
> **Wirkungsweise:** Man ersetzt eine innere Funktion $u(x)$ durch eine neue Variable $u$. Dabei muss auch das Differential $dx$ durch $du$ (unter Berücksichtigung der "Nachdifferenzierung" $u'(x)$) ersetzt und die Integrationsgrenzen angepasst werden. Dies vereinfacht komplexe verkettete Funktionen.

#### Beispiel 11.4 d): Substitution
Berechne: $\int_{\textcolor{#e6994c}{\sqrt{3}}}^{\textcolor{#e6994c}{\sqrt{8}}} (x^2+1)^{-\frac{3}{2}} x \, dx$

1.  **Substitution:** Sei $\textcolor{#4ce6e6}{u(x)} = x^2+1$.
2.  **Differential:** $\textcolor{#4ce6e6}{du} = 2x \, dx \implies x \, dx = \frac{\textcolor{#4ce6e6}{du}}{2}$.
3.  **Grenzen:**
    *   $x = \textcolor{#e6994c}{\sqrt{3}} \to u = (\sqrt{3})^2+1 = \textcolor{#e6994c}{4}$
    *   $x = \textcolor{#e6994c}{\sqrt{8}} \to u = (\sqrt{8})^2+1 = \textcolor{#e6994c}{9}$
4.  **Rechnung:**
$$
\begin{aligned}
\int_{\sqrt{3}}^{\sqrt{8}} \underbrace{(x^2+1)^{-\frac{3}{2}}}_{u^{-\frac{3}{2}}} \underbrace{x \, dx}_{\frac{du}{2}} &= \int_{4}^{9} u^{-\frac{3}{2}} \cdot \frac{1}{2} \, du \\
&= \frac{1}{2} \left[ \frac{u^{-\frac{1}{2}}}{-\frac{1}{2}} \right]_4^9 = \left[ -u^{-\frac{1}{2}} \right]_4^9 \\
&= - \left( \frac{1}{\sqrt{9}} - \frac{1}{\sqrt{4}} \right) = - \left( \frac{1}{3} - \frac{1}{2} \right) = \frac{1}{6}
\end{aligned}
$$